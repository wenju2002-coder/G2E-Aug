# G2E-Augend

## Title

G2E-Augend: Retrosynthesis Prediction Using an End-to-End Graph Neural Network for Molecular Graph Editing

## Environment Requirements

```text
python = 3.11.8
pytorch = 2.2.2
numpy = 1.26.4
rdkit = 2024.03.4
```

The code also requires `pandas`, `joblib`, and `tqdm`.

## Data

The original datasets used in this project are from:

- USPTO-50K: https://github.com/Hanjun-Dai/GLN (`schneider50k`)
- USPTO-FULL: https://github.com/Hanjun-Dai/GLN (`uspto_multi`)

The raw and processed data should be placed in the corresponding dataset folders. The directory structure should be as follows:

```text
G2E-Augend
└── data
    ├── uspto_50k
    │   ├── canonicalized_test.csv
    │   ├── canonicalized_train.csv
    │   ├── canonicalized_valid.csv
    │   ├── raw_test.csv
    │   ├── raw_train.csv
    │   └── raw_valid.csv
    └── uspto_full
        ├── raw_test.csv
        ├── raw_train.csv
        └── raw_valid.csv
```

The raw USPTO-50K and USPTO-FULL datasets are stored as `raw_train.csv`, `raw_valid.csv`, and `raw_test.csv`.

For USPTO-50K, `canonicalize_prod.py` generates `canonicalized_train.csv`, `canonicalized_valid.csv`, and `canonicalized_test.csv`. The current preprocessing code reads the canonicalized files for USPTO-50K and the raw files for USPTO-FULL.

## Data Preprocessing

Run all commands from the project root directory.

### Canonicalize USPTO-50K

```bash
python canonicalize_prod.py --mode train --dataset uspto_50k
python canonicalize_prod.py --mode valid --dataset uspto_50k
python canonicalize_prod.py --mode test --dataset uspto_50k
```

### Generate Edit Labels and Edit Sequences

Process the training set first because the validation and test sets use the edit vocabularies generated from the training set.

For USPTO-50K:

```bash
python preprocess.py --mode train --dataset uspto_50k
python preprocess.py --mode valid --dataset uspto_50k
python preprocess.py --mode test --dataset uspto_50k
```

For USPTO-FULL:

```bash
python preprocess.py --mode train --dataset uspto_full
python preprocess.py --mode valid --dataset uspto_full
python preprocess.py --mode test --dataset uspto_full
```

### Prepare Training Data

Prepare the data without using reaction classes as a condition:

```bash
python prepare_data.py --dataset uspto_50k
```

or

```bash
python prepare_data.py --dataset uspto_full
```

Prepare the USPTO-50K data using reaction classes as a condition:

```bash
python prepare_data.py --dataset uspto_50k --use_rxn_class
```

The generated training batches are saved under:

```text
data/<dataset>/train/without_rxn_class/
data/<dataset>/train/with_rxn_class/
```

## Train the G2E-Augend Model

Train a model without using reaction classes as a condition:

```bash
python train.py --dataset uspto_50k
```

or

```bash
python train.py --dataset uspto_full
```

The trained model is saved under:

```text
G2E-Augend/experiments/<dataset>/without_rxn_class/<experiment_name>/
```

Train a USPTO-50K model using reaction classes as a condition:

```bash
python train.py --dataset uspto_50k --use_rxn_class
```

The trained model is saved under:

```text
G2E-Augend/experiments/uspto_50k/with_rxn_class/<experiment_name>/
```

`--use_rxn_class` is a Boolean flag. Add it to enable reaction-class conditioning and omit it to disable reaction-class conditioning.

## Test

Two evaluation scripts are used in this project:

- `eval.py` evaluates overall Top-1, Top-3, Top-5, and Top-10 exact accuracy and saves detailed predictions.
- `eval_bucket.py` evaluates Top-k exact accuracy for Many-shot, Medium-shot, and Few-shot reaction buckets.

### Overall Exact-Accuracy Evaluation

Without reaction classes:

```bash
python eval.py --dataset uspto_50k --experiments <experiment_name>
```

With reaction classes:

```bash
python eval.py --dataset uspto_50k --use_rxn_class --experiments <experiment_name>
```

The raw prediction file is saved as:

```text
G2E-Augend/experiments/<dataset>/<setting>/<experiment_name>/pred_results.txt
```

If the output file already exists, a numbered file such as `pred_results_1.txt` is created.

The current `eval.py` implementation loads `epoch_77.pt`. Change the checkpoint filename in `eval.py` when evaluating a different epoch.

### Many/Medium/Few-Shot Bucket Evaluation

Without reaction classes:

```bash
python eval_bucket.py --dataset uspto_50k --experiments <experiment_name> --epoch epoch_<N>.pt
```

With reaction classes:

```bash
python eval_bucket.py --dataset uspto_50k --use_rxn_class --experiments <experiment_name> --epoch epoch_<N>.pt
```

The buckets are determined by the minimum training frequency of the ground-truth edits in each reaction:

```text
Many-shot:  frequency > 100
Medium-shot: 20 <= frequency <= 100
Few-shot:   frequency < 20
```

The Markdown and CSV reports are saved under the experiment directory as:

```text
bucket_eval_epoch_<N>.md
bucket_eval_epoch_<N>.csv
```

## Reproducing Our Results

The provided USPTO-50K checkpoints are:

```text
Without reaction classes:
experiment/uspto_50k/without_rxn_class/16-07-2026--01-17-31/epoch_86.pt

With reaction classes:
experiment/uspto_50k/with_rxn_class/15-07-2026--01-22-06/epoch_124.pt
```

The evaluation code reads from `experiments/` with a trailing `s`, while the provided checkpoints are currently stored under `experiment/`. Move the supplied experiment folders into `experiments/` before running the following commands.

To reproduce the bucket exact-accuracy results without reaction classes, run:

```bash
python eval_bucket.py --dataset uspto_50k --experiments 16-07-2026--01-17-31 --epoch epoch_86.pt
```

To reproduce the bucket exact-accuracy results with reaction classes, run:

```bash
python eval_bucket.py --dataset uspto_50k --use_rxn_class --experiments 15-07-2026--01-22-06 --epoch epoch_124.pt
```

To reproduce the detailed exact-accuracy predictions using `eval.py`, set its checkpoint filename to `epoch_86.pt` or `epoch_124.pt`, and then run:

```bash
python eval.py --dataset uspto_50k --experiments 16-07-2026--01-17-31
python eval.py --dataset uspto_50k --use_rxn_class --experiments 15-07-2026--01-22-06
```

These commands report the reaction-class-unknown and reaction-class-known settings, respectively.
