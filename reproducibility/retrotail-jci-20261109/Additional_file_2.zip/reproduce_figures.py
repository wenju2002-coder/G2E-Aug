"""Reproduce manuscript figures 2-5 from the archived integer-count analysis.

Requires numpy, matplotlib and Pillow; no model inference or Word is needed.
Keep this script beside plot_manuscript_figures.py and publication_style.py.
"""
import argparse
import csv
import inspect
import json
import re
from pathlib import Path


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--analysis',type=Path,default=Path(__file__).parent/'Analysis')
    parser.add_argument('--output',type=Path,required=True,help='New directory, never overwritten.')
    args=parser.parse_args()
    if args.output.exists():raise FileExistsError('Output directory exists: '+str(args.output))
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import plot_manuscript_figures as plot
    import publication_style as style
    original_addfont=style.font_manager.fontManager.addfont
    def existing_font(path):
        if Path(path).is_file():original_addfont(path)
    style.font_manager.fontManager.addfont=existing_font
    style.configure_submission_style(plot)
    style.font_manager.fontManager.addfont=original_addfont
    if not any(font.name=='Arial' for font in style.font_manager.fontManager.ttflist):
        matplotlib.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'dejavusans'})
    audit=json.loads((args.analysis/'audit_results.json').read_text(encoding='utf-8'))
    power=list(csv.DictReader((args.analysis/'power_and_ceiling.csv').open(encoding='utf-8',newline='')))
    def row(model,bucket,cls='All'):
        return next(r for r in audit['summary_rows'] if r['model_setting']==model and
                    r['bucket']==bucket and r['class_index_0_based']==cls)
    def power_value(setting,bucket,k,field):
        return float(next(r[field] for r in power if r['setting']==setting and
                          r['bucket']==bucket and r['metric']=='top'+str(k)))
    settings={'Reaction class unknown':'unknown','Reaction class known':'known'}
    plot.BASELINE_PCT={name:np.array([[row('baseline_'+setting,b)['top'+str(k)+'_percent']
                                     for k in (1,3,5,10)] for b in ('Many','Medium','Few')])
                       for name,setting in settings.items()}
    plot.AGGREGATE_TOP1={name:row('baseline_'+setting,'All')['top1_percent'] for name,setting in settings.items()}
    plot.VERIFIED_CEILINGS={name:np.array([[power_value(setting,b,k,'aggregate_ceiling_pp') for k in (1,10)]
                                         for b in ('Many','Medium','Few')]) for name,setting in settings.items()}
    plot.VERIFIED_COMBINED_CEILINGS={name:tuple(sum(power_value(setting,b,k,'aggregate_ceiling_pp')
                                                 for b in ('Medium','Few')) for k in (1,10))
                                    for name,setting in settings.items()}
    code=re.sub(r'    ceiling = .*?\n\n    fig =',
                '    ceiling = VERIFIED_CEILINGS\n    tail_sums = VERIFIED_COMBINED_CEILINGS\n\n    fig =',
                inspect.getsource(plot.figure_2),flags=re.S)
    exec(compile(code,'<archived-ceilings>','exec'),plot.__dict__)
    plot.VERIFIED_FEW_MDD=np.array([power_value('unknown','Few',k,'mdd_unpaired_80_percent_power_pp') for k in (1,3,5,10)])
    plot.VERIFIED_BASE_FEW=np.array([row('baseline_unknown','Few')['correct_top'+str(k)] for k in (1,3,5,10)])
    plot.VERIFIED_AUG_FEW=np.array([row('aug_unknown','Few')['correct_top'+str(k)] for k in (1,3,5,10)])
    code=inspect.getsource(plot.figure_3)
    code=re.sub(r'    mdd = np.array\(\[[^\]]+\]\)','    mdd = VERIFIED_FEW_MDD',code)
    code=re.sub(r'    baseline_counts = np.array\([^\n]+','    baseline_counts = VERIFIED_BASE_FEW',code)
    code=re.sub(r'    augmented_counts = np.array\([^\n]+','    augmented_counts = VERIFIED_AUG_FEW',code)
    exec(compile(code,'<archived-few-estimates>','exec'),plot.__dict__)
    plot.VERIFIED_CLASS_COUNTS=np.array([[next((r['n'] for r in audit['summary_rows']
                                               if r['model_setting']=='baseline_unknown' and r['bucket']==b and
                                               r['class_index_0_based']==c),0)
                                        for b in ('Many','Medium','Few')] for c in range(10)])
    plot.VERIFIED_CLASS_ACCURACY=np.array([[row('baseline_unknown',b,c)['top1_percent']
                                          if plot.VERIFIED_CLASS_COUNTS[c,j] else np.nan
                                          for j,b in enumerate(('Many','Medium','Few'))] for c in range(10)])
    code=re.sub(r'    counts = np.array\(.*?\n    \)\n    accuracy = np.array\(.*?\n    \)',
                '    counts = VERIFIED_CLASS_COUNTS\n    accuracy = VERIFIED_CLASS_ACCURACY',
                inspect.getsource(plot.figure_4),flags=re.S)
    exec(compile(code,'<archived-class-strata>','exec'),plot.__dict__)
    args.output.mkdir(parents=True,exist_ok=False)
    stems={2:'Fig2_accuracy_by_edit_frequency',3:'Fig3_aggregate_tail_ceiling',
           4:'Fig4_few_shot_paired_comparison',5:'Fig5_class_bucket_composition'}
    for number,builder in zip(range(2,6),[plot.figure_1,plot.figure_2,plot.figure_3,plot.figure_4]):
        fig=builder(include_figure_title=False)
        style.resize_to_full_width(fig,112 if number==5 else 110)
        style.refine_layout(fig,'Fig4_few_shot_mdd_comparison' if number==4 else stems[number])
        if number==2:
            for ax,(_,values) in zip(fig.axes,plot.BASELINE_PCT.items()):
                labels=[item for item in ax.texts if re.fullmatch(r'\d+\.\d',item.get_text())]
                for index,item in enumerate(labels):
                    metric,bucket=divmod(index,3);n=(4832,120,52)[bucket]
                    count=int(round(values[bucket,metric]*n/100))
                    item.set_y(plot.wilson_interval(count,n)[1]+1.4)
                for item in ax.texts:
                    if item.get_text().startswith('Aggregate Top-1:'):
                        item.set_transform(ax.transAxes);item.set_position((0.99,0.975))
        for item in fig.findobj():
            if not hasattr(item,'get_text'):continue
            value=item.get_text()
            if 'Both tail buckets:' in value:item.set_text(value.replace('Both tail buckets:','Medium + few-shot:'))
            if value=='Tail counts':item.set_text('Medium/few counts')
            if number==4 and value.startswith('Wilson 95% CI;'):
                item.set_text('Wilson 95% CI; shaded MDD is an unpaired planning reference\n'
                              'Top-10 paired p = 0.03125; Holm p = 0.84375 (32 comparisons)')
                item.set_fontsize(7.8)
        if number==5:
            totals=plot.VERIFIED_CLASS_COUNTS.sum(axis=1)
            fig.axes[0].set_yticklabels([f'Class {i+1} ($n$={int(n):,})' for i,n in enumerate(totals)])
            fig.axes[1].set_yticklabels([f'Class {i+1}' for i in range(10)])
        fig.savefig(args.output/(stems[number]+'.pdf'),metadata={'Title':stems[number]})
        fig.savefig(args.output/(stems[number]+'.png'),dpi=300)
        plt.close(fig)
    print('Reproduced four figures from:',args.analysis)


if __name__=='__main__':main()
