"""Redraw every real-data figure from the compact analysis tables.   python3 make_figures.py <tables_dir> <out_dir> [fig2 fig3 ...]"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import numpy as np, pandas as pd
import figlocal as L
fs = L.fs
import matplotlib.pyplot as plt
from matplotlib import patches

TAB, OUT = sys.argv[1], sys.argv[2]
WHICH = sys.argv[3:] or ["fig2", "fig3", "fig4", "fig5"]  # Fig. 1 is drawn by make_fig1_svg.py
fs.setup()
plt.rcParams.update({"font.family":"Arial","font.sans-serif":["Arial"],"font.size":9.1,"axes.titlesize":9.1,"axes.labelsize":9.1,"xtick.labelsize":9.1,"ytick.labelsize":9.1,"legend.fontsize":9.1})
SD = fs.SourceData(script="scripts/make_figures.py")

def vheat(ax, M, cmap, vmin, vmax):
    """Vector heat map: one rectangle per cell (no embedded raster); cell centres at integer coordinates."""
    from matplotlib import colors as mcolors
    cm = plt.get_cmap(cmap) if isinstance(cmap, str) else cmap
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
    M = np.ma.masked_invalid(np.asarray(M, float))
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if not np.ma.is_masked(M[i, j]):
                ax.add_patch(patches.Rectangle((j - 0.5, i - 0.5), 1, 1, facecolor=cm(norm(M[i, j])), edgecolor="none", lw=0))
    ax.set_xlim(-0.5, M.shape[1] - 0.5); ax.set_ylim(M.shape[0] - 0.5, -0.5)


_orig_add = SD.add
def _add(panel, table, source="", note=""):
    import hashlib
    first = source.split(";")[0].strip()
    path = os.path.join(TAB, first)
    _orig_add(panel, table, source=source, note=note)
    if os.path.isfile(path):
        SD.panels[panel]["sha256"] = hashlib.sha256(open(path, "rb").read()).hexdigest()[:16]
SD.add = _add
rd = lambda n: pd.read_csv(os.path.join(TAB, n))
acc = rd("acc_by_bucket.csv"); gap = rd("gap_newcombe.csv"); ceil = rd("ceiling_mdd.csv")
thr = rd("threshold_sensitivity_rederived.csv"); fb = rd("fine_bins.csv"); lr = rd("logit_exploratory.csv")
lrs = rd("logit_with_similarity.csv"); labels = rd("edit_label_frequencies.csv")
G3 = ["Many", "Medium", "Few"]
N_ALL = 5004


def A(setting, bucket, metric):
    r = acc[(acc.setting == setting) & (acc.bucket == bucket) & (acc.metric == metric)].iloc[0]
    return r


# =====================================================================================
def fig2():
    fig, axs = fs.grid("double", 118, 2, 3, wspace=0.50, hspace=0.62, left=0.065, right=0.99, top=0.945, bottom=0.135)
    # ---- a: rank-frequency of the edit vocabulary
    ax = axs[0][0]
    lab = labels.sort_values("train_count", ascending=False).reset_index(drop=True)
    cols = [L.GCOL["Many"] if c > 100 else (L.GCOL["Medium"] if c >= 20 else L.GCOL["Few"]) for c in lab.train_count]
    ax.vlines(lab["rank"], 0.8, lab.train_count, color=cols, lw=0.9, alpha=0.9)
    ax.scatter(lab["rank"], lab.train_count, s=3.2, color=cols, zorder=3, lw=0)
    ax.set_yscale("log"); ax.set_ylim(0.8, 6e4); ax.set_xlim(-3, 163)
    fs.hline(ax, 100); fs.hline(ax, 20)
    nM, nm, nF = (lab.train_count > 100).sum(), ((lab.train_count >= 20) & (lab.train_count <= 100)).sum(), (lab.train_count < 20).sum()
    L.tag(ax, f"{nM} labels > 100", 0.30, 0.86, color=L.MANY, size=5.2)
    L.tag(ax, f"{nm} labels 20–100", 0.46, 0.60, color="#9A6B0A", size=5.2)
    L.tag(ax, f"{nF} labels < 20", 0.62, 0.21, color=L.FEW, size=5.2)
    ax.set_xlabel("Edit label rank"); ax.set_ylabel("Training occurrences")
    fs.panel_label(ax, "a", dx=-0.27)
    SD.add("2a", lab[["rank", "label_type", "label", "train_count"]], source="edit_label_frequencies.csv")
    # ---- b: top-1 by group, both class settings
    ax = axs[0][1]
    rows = []
    for i, g in enumerate(G3):
        for sett, dx, filled in [("baseline_unknown", -0.11, True), ("baseline_known", 0.11, False)]:
            r = A(sett, g, "top1")
            L.ci_point(ax, i + dx, r.pct, r.ci_lo, r.ci_hi, L.GCOL[g], filled=filled, s=16)
            ax.annotate(f"{r.pct:.1f}", (i + dx, r.ci_hi), xytext=(0, 2.5), textcoords="offset points", ha="center", va="bottom", fontsize=9.1, color=L.GCOL[g] if g != "Medium" else "#9A6B0A")
            rows.append(dict(group=g, setting=sett, n=int(r.n), k=int(r.k), pct=r.pct, ci_lo=r.ci_lo, ci_hi=r.ci_hi))
    for sett, ls in [("baseline_unknown", (0, (1, 1.5))), ("baseline_known", (0, (4, 2)))]:
        a = A(sett, "All", "top1").pct
        ax.plot([-0.55, 2.5], [a, a], color=fs.NEUT[0], lw=0.6, ls=ls, zorder=0)
        ax.text(2.56, a, f"pooled\n{a:.1f}", fontsize=9.1, color=fs.NEUT[0], va="center", ha="left", linespacing=1.1)
    ax.set_xticks(range(3), [f"{L.GLAB[g].replace('-shot','')}\n(n = {int(A('baseline_unknown', g, 'top1').n):,})" for g in G3])
    ax.set_xlim(-0.55, 3.05); ax.set_ylim(0, 85); ax.set_ylabel("Top-1 accuracy (%)")
    L.legend_marker(ax, [("Class unknown", fs.INK, True), ("Class known", fs.INK, False)], loc="upper right", bbox=(1.0, 1.02))
    fs.light_grid(ax); fs.panel_label(ax, "b", dx=-0.22)
    SD.add("2b", pd.DataFrame(rows), source="acc_by_bucket.csv")
    # ---- c: head-to-tail gap by top-k
    ax = axs[0][2]
    ks = ["top1", "top3", "top5", "top10"]; rows = []
    for j, k in enumerate(ks):
        for sett, dx, filled in [("baseline_unknown", -0.12, True), ("baseline_known", 0.12, False)]:
            r = gap[(gap.setting == sett) & (gap.metric == k)].iloc[0]
            L.ci_point(ax, j + dx, r.gap_pp, r.lo, r.hi, L.FEW, filled=filled, s=16)
            ax.annotate(f"{r.gap_pp:.1f}", (j + dx, r.hi if dx < 0 else r.lo), xytext=(0, 2.2 if dx < 0 else -2.2), textcoords="offset points", ha="center", va="bottom" if dx < 0 else "top", fontsize=9.1, color=L.FEW)
            rows.append(dict(setting=sett, metric=k, gap_pp=r.gap_pp, lo=r.lo, hi=r.hi))
    ax.set_xticks(range(4), ["Top-1", "Top-3", "Top-5", "Top-10"]); ax.set_xlim(-0.6, 3.6)
    ax.set_ylim(0, 75); ax.set_ylabel("Many-shot minus few-shot (pp)")
    fs.light_grid(ax); fs.panel_label(ax, "c", dx=-0.22)
    L.tag(ax, "Newcombe 95% intervals", 0.02, 0.04, va="bottom", color=fs.NEUT[0], size=4.8)
    SD.add("2c", pd.DataFrame(rows), source="gap_newcombe.csv")
    # ---- d: finer frequency bins
    ax = axs[1][0]
    bins = ["<5", "5-9", "10-19", "20-49", "50-100", "101-300", "301-1000", ">1000"]
    bshow = ["<5", "5–9", "10–19", "20–49", "50–100", "101–\n300", "301–\n1000", ">1000"]
    xt = np.arange(len(bins)); rows = []
    L.shade_groups(ax, [(-0.5, 2.5, "Few"), (2.5, 4.5, "Medium"), (4.5, 7.5, "Many")], alpha=0.08)
    for sett, dx, filled in [("baseline_unknown", -0.12, True), ("baseline_known", 0.12, False)]:
        for i, b in enumerate(bins):
            r = fb[(fb.setting == sett) & (fb.bin == b) & (fb.metric == "top1")].iloc[0]
            gname = "Few" if i < 3 else ("Medium" if i < 5 else "Many")
            L.ci_point(ax, i + dx, r.pct, r.ci_lo, r.ci_hi, L.GCOL[gname], filled=filled, s=11, lw=0.8)
            rows.append(dict(setting=sett, bin=b, n=int(r.n), k=int(r.k), pct=r.pct, ci_lo=r.ci_lo, ci_hi=r.ci_hi))
    ns = [int(fb[(fb.setting == "baseline_unknown") & (fb.bin == b) & (fb.metric == "top1")].n.iloc[0]) for b in bins]
    ax.set_xticks(xt, [f"{b}" for b in bshow], fontsize=9.1); [ax.text(i, -0.215, f"n={n:,}", transform=ax.get_xaxis_transform(), ha="center", va="top", fontsize=9.1, color=fs.NEUT[0]) for i, n in enumerate(ns)]
    ax.set_xlabel("Rarest required edit: training occurrences", labelpad=22)
    ax.set_ylim(0, 90); ax.set_ylabel("Top-1 accuracy (%)"); ax.set_xlim(-0.6, 7.6)
    fs.light_grid(ax); fs.panel_label(ax, "d", dx=-0.27)
    SD.add("2d", pd.DataFrame(rows), source="fine_bins.csv")
    # ---- e: threshold sensitivity (dumbbell many vs few top-1)
    ax = axs[1][1]
    rows = []; yl = []; y = 0
    for sett, nm in [("unknown", "unknown"), ("known", "known")]:
        for lo_, hi_ in [(10, 50), (20, 100), (50, 200)]:
            t = thr[(thr.lo == lo_) & (thr.hi == hi_) & (thr.setting == sett)].set_index("bucket")
            m1, f1 = t.loc["Many", "pct1"], t.loc["Few", "pct1"]
            ax.plot([f1, m1], [y, y], color=fs.NEUT[1], lw=1.6, zorder=1, solid_capstyle="round")
            ax.scatter(f1, y, s=14, color=L.FEW, zorder=3, lw=0); ax.scatter(m1, y, s=14, color=L.MANY, zorder=3, lw=0)
            ax.annotate(f"{m1 - f1:.1f}", ((m1 + f1) / 2, y), xytext=(0, 3.2), textcoords="offset points", ha="center", va="bottom", fontsize=9.1, color=fs.INK)
            yl.append(f"{lo_}/{hi_}   ({int(t.loc['Few','n'])})")
            rows.append(dict(setting=sett, few_below=lo_, many_above=hi_, n_few=int(t.loc["Few", "n"]), many_top1=m1, few_top1=f1, gap=m1 - f1))
            y += 1
        y += 0.55
    pos = [0, 1, 2, 3.9, 4.9, 5.9]
    # re-place rows with gap between settings
    ax.clear(); ax.spines[["top", "right"]].set_visible(False)
    for yy, r in zip(pos, rows):
        ax.plot([r["few_top1"], r["many_top1"]], [yy, yy], color=fs.NEUT[1], lw=1.6, zorder=1, solid_capstyle="round")
        ax.scatter(r["few_top1"], yy, s=14, color=L.FEW, zorder=3, lw=0); ax.scatter(r["many_top1"], yy, s=14, color=L.MANY, zorder=3, lw=0)
        ax.annotate(f"{r['gap']:.1f} pp", ((r["many_top1"] + r["few_top1"]) / 2, yy), xytext=(0, 3.0), textcoords="offset points", ha="center", va="bottom", fontsize=9.1)
    ax.set_yticks(pos, [f"{r['few_below']}/{r['many_above']} (n = {r['n_few']})" for r in rows], fontsize=9.1)
    ax.set_ylim(6.6, -1.1); ax.set_xlim(0, 85)
    ax.text(1, -0.75, "Class unknown", fontsize=9.1, ha="left", color=fs.NEUT[0], va="center"); ax.text(1, 3.15, "Class known", fontsize=9.1, ha="left", color=fs.NEUT[0], va="center")
    ax.set_xlabel("Top-1 accuracy (%)"); fs.light_grid(ax, "x")
    ax.scatter([], [], s=14, color=L.FEW, label="Few-shot"); ax.scatter([], [], s=14, color=L.MANY, label="Many-shot")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=9.1)
    ax.set_ylabel("Thresholds (few-shot n)", fontsize=9.1)
    fs.panel_label(ax, "e", dx=-0.42)
    SD.add("2e", pd.DataFrame(rows), source="threshold_sensitivity_rederived.csv")
    # ---- f: adjusted association with frequency
    ax = axs[1][2]
    specs = [("log10 min-frequency only", "Frequency alone"), ("+ edit count, LG flag, class", "+ edits, leaving group, class")]
    rows = []; y = 0; ylab = []; ypos = []
    for si, (mk, nm) in enumerate(specs):
        for sett, filled, dy in [("baseline_unknown", True, -0.16), ("baseline_known", False, 0.16)]:
            r = lr[(lr.setting == sett) & (lr.model == mk)].iloc[0]
            L.ci_point(ax, r.OR_per_10x, y + dy, r.lo, r.hi, fs.INK, filled=filled, s=14, orient="h")
            rows.append(dict(model=nm, setting=sett, OR=r.OR_per_10x, lo=r.lo, hi=r.hi))
        ylab.append(nm); ypos.append(y); y += 1
    for sett, filled, dy in [("baseline_unknown", True, -0.16), ("baseline_known", False, 0.16)]:
        r = lrs[(lrs.setting == sett) & (lrs.term == "logf")].iloc[0]
        L.ci_point(ax, r.OR, y + dy, r.lo, r.hi, fs.INK, filled=filled, s=14, orient="h")
        rows.append(dict(model="+ product similarity", setting=sett, OR=r.OR, lo=r.lo, hi=r.hi))
    ylab.append("+ product similarity"); ypos.append(y)
    ax.set_yticks(ypos, ylab); ax.set_ylim(2.5, -0.6); fs.vline(ax, 1.0)
    ax.set_xscale("log"); ax.set_xticks([1, 1.5, 2, 3], ["1", "1.5", "2", "3"]); ax.set_xlim(0.9, 3.2); ax.minorticks_off()
    ax.set_xlabel("Odds ratio of top-1 success\nper 10-fold more training occurrences")
    L.legend_marker(ax, [("Class unknown", fs.INK, True), ("Class known", fs.INK, False)], loc="lower center", bbox=(0.5, 1.0), ncol=2)
    fs.light_grid(ax, "x"); fs.panel_label(ax, "f", dx=-0.52)
    SD.add("2f", pd.DataFrame(rows), source="logit_exploratory.csv; logit_with_similarity.csv")
    return fig


# ---------------------------------------------------------------- shared extra tables
pt = rd("paired_tests.csv"); pbc = rd("paired_bootstrap_ci.csv"); pp = rd("paired_planning.csv")
req = rd("paired_required_n.csv"); umdd = rd("unpaired_mdd_curve.csv"); odis = rd("observed_discordance.csv")
feat = rd("per_reaction_features.csv")
CLS = {1: "Heteroatom alkylation/arylation", 2: "Acylation and related", 3: "C–C bond formation", 4: "Heterocycle formation",
       5: "Protections", 6: "Deprotections", 7: "Reductions", 8: "Oxidations", 9: "FG interconversion", 10: "FG addition"}
DARK_AMBER = "#9A6B0A"
TXT = {"Many": L.MANY, "Medium": DARK_AMBER, "Few": L.FEW}


def fig3():
    fig, axs = fs.grid("double", 108, 2, 3, wspace=0.55, hspace=0.62, left=0.115, right=0.99, top=0.945, bottom=0.12)
    # a: leverage of each group on the pooled score
    ax = axs[0][0]; rows = []
    for gi, g in enumerate(G3):
        for sett, dy, filled in [("baseline_unknown", -0.19, True), ("baseline_known", 0.19, False)]:
            r = ceil[(ceil.setting == sett) & (ceil.metric == "top1") & (ceil.bucket == g)].iloc[0]
            ax.barh(gi + dy, r.ceiling_pp, height=0.32, color=L.GCOL[g] if filled else "white", edgecolor=L.GCOL[g], lw=0.8)
            ax.annotate(f"+{r.ceiling_pp:.2f}", (r.ceiling_pp, gi + dy), xytext=(3, 0), textcoords="offset points", va="center", fontsize=9.1, color=TXT[g])
            rows.append(dict(group=g, setting=sett, n=int(r.n), ceiling_pp=r.ceiling_pp))
    ax.set_yticks(range(3), [f"{L.GLAB[g].replace('-shot','')}\n{int(ceil[(ceil.bucket == g)].n.iloc[0]):,}" for g in G3], fontsize=9.1)
    ax.set_ylim(2.6, -0.6); ax.set_xlim(0, 52); ax.set_xlabel("Gain in pooled top-1 if group reaches 100% (pp)")
    L.legend_marker(ax, [("Class unknown", fs.INK, True), ("Class known", fs.INK, False)], loc="lower right", bbox=(1.0, 0.1))
    fs.light_grid(ax, "x"); fs.panel_label(ax, "a", dx=-0.36)
    SD.add("3a", pd.DataFrame(rows), source="ceiling_mdd.csv")
    # b: combined medium+few ceiling by top-k
    ax = axs[0][1]; rows = []
    for sett, filled, col in [("baseline_unknown", True, L.FEW), ("baseline_known", False, L.FEW)]:
        d = ceil[(ceil.setting == sett) & (ceil.bucket == "Medium+Few")].set_index("metric").loc[["top1", "top3", "top5", "top10"]]
        ax.plot(range(4), d.ceiling_pp, color=col, lw=0.9, zorder=2, ls="-" if filled else (0, (3, 2)))
        ax.scatter(range(4), d.ceiling_pp, s=15, facecolor=col if filled else "white", edgecolor=col, lw=0.9, zorder=3)
        for i, v in enumerate(d.ceiling_pp):
            ax.annotate(f"{v:.2f}", (i, v), xytext=(0, 4 if filled else -5), textcoords="offset points", ha="center", va="bottom" if filled else "top", fontsize=9.1, color=col)
            rows.append(dict(setting=sett, metric=d.index[i], ceiling_pp=v))
    ax.set_xticks(range(4), ["Top-1", "Top-3", "Top-5", "Top-10"]); ax.set_xlim(-0.4, 3.4); ax.set_ylim(0, 4.0)
    ax.set_ylabel("Gain in pooled accuracy (pp)"); L.tag(ax, "Medium- and few-shot both\nraised to 100%", 0.98, 0.97, ha="right", color=fs.NEUT[0])
    fs.light_grid(ax); fs.panel_label(ax, "b", dx=-0.22)
    SD.add("3b", pd.DataFrame(rows), source="ceiling_mdd.csv")
    # c: unpaired MDD vs n
    ax = axs[0][2]; rows = []
    for p, col, nm in [(0.1346, L.FEW, "Few-shot top-1 baseline, 13.5%"), (0.3846, "#C98A86", "Few-shot top-10 baseline, 38.5%")]:
        d = umdd[umdd.p_base == p]
        ax.plot(d.n, d.mdd_pp, color=col, lw=1.0, marker="o", ms=2.2, zorder=2)
        for n_ in (52, 120):
            v = float(d[d.n == n_].mdd_pp.iloc[0])
            if n_ == 52:
                ax.annotate(f"{v:.1f}", (n_, v), xytext=(7, 3), textcoords="offset points", ha="left", fontsize=9.1, color=L.FEW if p == 0.1346 else "#B06A66", bbox=dict(fc="white", ec="none", pad=0.4))
        rows += [dict(p_base=p, n=int(a), mdd_pp=b) for a, b in zip(d.n, d.mdd_pp)]
    ax.set_xscale("log"); ax.set_xlim(25, 6000); ax.set_ylim(0, 40)
    for n_, lab in [(52, "few\n52"), (120, "medium\n120"), (4832, "many\n4,832")]:
        ax.axvline(n_, color=fs.NEUT[1], lw=0.5, ls=(0, (2, 2)), zorder=0)
        ax.text(n_, 39.3, lab, fontsize=9.1, ha="center", va="top", color=fs.NEUT[0], linespacing=1.05)
    ax.set_xlabel("Reactions per model, n"); ax.set_ylabel("Unpaired MDD, 80% power (pp)")
    L.tag(ax, "13.5% baseline", 0.97, 0.52, ha="right", color=L.FEW); L.tag(ax, "38.5% baseline", 0.97, 0.78, ha="right", color="#C98A86")
    fs.light_grid(ax); fs.panel_label(ax, "c", dx=-0.22)
    SD.add("3c", pd.DataFrame(rows), source="unpaired_mdd_curve.csv")
    # d: paired MDD vs n
    ax = axs[1][0]; rows = []
    cols = ["#BFD7E8", "#8FB8D6", "#5C97C0", "#2C6E9B", "#173F5F"]
    for d_, col in zip([0.05, 0.10, 0.15, 0.20, 0.30], cols):
        t = pp[(pp.discordance == d_)].dropna()
        ax.plot(t.n, t.paired_mdd_pp, color=col, lw=1.0, marker="o", ms=2.2, zorder=3)
        ax.plot([], [], color=col, marker="o", ms=2.2, lw=1.0, label=f"{int(d_*100)}%")
        rows += [dict(discordance=d_, n=int(a), paired_mdd_pp=b) for a, b in zip(t.n, t.paired_mdd_pp)]
    ax.set_xscale("log"); ax.set_xlim(40, 4000); ax.set_ylim(0, 25)
    ax.axhline(5, color=fs.NEUT[0], lw=0.5, ls=(0, (3, 2))); ax.text(3900, 5.4, "5 pp", fontsize=9.1, color=fs.NEUT[0], ha="right")
    for n_ in (52, 120):
        ax.axvline(n_, color=fs.NEUT[1], lw=0.5, ls=(0, (2, 2)), zorder=0)
    ax.set_xlabel("Reactions, n"); ax.set_ylabel("Paired MDD, 80% power (pp)")
    ax.legend(title="Reactions on which\nmodels differ", loc="upper right", fontsize=9.1, title_fontsize=9.1, handlelength=1.5)
    fs.light_grid(ax); fs.panel_label(ax, "d", dx=-0.22)
    SD.add("3d", pd.DataFrame(rows), source="paired_planning.csv")
    # e: observed disagreement
    ax = axs[1][1]; rows = []
    for gi, g in enumerate(G3):
        for mk, dx, filled in [("top1", -0.17, True), ("top10", 0.17, False)]:
            r = odis[(odis.setting == "unknown") & (odis.bucket == g) & (odis.metric == mk)].iloc[0]
            ax.bar(gi + dx, 100 * r.discordance, width=0.3, color=L.GCOL[g] if filled else "white", edgecolor=L.GCOL[g], lw=0.8)
            ax.annotate(f"{100*r.discordance:.1f}", (gi + dx, 100 * r.discordance), xytext=(0, 2), textcoords="offset points", ha="center", fontsize=9.1, color=TXT[g])
            rows.append(dict(group=g, metric=mk, n=int(r.n), discordance_pct=100 * r.discordance))
    ax.set_xticks(range(3), [L.GLAB[g].replace("-shot", "") for g in G3]); ax.set_ylim(0, 26)
    ax.set_ylabel("Reactions where models differ (%)"); ax.set_xlim(-0.55, 2.55)
    L.legend_marker(ax, [("Top-1", fs.INK, True), ("Top-10", fs.INK, False)], loc="upper right", bbox=(1.0, 1.02), ncol=2)
    fs.light_grid(ax); fs.panel_label(ax, "e", dx=-0.22)
    SD.add("3e", pd.DataFrame(rows), source="observed_discordance.csv")
    # f: reactions required
    ax = axs[1][2]; rows = []
    cols = {3.0: "#BFD7E8", 5.0: "#5C97C0", 10.0: "#173F5F"}
    for di, d_ in enumerate([0.10, 0.15, 0.20, 0.30]):
        for k, dl in enumerate([3.0, 5.0, 10.0]):
            r = req[(req.discordance == d_) & (req.delta_pp == dl)].iloc[0]
            ax.bar(di + (k - 1) * 0.26, r.n_required, width=0.24, color=cols[dl])
            ax.annotate(f"{int(r.n_required):,}", (di + (k - 1) * 0.26, r.n_required), xytext=(0, 1.5), textcoords="offset points", ha="center", fontsize=9.1, rotation=90, va="bottom")
            rows.append(dict(discordance=d_, delta_pp=dl, n_required=int(r.n_required)))
    ax.set_yscale("log"); ax.set_ylim(30, 8000); ax.set_xticks(range(4), ["10", "15", "20", "30"])
    ax.axhline(52, color=L.FEW, lw=0.7, ls=(0, (3, 2))); pass
    ax.set_xlabel("Reactions on which models differ (%)"); ax.set_ylabel("Reactions needed, paired test")
    for k, dl in enumerate([3.0, 5.0, 10.0]):
        ax.bar([], [], color=cols[dl], label=f"{int(dl)} pp net gain")
    ax.legend(loc="lower center", bbox_to_anchor=(0.45, 1.0), fontsize=9.1, ncol=3, handlelength=0.8, columnspacing=0.5, handletextpad=0.3)
    fs.light_grid(ax); fs.panel_label(ax, "f", dx=-0.22)
    SD.add("3f", pd.DataFrame(rows), source="paired_required_n.csv")
    return fig


def fig4():
    fig, axs = fs.grid("double", 112, 2, 3, wspace=0.62, hspace=0.55, left=0.10, right=0.985, top=0.945, bottom=0.095, width_ratios=[1, 1, 1.05])
    ks = ["top1", "top3", "top5", "top10"]; kl = ["Top-1", "Top-3", "Top-5", "Top-10"]
    # a,b: few-shot accuracy baseline vs aug
    for ax, sett, letter in [(axs[0][0], "unknown", "a"), (axs[0][1], "known", "b")]:
        rows = []
        for i, k in enumerate(ks):
            rb, ra = A(f"baseline_{sett}", "Few", k), A(f"aug_{sett}", "Few", k)
            ax.plot([rb.pct, ra.pct], [i, i], color=fs.NEUT[1], lw=1.6, zorder=1, solid_capstyle="round")
            L.ci_point(ax, rb.pct, i - 0.14, rb.ci_lo, rb.ci_hi, L.M_BASE, s=13, orient="h", lw=0.7)
            L.ci_point(ax, ra.pct, i + 0.14, ra.ci_lo, ra.ci_hi, L.M_AUG, s=13, orient="h", lw=0.7)
            ax.annotate(f"{ra.pct - rb.pct:+.1f} pp ({int(ra.k - rb.k):+d})", (99, i), ha="right", va="center", fontsize=9.1, color=fs.INK)
            rows += [dict(setting=sett, model="Graph2Edits", metric=k, n=int(rb.n), k=int(rb.k), pct=rb.pct, ci_lo=rb.ci_lo, ci_hi=rb.ci_hi),
                     dict(setting=sett, model="Graph2Edits-Aug", metric=k, n=int(ra.n), k=int(ra.k), pct=ra.pct, ci_lo=ra.ci_lo, ci_hi=ra.ci_hi)]
        ax.set_yticks(range(4), kl); ax.set_ylim(3.6, -0.6); ax.set_xlim(0, 100); ax.set_xticks([0, 20, 40, 60, 80]); ax.set_xlabel("Few-shot accuracy, n = 52 (%)")
        ax.set_title("Class " + sett, fontsize=9.1, color=fs.NEUT[0], pad=2)
        fs.light_grid(ax, "x"); fs.panel_label(ax, letter, dx=-0.26 if letter == "a" else -0.18)
        SD.add("4" + letter, pd.DataFrame(rows), source="acc_by_bucket.csv")
    axs[0][1].scatter([], [], s=13, color=L.M_BASE, label="Graph2Edits"); axs[0][1].scatter([], [], s=13, color=L.M_AUG, label="Graph2Edits-Aug")
    axs[0][1].legend(loc="lower left", bbox_to_anchor=(0.0, 0.0), ncol=1, fontsize=9.1)
    # c: discordant pairs, few-shot
    ax = axs[0][2]; rows = []
    y = 0; yt = []; yl = []
    for sett in ["unknown", "known"]:
        for k in ks:
            r = pt[(pt.setting == sett) & (pt.bucket == "Few") & (pt.metric == k)].iloc[0]
            ax.barh(y, -r.base_only, height=0.62, color=L.M_BASE); ax.barh(y, r.aug_only, height=0.62, color=L.M_AUG)
            ax.annotate(f"{int(r.base_only)}", (-r.base_only, y), xytext=(-2.5, 0), textcoords="offset points", ha="right", va="center", fontsize=9.1)
            ax.annotate(f"{int(r.aug_only)}", (r.aug_only, y), xytext=(2.5, 0), textcoords="offset points", ha="left", va="center", fontsize=9.1)
            yt.append(y); yl.append(("Class unknown · " if sett == "unknown" and k == "top1" else ("Class known · " if sett == "known" and k == "top1" else "")) + k.replace("top", "Top-"))
            rows.append(dict(setting=sett, metric=k, baseline_only=int(r.base_only), aug_only=int(r.aug_only), p_exact=r.p_exact))
            y += 1
        y += 0.6
    ax.set_yticks(yt, yl, fontsize=9.1); ax.set_ylim(y - 0.6, -0.7); ax.axvline(0, color=fs.INK, lw=0.5)
    ax.set_xlim(-8, 9); ax.set_xticks([-6, -3, 0, 3, 6], ["6", "3", "0", "3", "6"]); ax.set_xlabel("Reactions solved by one model only")
    ax.text(-7.8, -0.45, "Graph2Edits only", fontsize=9.1, color=L.M_BASE, ha="left", va="center"); ax.text(8.8, -0.45, "Aug only", fontsize=9.1, color=L.M_AUG, ha="right", va="center")
    fs.panel_label(ax, "c", dx=-0.62)
    SD.add("4c", pd.DataFrame(rows), source="paired_tests.csv")
    # d: forest of paired differences (class unknown)
    ax = axs[1][0]; rows = []; y = 0; yt = []; yl = []
    for g in ["Many", "Medium", "Few", "All"]:
        for k in ks:
            r = pbc[(pbc.setting == "unknown") & (pbc.bucket == g) & (pbc.metric == k)].iloc[0]
            col = L.GCOL.get(g, fs.INK)
            L.ci_point(ax, r.diff_pp, y, r.lo, r.hi, col, s=11, orient="h", lw=0.8)
            rows.append(dict(group=g, metric=k, diff_pp=r.diff_pp, lo=r.lo, hi=r.hi)); yt.append(y); yl.append(kl[ks.index(k)] if k == "top1" else kl[ks.index(k)]); y += 1
        y += 0.5
    ax.set_yticks(yt, yl, fontsize=9.1); fs.vline(ax, 0); ax.set_ylim(y - 0.5, -0.8)
    for gi, g in enumerate(["Many", "Medium", "Few", "Pooled"]):
        ax.text(-0.02, (gi * 5 + 1.5 + 0.0), "", fontsize=9.1)
    for gi, g in enumerate(["Many-shot", "Medium-shot", "Few-shot", "Pooled"]):
        ax.text(1.0, gi * 4.5 + 1.5, g, transform=ax.get_yaxis_transform(), fontsize=9.1, ha="right", va="center", color=[L.MANY, DARK_AMBER, L.FEW, fs.INK][gi], fontweight="bold")
    ax.set_xlim(-12, 23); ax.set_xlabel("Aug minus Graph2Edits (pp)\npaired bootstrap 95% interval")
    fs.light_grid(ax, "x"); fs.panel_label(ax, "d", dx=-0.30)
    SD.add("4d", pd.DataFrame(rows), source="paired_bootstrap_ci.csv")
    # e: Holm picture
    ax = axs[1][1]
    d = pt.sort_values("p_exact").reset_index(drop=True); d["i"] = np.arange(1, len(d) + 1); d["crit"] = 0.05 / (len(d) - d.i + 1)
    ax.plot(d.i, d.crit, color=fs.NEUT[0], lw=0.8, drawstyle="steps-mid", zorder=1)
    cols_ = [L.FEW if (r.bucket == "Few" and r.metric == "top10" and r.setting == "unknown") else fs.NEUT[0] for r in d.itertuples()]
    ax.scatter(d.i, d.p_exact.clip(lower=1e-3), s=9, c=cols_, zorder=3, lw=0)
    ax.axhline(0.05, color=fs.NEUT[1], lw=0.5, ls=(0, (2, 2)))
    ax.set_yscale("log"); ax.set_ylim(8e-4, 1.4); ax.set_xlim(0, 33)
    ax.text(32.5, 0.05 * 1.12, "α = 0.05", fontsize=9.1, color=fs.NEUT[0], ha="right")
    ax.text(8, 0.0050, "Holm threshold", fontsize=9.1, color=fs.NEUT[0], ha="left", va="bottom")
    fe = d[(d.setting == "unknown") & (d.bucket == "Few") & (d.metric == "top10")].iloc[0]
    ax.annotate(f"few-shot top-10\nraw p = {fe.p_exact:.3f}\nHolm p = {fe.p_holm:.2f}", (fe.i, fe.p_exact), xytext=(9, 11), textcoords="offset points", fontsize=9.1, color=L.FEW, arrowprops=dict(arrowstyle="-", lw=0.5, color=L.FEW), va="bottom")
    ax.set_xlabel("Comparisons ranked by raw p"); ax.set_ylabel("Exact McNemar p")
    fs.light_grid(ax); fs.panel_label(ax, "e", dx=-0.26)
    SD.add("4e", d[["i", "setting", "bucket", "metric", "base_only", "aug_only", "p_exact", "p_holm", "crit"]], source="paired_tests.csv")
    # f: heat map of net successes
    ax = axs[1][2]
    M = []; rowl = []
    for sett in ["unknown", "known"]:
        for g in G3:
            M.append([pt[(pt.setting == sett) & (pt.bucket == g) & (pt.metric == k)].iloc[0].aug_k - pt[(pt.setting == sett) & (pt.bucket == g) & (pt.metric == k)].iloc[0].base_k for k in ks])
            rowl.append(f"{'U' if sett == 'unknown' else 'K'} · {g}")
    M = np.array(M, float)
    vheat(ax, M, fs.CMAP_DIV, -40, 40)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{int(M[i, j]):+d}", ha="center", va="center", fontsize=9.1, color=fs.INK)
    ax.set_xticks(range(4), kl); ax.set_yticks(range(6), rowl, fontsize=9.1); ax.tick_params(length=0)
    ax.axhline(2.5, color="white", lw=2)
    for sp in ax.spines.values(): sp.set_visible(False)
    ax.set_title("Net extra successes (Aug − Graph2Edits)", fontsize=9.1, color=fs.NEUT[0], pad=3)
    ax.text(0.5, -0.19, "U, class unknown; K, class known", transform=ax.transAxes, fontsize=9.1, ha="center", color=fs.NEUT[0])
    fs.panel_label(ax, "f", dx=-0.30)
    SD.add("4f", pd.DataFrame(M, index=rowl, columns=ks).reset_index().rename(columns={"index": "row"}), source="paired_tests.csv")
    return fig


def fig5():
    fig = plt.figure(figsize=(180 / 25.4, 112 / 25.4))
    gt = fig.add_gridspec(1, 2, left=0.215, right=0.99, top=0.935, bottom=0.60, wspace=0.52, width_ratios=[1.25, 1])
    gb = fig.add_gridspec(1, 3, left=0.085, right=0.99, top=0.455, bottom=0.095, wspace=0.62)
    ax_a = fig.add_subplot(gt[0, 0]); ax_b = fig.add_subplot(gt[0, 1])
    ax_c = fig.add_subplot(gb[0, 0]); ax_d = fig.add_subplot(gb[0, 1]); ax_e = fig.add_subplot(gb[0, 2])
    # a: composition by class
    ax = ax_a; rows = []
    for ci, c in enumerate(range(1, 11)):
        sub = feat[feat.class_number_1_based == c]; n = len(sub); left = 0
        for g in G3:
            w = 100 * (sub.bucket == g).sum() / n
            ax.barh(ci, w, left=left, height=0.7, color=L.GCOL[g], lw=0)
            if g != "Many" and (sub.bucket == g).sum() > 0 and w > 3.4:
                ax.text(left + w / 2, ci, f"{int((sub.bucket == g).sum())}", ha="center", va="center", fontsize=9.1, color="white", fontweight="bold")
            rows.append(dict(cls=c, group=g, n=int((sub.bucket == g).sum()), share_pct=w)); left += w
        ax.text(101.5, ci, f"{n:,}", fontsize=9.1, va="center", color=fs.NEUT[0])
    ax.set_yticks(range(10), [f"{c}  {CLS[c]}" for c in range(1, 11)], fontsize=9.1); ax.set_ylim(9.6, -0.6); ax.set_xlim(0, 112)
    ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xlabel("Share of class test reactions (%); white numbers: medium-shot / few-shot counts"); ax.text(101.5, -0.95, "n", fontsize=9.1, color=fs.NEUT[0], va="bottom")
    for g, x in [("Many", 0.15), ("Medium", 0.37), ("Few", 0.60)]:
        pass
    ax.scatter([], [], s=12, marker="s", color=L.MANY, label="Many"); ax.scatter([], [], s=12, marker="s", color=L.MEDIUM, label="Medium"); ax.scatter([], [], s=12, marker="s", color=L.FEW, label="Few")
    ax.legend(loc="lower center", bbox_to_anchor=(0.45, 1.0), ncol=3, fontsize=9.1, handletextpad=0.1)
    fs.panel_label(ax, "a", dx=-0.52); SD.add("5a", pd.DataFrame(rows), source="per_reaction_features.csv")
    # b: per-class top-1 by group (baseline unknown) heat map
    ax = ax_b; M = np.full((10, 3), np.nan); N = np.zeros((10, 3), int); rows = []
    for ci, c in enumerate(range(1, 11)):
        for gi, g in enumerate(G3):
            sub = feat[(feat.class_number_1_based == c) & (feat.bucket == g)]
            N[ci, gi] = len(sub)
            if len(sub) >= 5: M[ci, gi] = 100 * sub.baseline_unknown_top1.mean()
            rows.append(dict(cls=c, group=g, n=len(sub), top1_pct=M[ci, gi]))
    vheat(ax, M, fs.CMAP_BLUE, 0, 80)
    for i in range(10):
        for j in range(3):
            if np.isnan(M[i, j]):
                ax.text(j, i, f"n = {N[i, j]}" if N[i, j] else "–", ha="center", va="center", fontsize=9.1, color=fs.NEUT[0])
            else:
                ax.text(j, i, f"{M[i, j]:.0f}  ({N[i, j]})", ha="center", va="center", fontsize=9.1, color="white" if M[i, j] > 45 else fs.INK)
    ax.set_xticks(range(3), ["Many", "Medium", "Few"]); ax.set_yticks(range(10), [str(c) for c in range(1, 11)], fontsize=9.1); ax.tick_params(length=0)
    for sp in ax.spines.values(): sp.set_visible(False)
    ax.set_title("Top-1 accuracy, % (n); cells with n < 5 not shown", fontsize=9.1, color=fs.NEUT[0], pad=3); ax.set_ylabel("Reaction class")
    fs.panel_label(ax, "b", dx=-0.22); SD.add("5b", pd.DataFrame(rows), source="per_reaction_features.csv")
    # c: descriptors
    ax = ax_c; rows = []
    for gi, g in enumerate(G3):
        sub = feat[feat.bucket == g]
        for k, (col, lab, dx, filled) in enumerate([("has_leaving_group_edit", "Leaving-group edit", -0.2, True), ("has_unseen_edit", "Unseen edit label", 0.2, False)]):
            v = 100 * sub[col].mean()
            ax.bar(gi + dx, v, width=0.36, color=L.GCOL[g] if filled else "white", edgecolor=L.GCOL[g], lw=0.8)
            ax.annotate(f"{v:.1f}", (gi + dx, v), xytext=(0, 2), textcoords="offset points", ha="center", fontsize=9.1, color=TXT[g])
            rows.append(dict(group=g, feature=lab, pct=v, n=len(sub)))
    ax.set_xticks(range(3), ["Many", "Medium", "Few"]); ax.set_ylim(0, 125); ax.set_yticks([0, 25, 50, 75, 100]); ax.set_ylabel("Reactions (%)"); ax.set_xlim(-0.6, 2.6)
    L.legend_marker(ax, [("Leaving-group edit", fs.INK, True), ("Unseen edit label", fs.INK, False)], loc="upper left", bbox=(0.0, 1.02), size=4.8)
    fs.light_grid(ax); fs.panel_label(ax, "c", dx=-0.34); SD.add("5c", pd.DataFrame(rows), source="per_reaction_features.csv")
    # d: nearest-neighbour similarity
    ax = ax_d
    grp = {g: feat[feat.bucket == g].product_nn_tanimoto.values for g in G3}
    rngp = np.random.default_rng(7)
    shown = {g: (rngp.choice(v, 150, replace=False) if len(v) > 150 else v) for g, v in grp.items()}
    fs.raincloud(ax, shown, [L.MANY, L.MEDIUM, L.FEW], orient="v", point_size=2.5)
    for gi, g in enumerate(G3):
        ax.text(gi, 0.115, f"median {np.median(grp[g]):.2f}", ha="center", fontsize=9.1, color=fs.NEUT[0])
    ax.set_ylabel("Nearest training product,\nTanimoto similarity"); ax.set_ylim(0.1, 1.02)
    fs.light_grid(ax); fs.panel_label(ax, "d", dx=-0.34)
    SD.add("5d", pd.DataFrame({"group": sum([[g] * len(v) for g, v in grp.items()], []), "nn_tanimoto": np.concatenate(list(grp.values()))}), source="per_reaction_features.csv")
    # e: unseen-label sensitivity
    ax = ax_e; rows = []; y = 0; yt = []; yl = []
    for sett in ["unknown", "known"]:
        col = f"baseline_{sett}_top1"
        for lab, sub, c_ in [("Many", feat[feat.bucket == "Many"], L.MANY), ("Few, all", feat[feat.bucket == "Few"], L.FEW), ("Few, seen labels", feat[(feat.bucket == "Few") & (feat.has_unseen_edit == 0)], L.FEW)]:
            k = int(sub[col].sum()); n = len(sub); lo, hi = L_wilson(k, n)
            L.ci_point(ax, 100 * k / n, y, 100 * lo, 100 * hi, c_, filled=(lab != "Few, seen labels"), s=13, orient="h", lw=0.8)
            ax.annotate(f"{100*k/n:.1f}", (100 * hi, y), xytext=(3, 0), textcoords="offset points", va="center", fontsize=9.1)
            rows.append(dict(setting=sett, group=lab, n=n, k=k, pct=100 * k / n, ci_lo=100 * lo, ci_hi=100 * hi)); yt.append(y); yl.append(f"{lab} ({n})"); y += 1
        y += 0.6
    ax.set_yticks(yt, yl, fontsize=9.1); ax.set_ylim(y - 0.6, -0.7); ax.set_xlim(0, 88); ax.set_xlabel("Top-1 accuracy (%)")
    ax.text(87, 0.9, "Class unknown", fontsize=9.1, ha="right", color=fs.NEUT[0]); ax.text(87, 4.5, "Class known", fontsize=9.1, ha="right", color=fs.NEUT[0])
    fs.light_grid(ax, "x"); fs.panel_label(ax, "e", dx=-0.72); SD.add("5e", pd.DataFrame(rows), source="per_reaction_features.csv")
    return fig


def L_wilson(k, n, z=1.959963984540054):
    p = k / n; den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h


# Preview-specific text placement is in the adjacent typography module.
