import json, math, sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from figkit.svgkit import Fig, INK, GREY, LIGHT, MID
from figkit import icons as I

PAN = ROOT / "source_data" / "figure_panels"; P = "source_data_fig1_fig2_fig3_fig4_fig5_"
MANY, MED, FEW = "#2C6E9B", "#E0A33A", "#C8423B"
TINTS = {MANY: "#E3EDF4", MED: "#FBF0DC", FEW: "#F8E3E1", GREY: "#F2F2F2"}
comp = pd.read_csv(PAN / f"{P}1_composition.csv"); top1 = pd.read_csv(PAN / f"{P}1_top1_by_group.csv")
ceil = pd.read_csv(PAN / f"{P}1_ceiling.csv"); power = pd.read_csv(PAN / f"{P}1_power.csv")
rank = pd.read_csv(PAN / f"{P}1_rank_frequency.csv")
COL = {"Many": MANY, "Medium": MED, "Few": FEW}


def build():
    f = Fig(180, 124)
    def card(x, y, w, h, c, r=1.6, sw=0.3): f.card(x, y, w, h, c, r=r, sw=sw, fill=TINTS.get(c))
    def mol(smi, x, y, w, h): f.g(I.rdkit_mol(smi, int(w * 10), int(h * 10), bw=1.3), x, y, 1.0)

    # ---------- a: evaluation set and the pooled score ----------
    f.panel_letter(1, 5, "a"); f.text(6.5, 5, "The pooled score", size=6.5, bold=True)
    f.g(I.database(MANY), 1.5, 8.5, 1.35)
    f.text(16.5, 14.2, "USPTO-50K test set", size=6, bold=True)
    f.text(16.5, 18.2, "5,004 reactions evaluated", size=5)
    f.text(16.5, 21.8, "39,985 for training", size=5, c=GREY)
    x0, y0, W = 3, 28, 44; sh = comp.share_pct.tolist(); xs = x0
    for g, s_ in zip(["Many", "Medium", "Few"], sh):
        w = W * s_ / 100; f.rect(xs, y0, w, 6, fill=COL[g], stroke="none", sw=0); xs += w
    f.text(x0 + 1, y0 + 4.2, "96.6% many-shot", size=5, c="#FFFFFF", bold=True)
    f.line(x0 + W * 0.9783, y0 + 6, x0 + W * 0.9783 - 3, y0 + 10, c=MED, sw=0.2); f.text(x0 + W * 0.9783 - 3.4, y0 + 12.6, "2.4%", size=5, c="#9A6A0B", anchor="end")
    f.line(x0 + W * 0.9948, y0 + 6, x0 + W * 0.9948 + 0.5, y0 + 10, c=FEW, sw=0.2); f.text(50.5, y0 + 12.6, "1.0%", size=9.1, c=FEW, anchor="end")
    f.arrow(25, 44, 25, 49, c=GREY, sw=0.4, head=1.4)
    f.text(25, 57.5, "55.1%", size=13, bold=True, anchor="middle")
    f.text(25, 61.2, "pooled top-1 accuracy", size=5, anchor="middle", c=GREY)
    f.text(25, 64.6, "Graph2Edits, class unknown", size=5, anchor="middle", c=GREY)

    # ---------- b: the rarest required edit decides the group ----------
    f.panel_letter(52, 5, "b"); f.text(57.5, 5, "A reaction takes the count of its rarest edit", size=6.5, bold=True)
    prod = "O=C(NCc1ccccc1)c1ccccc1"
    rows = [("O=C(Cl)c1ccccc1", "attach  *Cl", "8,655", "many-shot", MANY), ("O=C(c1ccccc1)n1ccnc1", "attach  *n1ccnc1", "16", "few-shot", FEW)]
    for i, (rs, lab, cnt, grp, c) in enumerate(rows):
        yy = 9 + i * 20
        card(53.5, yy, 72, 17.5, c, r=1.8)
        mol(prod, 55, yy + 1.8, 16, 13); f.arrow(72.2, yy + 8.7, 78.5, yy + 8.7, c=INK, sw=0.35, head=1.3)
        f.text(75.3, yy + 6.8, "edit", size=4.4, anchor="middle", c=GREY)
        mol(rs, 80, yy + 1.8, 16, 13)
        f.text(97.5, yy + 5.6, lab, size=5.2, bold=True)
        f.text(97.5, yy + 9.3, f"{cnt} in training", size=5)
        f.rect(97.5, yy + 11.2, 19, 4.4, fill=c, stroke="none", sw=0, r=1.1); f.text(107, yy + 14.3, grp, size=5, c="#FFFFFF", bold=True, anchor="middle")
    f.text(55, 50.5, "Group = smallest training count among the", size=5, c=INK)
    f.text(55, 53.8, "edits a reaction needs (exact match needs all of them)", size=5, c=INK)
    for j, (g, t_) in enumerate([("Many", "many  >100"), ("Medium", "medium  20–100"), ("Few", "few  <20")]):
        xx = 53.5 + j * 24.4; card(xx, 57.5, 23, 6.2, COL[g], r=1.4); f.text(xx + 11.5, 61.6, t_, size=5, bold=True, anchor="middle", c=COL[g] if g != "Medium" else "#8A5A00")

    # ---------- c: rank-frequency ----------
    f.panel_letter(130, 5, "c"); f.text(135.5, 5, "Edit labels are long-tailed", size=6.5, bold=True)
    X0, X1, Y0, Y1 = 142, 177, 11, 54
    ypos = lambda v: Y1 - (math.log10(max(v, 1)) / 4.6) * (Y1 - Y0)
    bw = (X1 - X0) / len(rank)
    for r in rank.itertuples():
        g = "Many" if r.train_count > 100 else ("Medium" if r.train_count >= 20 else "Few")
        yb = ypos(r.train_count); f.rect(X0 + (r.rank - 1) * bw, yb, bw * 0.92, max(Y1 - yb, 0.25), fill=COL[g], stroke="none", sw=0)
    f.line(X0, Y1, X1, Y1, sw=0.25); f.line(X0, Y0, X0, Y1, sw=0.25)
    for v, lab in [(1, "1"), (100, "10²"), (10000, "10⁴")]:
        f.line(X0 - 0.8, ypos(v), X0, ypos(v), sw=0.2); f.text(X0 - 1.4, ypos(v) + 0.9, lab, size=5, anchor="end")
    for v in (20, 100): f.line(X0, ypos(v), X1, ypos(v), c=GREY, sw=0.2, dash="14 10")
    f.text(X1 - 1, ypos(3000) + 1, "41 labels >100", size=5, c=MANY, bold=True, anchor="end")
    f.text(X1 - 1, ypos(45) + 0.2, "21 labels 20–100", size=5, c="#8A5A00", bold=True, anchor="end")
    f.text(X1 - 1, ypos(9) - 0.6, "96 labels <20", size=5, c=FEW, bold=True, anchor="end")
    f.text((X0 + X1) / 2, Y1 + 4.5, "Edit label rank (158 labels)", size=5, anchor="middle")
    f.text(133.5, (Y0 + Y1) / 2 + 12, "", size=5)
    f.raw(f'<text transform="translate({f._u(134.8)} {f._u(Y1 - 4)}) rotate(-90)" font-family="Arial, Helvetica, sans-serif" font-size="{round(9.1*25.4/72*10,2)}" fill="{INK}">Training occurrences</text>')

    # ---------- d: accuracy by group ----------
    oy = 70
    f.panel_letter(1, oy + 5, "d"); f.text(6.5, oy + 5, "Top-1 accuracy by group", size=6.5, bold=True)
    ax0, ax1, ay0, ay1 = 13, 56, oy + 9, oy + 43
    yp = lambda v: ay1 - v / 80 * (ay1 - ay0)
    for v in (0, 40, 80): f.line(ax0 - 0.8, yp(v), ax0, yp(v), sw=0.2); f.text(ax0 - 1.4, yp(v) + 0.9, str(v), size=5, anchor="end")
    f.text(ax1, ay0 + 2.5, "Wilson 95% CI", size=9.1, anchor="end", c=GREY)
    f.line(ax0, ay0, ax0, ay1, sw=0.25); f.line(ax0, ay1, ax1, ay1, sw=0.25)
    f.line(ax0, yp(55.08), ax1, yp(55.08), c=GREY, sw=0.25, dash="14 10"); f.text(ax1, yp(55.08) - 1.0, "pooled 55.1", size=4.8, c=GREY, anchor="end")
    for j, r in enumerate(top1.itertuples()):
        cx = ax0 + 9 + j * 15; c = COL[r.group]
        f.line(cx, yp(r.ci_lo), cx, yp(r.ci_hi), c=c, sw=0.45); f.circle(cx, yp(r.pct), 1.1, fill=c, stroke=c, sw=0.15)
        f.text(cx + 1.8, yp(r.pct) - 0.8, f"{r.pct:.1f}", size=5, c=c if r.group != "Medium" else "#8A5A00", bold=True)
        f.text(cx, ay1 + 3.6, r.group, size=5, anchor="middle"); f.text(cx, ay1 + 6.8, f"n = {int(r.n):,}", size=4.6, anchor="middle", c=GREY)
    f.raw(f'<text transform="translate({f._u(4.6)} {f._u(ay1 + 2)}) rotate(-90)" font-family="Arial, Helvetica, sans-serif" font-size="{round(9.1*25.4/72*10,2)}" fill="{INK}">Top-1 accuracy (%)</text>')

    # ---------- e: ceiling on the pooled score ----------
    f.panel_letter(62, oy + 5, "e"); f.text(67.5, oy + 5, "Ceiling on the pooled score", size=6.5, bold=True)
    vals = [("Few", float(ceil.set_index("group").loc["Few", "ceiling_pp"]), FEW), ("Medium", float(ceil.set_index("group").loc["Medium", "ceiling_pp"]), MED), ("Both", 2.60, INK)]
    bx0, bx1 = 82, 112; sc = (bx1 - bx0) / 3.0
    for k, (nm, v, c) in enumerate(vals):
        yy = oy + 12 + k * 9.5
        f.text(bx0 - 1.5, yy + 4.2, nm, size=5, anchor="end"); f.rect(bx0, yy, v * sc, 6, fill=c, stroke="none", sw=0)
        f.text(bx0 + v * sc + 1.2, yy + 4.3, f"+{v:.2f} pp", size=5, bold=True)
    f.line(bx0, oy + 10, bx0, oy + 40.5, sw=0.25)
    f.g(I.balance(MANY), 63.5, oy + 14, 1.0)
    f.text(86, oy + 46, "perfect tail accuracy adds", size=5, anchor="middle", c=INK); f.text(86, oy + 49.4, "2.6 pp to the pooled score;", size=5, anchor="middle"); f.text(86, oy + 52.8, "many-shot headroom is 42.3 pp", size=5, anchor="middle", c=GREY)

    # ---------- f: detectable gain ----------
    f.panel_letter(122, oy + 5, "f"); f.text(127.5, oy + 5, "Smallest gain detectable", size=6.5, bold=True)
    labs = ["Unpaired", "Paired", "Paired"]; subs = ["n = 52", "n = 52", "n = 500"]; cs = [GREY, MANY, MANY]
    fy0, fy1 = oy + 11, oy + 42; ypf = lambda v: fy1 - v / 30 * (fy1 - fy0)
    for v in (0, 10, 20, 30): f.line(133.2, ypf(v), 134, ypf(v), sw=0.2); f.text(132.6, ypf(v) + 0.9, str(v), size=5, anchor="end")
    f.line(134, fy0, 134, fy1, sw=0.25); f.line(134, fy1, 178, fy1, sw=0.25)
    for k, r in enumerate(power.itertuples()):
        cx = 140 + k * 14.5; f.rect(cx - 4.2, ypf(r.mdd_pp), 8.4, fy1 - ypf(r.mdd_pp), fill=cs[k], stroke="none", sw=0)
        f.text(cx, ypf(r.mdd_pp) - 1, f"{r.mdd_pp:.1f}", size=5, bold=True, anchor="middle")
        f.text(cx, fy1 + 3.6, labs[k], size=5, anchor="middle"); f.text(cx, fy1 + 6.7, subs[k], size=4.6, anchor="middle", c=GREY)
    f.raw(f'<text transform="translate({f._u(125.4)} {f._u(fy1 + 1)}) rotate(-90)" font-family="Arial, Helvetica, sans-serif" font-size="{round(9.1*25.4/72*10,2)}" fill="{INK}">Net gain, 80% power (pp)</text>')
    f.text(150, oy + 52.8, "paired design: 15% correctness discordance", size=4.8, anchor="middle", c=GREY)

    return f
