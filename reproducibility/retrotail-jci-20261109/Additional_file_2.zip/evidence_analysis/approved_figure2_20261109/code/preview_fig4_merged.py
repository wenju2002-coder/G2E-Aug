"""Preview only: merge Figure 4a/b from the archived numerical source.

Run: E:\\anaconda\\python.exe code\\preview_fig4_merged.py
No manuscript files are read for modification or written by this script.
"""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.text import Text
from matplotlib.transforms import Bbox
import pandas as pd

import run_figures as base
import typography
import compact_labels

ROOT = Path(__file__).resolve().parent.parent
APPROVED = ROOT.parent / 'DMKD_文字对比与线宽修正版_20261106'
FONT = FontProperties(fname='C:/Windows/Fonts/ARIALN.TTF', size=9.1)
LABEL_FONT = FontProperties(fname='C:/Windows/Fonts/ARIALN.TTF', size=10)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def protected_files():
    return {
        str(p.relative_to(APPROVED)): digest(p)
        for folder in ['01_Manuscript', '03_LaTeX_Source']
        for p in (APPROVED / folder).rglob('*')
        if p.is_file() and not p.name.startswith('~$')
        and p.suffix.lower() in ['.docx', '.pdf', '.md', '.tex', '.png', '.svg']
    }


def main():
    for name in ['figures', 'verification']:
        (ROOT / name).mkdir(exist_ok=True)
    protected_before = protected_files()
    source = ROOT / 'source_data/analysis_tables/acc_by_bucket.csv'
    source_hash = digest(source)
    ns = base.definitions(ROOT / 'code/make_figures_readable.py')
    fig = ns['fig4']()
    typography.apply(fig, 4)
    compact_labels.apply(fig, 4)
    old_axes = list(fig.axes)
    old_science = json.loads(base.snapshot(fig))
    old_positions = [ax.get_position().bounds for ax in old_axes]
    old_width, old_height = fig.get_size_inches() * 25.4
    left = old_positions[0][0] * old_width
    right = (old_positions[1][0] + old_positions[1][2]) * old_width
    top_y = old_positions[0][1] * old_height

    # Keep the four other scientific panels intact, including existing point
    # annotations, colors, confidence intervals, axis scales and forest spacing.
    fig.delaxes(old_axes[0])
    fig.delaxes(old_axes[1])
    new_width, new_height = 180., 124.
    fig.set_size_inches(new_width / 25.4, new_height / 25.4, forward=True)
    for ax, (x, y, w, h) in zip(old_axes[2:], old_positions[2:]):
        ax.set_position([x, y * old_height / new_height,
                         w, h * old_height / new_height])
    merged_height = 45.
    merged_top = top_y + merged_height
    # Align the upper-right panel with the top of the merged panel; its data
    # rectangle size is not changed.
    pos = old_axes[2].get_position()
    old_axes[2].set_position([pos.x0,
        (merged_top - pos.height * new_height) / new_height,
        pos.width, pos.height])
    for ax, original_label, new_label in zip(old_axes[2:], 'cdef', 'bcde'):
        texts = [t for t in ax.texts if t.get_text() == original_label]
        assert len(texts) == 1
        texts[0].set_text(new_label)
        if new_label == 'b':
            # Do not let the new panel letter sit next to the delta-n heading.
            texts[0].set_position((-.32, 1.07))
    # Re-use the model legend handles, but put the legend in two rows inside
    # the upper-right empty part of the merged accuracy plotting region.
    assert len(fig.legends) == 1
    prior_legend = fig.legends[0]
    legend_handles = prior_legend.legend_handles
    legend_labels = [t.get_text() for t in prior_legend.get_texts()]
    prior_legend.remove()

    # Align only the c/d/e corner labels, not their data rectangles. The
    # forest panel must keep its previously approved 48-mm readable height.
    label_objects = [next(t for t in a.texts if t.get_text() == letter)
                     for a, letter in zip(old_axes[3:], 'cde')]
    positions = [fig.transFigure.inverted().transform(
                    t.get_transform().transform(t.get_position()))
                 for t in label_objects]
    common_label_y = float(positions[1][1])
    assert abs(float(positions[2][1]) - common_label_y) < 1e-12
    for label, position in zip(label_objects, positions):
        label.set_transform(fig.transFigure)
        label.set_position((float(position[0]), common_label_y))

    ax = fig.add_axes([left / new_width, top_y / new_height,
                      (right - left) / new_width, merged_height / new_height])
    fs, learner, lookup = ns['fs'], ns['L'], ns['A']
    rows = []
    y_positions = []
    metric_labels = []
    annotation_boxes = []
    ks = ['top1', 'top3', 'top5', 'top10']
    names = ['Top-1', 'Top-3', 'Top-5', 'Top-10']
    for setting, offset in [('unknown', 0.), ('known', 4.5)]:
        for index, (metric, name) in enumerate(zip(ks, names)):
            y = offset + index
            rb = lookup(f'baseline_{setting}', 'Few', metric)
            ra = lookup(f'aug_{setting}', 'Few', metric)
            assert int(rb.n) == int(ra.n) == 52
            ax.plot([rb.pct, ra.pct], [y, y], color=fs.NEUT[1],
                    lw=1.6, zorder=1, solid_capstyle='round')
            for record, model, color, shift in [
                    (rb, 'Graph2Edits', learner.M_BASE, -.15),
                    (ra, 'Graph2Edits-Aug', learner.M_AUG, .15)]:
                learner.ci_point(ax, record.pct, y + shift,
                    record.ci_lo, record.ci_hi, color, s=13, orient='h', lw=.7)
                rows.append(dict(setting=setting, model=model, metric=metric,
                    n=int(record.n), k=int(record.k), pct=float(record.pct),
                    ci_lo=float(record.ci_lo), ci_hi=float(record.ci_hi)))
            # The two delta columns are separate from the accuracy plotting
            # region. No floating two-line parenthetical point annotations.
            difference = float(ra.pct - rb.pct)
            delta_k = int(ra.k - rb.k)
            if abs(difference) < 1e-10:
                difference = 0.
            for x, text in [(100., f'{difference:+.1f}'), (113., f'{delta_k:+d}')]:
                annotation_boxes.append(ax.text(x, y, text, ha='right',
                    va='center', fontproperties=FONT, color=fs.INK))
            y_positions.append(y)
            metric_labels.append(name)
        ax.text(-.13, offset + 1.5, 'Class ' + setting,
            transform=ax.get_yaxis_transform(), rotation=90, ha='center',
            va='center', fontproperties=FONT, color='#595959', clip_on=False)

    ax.set_xlim(0, 115)
    ax.set_ylim(8.15, -.65)
    ax.set_yticks(y_positions, metric_labels, fontproperties=FONT)
    ax.set_xticks([0, 20, 40, 60, 80])
    for label in ax.get_xticklabels():
        label.set_fontproperties(FONT)
    ax.set_xlabel('Few-shot accuracy, n = 52 (%)', fontproperties=FONT, labelpad=4)
    ax.xaxis.set_label_coords(40 / 115, -.13)
    ax.spines['bottom'].set_bounds(0, 80)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    fs.light_grid(ax, 'x')
    ax.axvline(84, color='#D4D7DB', lw=.5)
    ax.axhline(3.75, color='#D4D7DB', lw=.5)
    for x, heading in [(100., 'Δ (pp)'), (113., 'Δn')]:
        ax.text(x / 115, 1.025, heading, transform=ax.transAxes,
            ha='right', va='bottom', fontproperties=FONT, color=fs.INK)
    ax.text(-.105, 1.07, 'a', transform=ax.transAxes,
        fontproperties=LABEL_FONT, va='bottom', ha='left', color=fs.INK)
    model_legend = ax.legend(legend_handles, legend_labels,
        loc='upper right', bbox_to_anchor=(80 / 115, .995), ncol=1,
        prop=FONT, frameon=False, borderaxespad=.12,
        handlelength=.8, handletextpad=.35, labelspacing=.3)

    merged_data = pd.DataFrame(rows)
    expected = pd.concat([ns['SD'].panels['4a']['df'],
                          ns['SD'].panels['4b']['df']], ignore_index=True)
    pd.testing.assert_frame_equal(merged_data, expected,
                                  check_dtype=False, check_exact=True)
    merged_data.to_csv(ROOT / 'source_data/Fig4a_merged_plotted_values.csv', index=False)
    new_science = json.loads(base.snapshot(fig))
    assert new_science[:4] == old_science[2:], 'Other scientific panels changed'
    # Check all actual new markers/interval endpoints, not just exported tables.
    assert len(ax.collections) == 16
    for scatter, row, y in zip(ax.collections, rows,
                              [p + shift for p in y_positions for shift in [-.15, .15]]):
        assert scatter.get_offsets().tolist() == [[row['pct'], y]]
    ci_lines = [line for i, line in enumerate(ax.lines[:24]) if i % 3 in [1, 2]]
    assert len(ci_lines) == 16
    for line, row in zip(ci_lines, rows):
        assert list(line.get_xdata()) == [row['ci_lo'], row['ci_hi']]

    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    label_y = [t.get_window_extent(renderer).y0 for t in label_objects]
    assert max(label_y) - min(label_y) < 1e-9, 'c/d/e labels are not aligned'
    legend_box = model_legend.get_window_extent(renderer)
    # The legend must stay clear of all actual points/CI segments and deltas.
    for scatter in ax.collections:
        for point in ax.transData.transform(scatter.get_offsets()):
            assert not legend_box.padded(3 * fig.dpi / 72).contains(*point), 'Legend crowds a point'
    for line in ci_lines:
        coordinates = ax.transData.transform(list(zip(line.get_xdata(), line.get_ydata())))
        line_box = Bbox.from_extents(coordinates[:, 0].min(), coordinates[:, 1].min(),
                                    coordinates[:, 0].max(), coordinates[:, 1].max())
        assert not legend_box.overlaps(line_box.padded(1 * fig.dpi / 72)), 'Legend crosses a confidence interval'
    for text in annotation_boxes:
        assert not legend_box.overlaps(text.get_window_extent(renderer)), 'Legend crosses delta text'
    outside = []
    for text in fig.findobj(Text):
        if not text.get_visible() or not text.get_text().strip():
            continue
        skip = any((text in a.get_xticklabels() and not min(a.get_xlim()) <= text.get_position()[0] <= max(a.get_xlim()))
                or (text in a.get_yticklabels() and not min(a.get_ylim()) <= text.get_position()[1] <= max(a.get_ylim()))
                for a in fig.axes)
        if skip:
            continue
        box = text.get_window_extent(renderer)
        if box.x0 < -.5 or box.y0 < -.5 or box.x1 > width + .5 or box.y1 > height + .5:
            outside.append(text.get_text())
    assert not outside, outside
    for i, text in enumerate(annotation_boxes):
        box = text.get_window_extent(renderer)
        for other in annotation_boxes[i + 1:]:
            assert not box.overlaps(other.get_window_extent(renderer)), 'Delta labels overlap'
    for extension in ['pdf', 'svg', 'png']:
        fig.savefig(ROOT / f'figures/Fig4_ab_merged_preview.{extension}',
                    dpi=300, facecolor='white')
    # Detail crop is generated directly from the same Matplotlib figure.
    # Hide neighboring panels rather than leaving their cropped letters/ticks.
    # The axes-anchored two-row legend also stays put in the detail crop.
    for other_ax in old_axes[2:]:
        other_ax.set_visible(False)
    fig.savefig(ROOT / 'figures/Fig4a_merged_detail.png', dpi=300,
        facecolor='white', bbox_inches=Bbox.from_extents(0, 58 / 25.4, 118 / 25.4, 124 / 25.4))
    for other_ax in old_axes[2:]:
        other_ax.set_visible(True)
    assert digest(source) == source_hash
    assert protected_files() == protected_before, 'An approved manuscript file changed'
    report = dict(preview_only=True, manuscript_unchanged=True,
        protected_file_count=len(protected_before), protected_files=protected_before,
        source_data_sha256=source_hash, source_data_unchanged=True,
        merged_16_points_and_intervals_exactly_match_source=True,
        other_four_panels_scientific_artists_unchanged=True,
        panel_mapping={'a': 'original a + b', 'b': 'original c',
                       'c': 'original d', 'd': 'original e', 'e': 'original f'},
        original_canvas_mm=[180, 118], preview_canvas_mm=[180, 124],
        original_accuracy_0_to_80_width_mm=float(old_positions[0][2] * 180 * .8),
        merged_accuracy_0_to_80_width_mm=float((right - left) * 80 / 115),
        delta_annotation_definition='Graph2Edits-Aug minus Graph2Edits; pp = percentage points; Δn = additional solved reactions',
        text_outside_canvas=outside, delta_labels_nonoverlapping=True,
        model_legend_rows=2, model_legend_position='upper-right within panel a accuracy region',
        model_legend_clear_of_points_intervals_and_deltas=True,
        bottom_panel_labels_aligned=True, bottom_panel_label_y_mm=common_label_y * new_height,
        forest_panel_height_mm=float(old_axes[3].get_position().height * new_height),
        min_font_pt=min(t.get_fontsize() for t in fig.findobj(Text)
                        if t.get_visible() and t.get_text().strip()))
    (ROOT / 'verification/preview_checks.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print(json.dumps({k: v for k, v in report.items() if k != 'protected_files'},
                     ensure_ascii=False, indent=2))
    plt.close(fig)


if __name__ == '__main__':
    main()
