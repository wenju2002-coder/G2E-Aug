**【figkit：论文图件手写 SVG 工具包】**

本目录随论文包分发（复制到包内 `scripts/figkit/`），一条命令重绘；不依赖外部服务。

**【一、组成】**

1).`svgkit.py`：`Fig(w_mm, h_mm)` 毫米画布。基元：`rect card line path circle arrow text panel_letter bracket_box g`。`save(base)` 写 `.svg`，并经无头 Chromium 打印出嵌字 PDF（无 Type 3）与 600 dpi PNG（rsvg-convert）。文字一律保留为 `<text>`，字体 Arial。

2).`icons.py`：25 个原创扁平图标（试管架、培养皿、孔板、小鼠、细胞、蛋白卡通、抗体、DNA、芯片、数据库、文档、烧瓶、漏斗、盾牌、放大镜、网络、天平、锁、小柱图、对错号、问号、树、药丸、植物）与 `rdkit_mol(smiles,w,h)`。每个图标 100×100 单位，`Fig.g(icon, x_mm, y_mm, s)` 里 `s=1.0` 约 10 mm。需要新对象就在论文包内自己加函数，风格对齐：2 pt 描边、扁平填色、无渐变与阴影。

3).`paper_check.py`：论文包对新版规范的机检。`python3 -I paper_check.py <包目录>`，FAIL 须清零，WARN 须在说明里交代。

**【二、图件规格（执行时以 NC 现行指南为准）】**

1).画布单栏 88 mm、双栏 180 mm，高 ≤170 mm。图内字 5–7 pt，面板字母 8 pt 粗体小写。配色：本文用强调色（红 `#C0392B`），最强基线用蓝，其余中性灰；同条件全篇同色。

2).主图每张 4–8 个面板，先定唯一核心信息再选图型。数据面板由 CSV 驱动，真实结果回来只换 CSV 重跑；示意面板由图标与基元拼装，不用阴影、滤镜、Canvas、渐变。

3).目标稿预设图：整图预设用 `Fig.bracket_box` 在图像对象外画可见 `[ ]`，图题与图注也括起来；图内不加 PRESET、实验编号、水印。

4).GPT-Image 草图只借构图、对象摆放、配色与隐喻，像素与轮廓不进终稿，不做任何自动描摹。草图与提示词存包内 `sketches/`，供 AI 披露声明使用。生成走 `资产库/科研绘图资产库/tools/codex_panel.sh --purpose reference`（已修：只取本会话自己的出图，限流自动重试）。出图失败（429）时在 `sketches/SKETCH_STATUS.md` 写明次数与时间，不得拿旧图或别人的图充数。

**【三、最小范例】**

```python
import sys; sys.path.insert(0, "scripts")
from figkit.svgkit import Fig, RED, BLUE
from figkit import icons as I
f = Fig(180, 60)
f.panel_letter(1, 5, "a"); f.card(0, 8, 60, 40, RED)
f.g(I.mouse(), 5, 14, 1.4); f.text(30, 20, "Xenograft", size=6, bold=True)
f.save("figures/Fig1_overview")
```

完整范例：`PI3Ka` 包 `scripts/make_fig1_svg.py`。
