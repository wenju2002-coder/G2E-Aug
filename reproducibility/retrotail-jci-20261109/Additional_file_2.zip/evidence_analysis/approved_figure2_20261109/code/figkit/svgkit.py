"""figkit.svgkit — 手写 SVG 总装：毫米网格、面板字母、卡片、箭头、导出 PDF/PNG。

只产矢量源。文字一律保留为 <text>，字体 Arial/Helvetica，无阴影、无滤镜、无渐变。
用法见同目录 README.md；图标在 icons.py。
"""
from __future__ import annotations
import subprocess, shutil, html
from pathlib import Path

INK = "#222222"; GREY = "#949494"; LIGHT = "#EDEDED"; MID = "#C9C9C9"
BLUE = "#0173B2"; ORANGE = "#DE8F05"; GREEN = "#029E73"; PINK = "#CC78BC"; RED = "#C0392B"
TINT = {BLUE: "#E1EEF6", ORANGE: "#FBEFD9", GREEN: "#DCF0EA", PINK: "#F5E6F2", GREY: "#F2F2F2", RED: "#F7E1DE"}
FONT = "Arial Narrow"
PX = 96 / 25.4  # 1 mm in CSS px


def esc(s: str) -> str:
    return html.escape(str(s), quote=False)


class Fig:
    """画布单位为毫米（viewBox 以 mm×10 记，便于小数）。k=10 单位/mm。"""

    def __init__(self, w_mm: float = 180, h_mm: float = 100, bg: str = "#FFFFFF"):
        self.w, self.h, self.k = w_mm, h_mm, 10
        self.items: list[str] = []
        self.bg = bg
        self._mk = set()

    # ---- 基元 ----
    def _u(self, v):  # mm -> user units
        return round(v * self.k, 2)

    def raw(self, s: str):
        self.items.append(s)

    def g(self, inner: str, x=0, y=0, s=1.0, rot=0, cls: str = "", gid: str = ""):
        t = f'translate({self._u(x)} {self._u(y)}) scale({s})' + (f' rotate({rot})' if rot else '')
        a = f' id="{gid}"' if gid else ''
        self.items.append(f'<g{a} transform="{t}">{inner}</g>')

    def rect(self, x, y, w, h, fill="none", stroke=INK, sw=0.25, r=0, dash=None, op=1):
        d = f' stroke-dasharray="{dash}"' if dash else ''
        o = f' fill-opacity="{op}"' if op != 1 else ''
        self.items.append(f'<rect x="{self._u(x)}" y="{self._u(y)}" width="{self._u(w)}" height="{self._u(h)}" '
                          f'rx="{self._u(r)}" fill="{fill}"{o} stroke="{stroke}" stroke-width="{self._u(sw)}"{d}/>')

    def card(self, x, y, w, h, color=GREY, r=1.6, sw=0.3, dash=None, fill=None):
        self.rect(x, y, w, h, fill=fill or TINT.get(color, "#F5F5F5"), stroke=color, sw=sw, r=r, dash=dash)

    def line(self, x1, y1, x2, y2, c=INK, sw=0.25, dash=None, cap="round"):
        d = f' stroke-dasharray="{dash}"' if dash else ''
        self.items.append(f'<line x1="{self._u(x1)}" y1="{self._u(y1)}" x2="{self._u(x2)}" y2="{self._u(y2)}" '
                          f'stroke="{c}" stroke-width="{self._u(sw)}" stroke-linecap="{cap}"{d}/>')

    def path(self, d_mm: str, fill="none", stroke=INK, sw=0.25, cap="round", join="round"):
        """d_mm 里的数值已是 mm，内部乘 k。仅支持 M L C Q Z H V 绝对命令。"""
        import re
        def f(m):
            return str(round(float(m.group()) * self.k, 2))
        d = re.sub(r"-?\d+\.?\d*", f, d_mm)
        self.items.append(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{self._u(sw)}" '
                          f'stroke-linecap="{cap}" stroke-linejoin="{join}"/>')

    def circle(self, cx, cy, r, fill="none", stroke=INK, sw=0.25):
        self.items.append(f'<circle cx="{self._u(cx)}" cy="{self._u(cy)}" r="{self._u(r)}" fill="{fill}" '
                          f'stroke="{stroke}" stroke-width="{self._u(sw)}"/>')

    def arrow(self, x1, y1, x2, y2, c=INK, sw=0.3, head=1.4, dash=None):
        import math
        ang = math.atan2(y2 - y1, x2 - x1)
        bx, by = x2 - head * math.cos(ang), y2 - head * math.sin(ang)
        self.line(x1, y1, bx, by, c, sw, dash)
        px, py = -math.sin(ang) * head * 0.45, math.cos(ang) * head * 0.45
        pts = f"{self._u(x2)},{self._u(y2)} {self._u(bx+px)},{self._u(by+py)} {self._u(bx-px)},{self._u(by-py)}"
        self.items.append(f'<polygon points="{pts}" fill="{c}"/>')

    def text(self, x, y, s, size=6, c=INK, bold=False, anchor="start", italic=False, lines: list[str] | None = None, lh=1.18):
        """size 单位 pt。多行用 lines=[...]。"""
        # Darken only the grey text paint, not the GREY drawing constant.
        # Grey arrows, borders, markers and backgrounds retain their colors.
        if c == GREY:
            c = '#595959'
        size = max(9.1, size)
        fs = round(size * 25.4 / 72 * self.k, 2)
        wt = ' font-weight="700"' if bold else ''
        it = ' font-style="italic"' if italic else ''
        if str(s) in ['10²','10⁴']:
            exp = '2' if s == '10²' else '4'
            self.items.append(f'<text x="{self._u(x-1.3)}" y="{self._u(y)}" font-family="{FONT}" font-size="{fs}" fill="{c}" text-anchor="end">10</text>')
            self.items.append(f'<text x="{self._u(x)}" y="{self._u(y-.95)}" font-family="{FONT}" font-size="{fs*.75}" fill="{c}" text-anchor="end">{exp}</text>')
            return
        if lines:
            tsp = "".join(f'<tspan x="{self._u(x)}" dy="{0 if i == 0 else round(fs*lh,2)}">{esc(l)}</tspan>' for i, l in enumerate(lines))
            self.items.append(f'<text x="{self._u(x)}" y="{self._u(y)}" font-family="{FONT}" font-size="{fs}" fill="{c}" text-anchor="{anchor}"{wt}{it}>{tsp}</text>')
        else:
            self.items.append(f'<text x="{self._u(x)}" y="{self._u(y)}" font-family="{FONT}" font-size="{fs}" fill="{c}" text-anchor="{anchor}"{wt}{it}>{esc(s)}</text>')

    def panel_letter(self, x, y, letter):
        self.text(x, y, letter, size=8, bold=True)

    def bracket_box(self, x, y, w, h, c=INK, sw=0.3, arm=2.2):
        """目标稿预设图的可见 [ ] 边界（左右各一）。"""
        for sx, d in ((x, 1), (x + w, -1)):
            self.path(f"M{sx+d*arm} {y} L{sx} {y} L{sx} {y+h} L{sx+d*arm} {y+h}", stroke=c, sw=sw)

    # ---- 输出 ----
    def svg(self) -> str:
        W, H = self._u(self.w), self._u(self.h)
        body = "\n".join(self.items)
        return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" '
                f'width="{self.w}mm" height="{self.h}mm" viewBox="0 0 {W} {H}">\n'
                f'<rect width="{W}" height="{H}" fill="{self.bg}"/>\n{body}\n</svg>\n')

    def save(self, out_base: str | Path, pdf=True, png_dpi=600):
        """写 .svg，并用 rsvg-convert 出嵌字 PDF 与 PNG。返回路径字典。"""
        base = Path(out_base); base.parent.mkdir(parents=True, exist_ok=True)
        sv = base.with_suffix(".svg"); sv.write_text(self.svg(), encoding="utf-8")
        out = {"svg": sv}
        rs = shutil.which("rsvg-convert")
        if pdf:
            out["pdf"] = svg_to_pdf(sv, base.with_suffix(".pdf"), self.w, self.h)
        if rs and png_dpi:
            subprocess.run([rs, "-d", str(png_dpi), "-p", str(png_dpi), "-o", str(base.with_suffix(".png")), str(sv)], check=True)
            out["png"] = base.with_suffix(".png")
        return out


def svg_to_pdf(svg_path, pdf_path, w_mm, h_mm):
    """无头 Chromium 打印：文字嵌为 TrueType/CID，无 Type 3；失败时退回 rsvg-convert（会产 Type 3，须人工留意）。"""
    svg_path, pdf_path = Path(svg_path), Path(pdf_path)
    try:
        from playwright.sync_api import sync_playwright
        page_html = (f'<!doctype html><meta charset="utf-8"><style>@page{{size:{w_mm}mm {h_mm}mm;margin:0}}'
                     f'html,body{{margin:0;padding:0;background:#fff}}svg{{display:block;width:{w_mm}mm;height:{h_mm}mm}}</style>'
                     + svg_path.read_text(encoding="utf-8"))
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page()
            pg.set_content(page_html); pg.pdf(path=str(pdf_path), width=f"{w_mm}mm", height=f"{h_mm}mm", print_background=True, margin=dict(top="0", right="0", bottom="0", left="0"))
            b.close()
        return pdf_path
    except Exception as e:  # noqa
        rs = shutil.which("rsvg-convert")
        subprocess.run([rs, "-f", "pdf", "-o", str(pdf_path), str(svg_path)], check=True)
        print("WARN chromium pdf failed, rsvg fallback (Type 3 risk):", e)
        return pdf_path
