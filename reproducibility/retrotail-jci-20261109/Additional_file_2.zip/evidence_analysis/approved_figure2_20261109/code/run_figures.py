"""Run original plotting definitions with source-code typography changes."""
from pathlib import Path
import sys,json,hashlib,importlib.util,subprocess,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.text import Text
for fn in['arial.ttf','arialbd.ttf','ARIALN.TTF','ARIALNB.TTF','calibri.ttf']:
    font_manager.fontManager.addfont(str(Path('C:/Windows/Fonts')/fn))

DEFAULT=Path('E:/issue_code/G2E-Aug/新建文件夹/张文举_G2E_261102_2022_v03/output/DMKD_原绘图代码字号预览_20261106')
OUT=Path(__file__).resolve().parent.parent if Path(__file__).parent.name=='code'else DEFAULT
sys.stdout.reconfigure(encoding='utf8')

def snapshot(fig):
    def ar(a):
        a=np.ma.asarray(a);return {'v':np.asarray(a.filled(np.nan),dtype=float).tolist(),'mask':np.ma.getmaskarray(a).tolist()}
    result=[]
    for ax in fig.axes:
        o={'xlim':ax.get_xlim(),'ylim':ax.get_ylim(),'xscale':ax.get_xscale(),'yscale':ax.get_yscale(),
            'lines':[[ar(a.get_xdata()),ar(a.get_ydata()),str(a.get_color()),a.get_linestyle(),a.get_marker()]for a in ax.lines],
            'collections':[{'offsets':ar(a.get_offsets()),'paths':[ar(p.vertices)for p in a.get_paths()],'colors':ar(a.get_facecolors())}for a in ax.collections],
            'patches':[]}
        for a in ax.patches:
            v={'path':ar(a.get_path().vertices),'color':a.get_facecolor()}
            for key in['xy','width','height']:
                if hasattr(a,'get_'+key):v[key]=np.asarray(getattr(a,'get_'+key)()).tolist()
            o['patches'].append(v)
        result.append(o)
    return json.dumps(result,sort_keys=True,allow_nan=True,default=lambda a:a.item()if isinstance(a,np.generic)else str(a))

def definitions(path):
    for m in['figstyle','figlocal']:sys.modules.pop(m,None)
    sys.path.insert(0,str(path.parent));args=sys.argv[:]
    sys.argv=[str(path),str(OUT/'source_data/analysis_tables'),str(OUT/'verification')]
    s={'__file__':str(path),'__name__':'drawing_definitions'}
    raw=path.read_text(encoding='utf8').split('\nFIGS = dict(')[0]
    exec(compile(raw,str(path),'exec'),s);sys.argv=args
    return s

def main():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--figures',type=int,nargs='+',default=[2,3,4,5],choices=[2,3,4,5])
    selected=set(parser.parse_args().figures)
    report={}
    original=definitions(OUT/'original_code/make_figures.py');baselines={}
    for n in range(2,6):
        fig=original[f'fig{n}']()
        if n==2:fig.delaxes(fig.axes[0])
        baselines[n]=snapshot(fig);plt.close(fig)
    original_tables={k:v['df'].copy(deep=True)for k,v in original['SD'].panels.items()}
    modified=definitions(OUT/'code/make_figures_readable.py')
    spec=importlib.util.spec_from_file_location('preview_type',OUT/'code/typography.py');ty=importlib.util.module_from_spec(spec);spec.loader.exec_module(ty)
    for n in range(2,6):
        fig=modified[f'fig{n}']()
        if n==2:fig.delaxes(fig.axes[0])
        before=snapshot(fig);assert before==baselines[n],f'Original/new drawing values differ: {n}'
        ty.apply(fig,n);fig.canvas.draw()
        after=snapshot(fig);assert after==before,f'Typography changed a scientific artist: {n}'
        rend=fig.canvas.get_renderer();W,H=fig.canvas.get_width_height()
        outside=[]
        for t in fig.findobj(Text):
            if not t.get_visible()or not t.get_text().strip():continue
            # Matplotlib retains out-of-range log/auto tick objects that the
            # Axis renderer does not draw. They are not clipped figure labels.
            skip=False
            for ax in fig.axes:
                if t in ax.get_xticklabels() and not min(ax.get_xlim())<=t.get_position()[0]<=max(ax.get_xlim()):skip=True
                if t in ax.get_yticklabels() and not min(ax.get_ylim())<=t.get_position()[1]<=max(ax.get_ylim()):skip=True
            if skip:continue
            box=t.get_window_extent(rend)
            if box.x0 < -1 or box.y0 < -1 or box.x1>W+1 or box.y1>H+1:outside.append(t.get_text())
        if n in selected:
            for ext in['svg','pdf','png']:fig.savefig(OUT/f'figures/Fig{n}.{ext}',dpi=300,facecolor='white')
        report[str(n)]={'canvas_mm':(fig.get_size_inches()*25.4).tolist(),'scientific_artists_unchanged':True,
            'scientific_sha256':hashlib.sha256(before.encode()).hexdigest(),'declared_text_min_pt':min(t.get_fontsize()for t in fig.findobj(Text)if t.get_text().strip()and t.get_visible()),
            'text_outside_canvas':outside,'source':'code/make_figures_readable.py + code/typography.py'}
        plt.close(fig)
    assert all(original_tables[k].equals(v['df'])for k,v in modified['SD'].panels.items()if k!='2a')
    sd=modified['SD'];sd.panels.pop('2a',None)
    old=dict(sd.panels);sd.panels={({'2b':'2a','2c':'2c','2d':'2b','2e':'2d','2f':'2e'}.get(k,k)):v for k,v in old.items()}
    sd.write(str(OUT/'source_data/current_plotted_panels'))
    (OUT/'verification/native_plot_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    if Path(__file__).resolve()!=(OUT/'code/run_figures.py').resolve():shutil.copy2(__file__,OUT/'code/run_figures.py')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
