"""Preview only; redraw from unchanged CSVs. Never writes to JCI manuscript.

Run: python code/preview_fig2_encoding.py
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.text import Text
from matplotlib.colors import to_rgba
import run_figures as base
import typography
import compact_labels

ROOT = Path(__file__).resolve().parent.parent

def numeric_snapshot(fig):
    """All line/point/interval coordinates, paths, axes limits and scales."""
    def array(a):
        return np.asarray(np.ma.asarray(a).filled(np.nan), dtype=float).tolist()
    result = []
    for ax in fig.axes:
        result.append(dict(
            limits=[ax.get_xlim(), ax.get_ylim()],
            scales=[ax.get_xscale(), ax.get_yscale()],
            lines=[[array(a.get_xdata()), array(a.get_ydata())] for a in ax.lines],
            collections=[dict(offsets=array(a.get_offsets()),
                              paths=[array(p.vertices) for p in a.get_paths()])
                         for a in ax.collections if len(a.get_offsets())],
            patches=[array(a.get_path().vertices) for a in ax.patches]))
    return json.dumps(result, sort_keys=True, allow_nan=True)

def draw(filename):
    defs = base.definitions(ROOT / 'code' / filename)
    fig = defs['fig2']()
    fig.delaxes(fig.axes[0])
    typography.apply(fig, 2)
    compact_labels.apply(fig, 2)
    return fig, defs

def main():
    for folder in ["figures", "verification"]:
        (ROOT/folder).mkdir(parents=True,exist_ok=True)
    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in (ROOT/'source_data/analysis_tables').glob('*.csv')}
    old, old_defs = draw('original_make_figures_readable.py')
    baseline = numeric_snapshot(old)
    old_tables = {k:v['df'].copy(deep=True) for k,v in old_defs['SD'].panels.items()}
    plt.close(old)
    fig, defs = draw('make_figures_readable.py')
    assert baseline == numeric_snapshot(fig), 'Numerical artists changed'
    assert all(old_tables[k].equals(v['df']) for k,v in defs['SD'].panels.items())

    top, gap, fine, threshold, odds = fig.axes
    top.get_legend().remove()
    odds.get_legend().remove()
    # One shared class-input legend. Preserve all five panel physical bounds.
    old_h, new_h = 118., 126.
    for ax in fig.axes:
        x,y,w,h = ax.get_position().bounds
        ax.set_position([x, y*old_h/new_h, w, h*old_h/new_h])
    fig.set_size_inches(180/25.4, new_h/25.4, forward=True)
    ink = defs['fs'].INK
    handles = [Line2D([], [], marker='o', ls='', markersize=4,
                      markeredgecolor=ink, markeredgewidth=.9,
                      markerfacecolor='white' if unknown else ink,
                      label='Class unknown' if unknown else 'Class known')
               for unknown in [True, False]]
    fig.legend(handles=handles, loc='upper center', bbox_to_anchor=(.5,124.8/126),
               ncol=2, frameon=False, prop=compact_labels.FONT, borderaxespad=0,
               handlelength=.8, handletextpad=.4, columnspacing=1.7)
    # Colour key uses line swatches, not filled dots that could imply class known.
    threshold.get_legend().remove()
    threshold.legend(handles=[Line2D([],[],color=defs['L'].FEW,lw=1.5,label='Few'),
                              Line2D([],[],color=ink,lw=1.5,label='Many')],
                     loc='lower right',bbox_to_anchor=(1,1.035),ncol=2,
                     prop=compact_labels.FONT,frameon=False,borderaxespad=0,
                     handlelength=.8,handletextpad=.3,columnspacing=.7)
    for text in threshold.texts:
        if text.get_text() in ['U','K','Class unknown','Class known']:
            # Class identity is already encoded by fill in the shared legend.
            text.set_visible(False)

    # Verify all 48 data markers follow the declared class encoding.
    settings = [[False,True]*3, [False,True]*4,
                [False]*8+[True]*8, [False]*6+[True]*6, [False,True]*3]
    checked = 0
    for ax, expected in zip(fig.axes,settings):
        points = [c for c in ax.collections if len(c.get_offsets())]
        assert len(points)==len(expected)
        for point, filled in zip(points,expected):
            white = np.allclose(point.get_facecolors()[0],to_rgba('white'))
            assert white != filled
            checked += 1
    assert baseline == numeric_snapshot(fig)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    width,height=fig.canvas.get_width_height()
    outside=[]
    for t in fig.findobj(Text):
        if not t.get_visible() or not t.get_text().strip(): continue
        skip=any((t in ax.get_xticklabels() and not min(ax.get_xlim())<=t.get_position()[0]<=max(ax.get_xlim()))
                 or (t in ax.get_yticklabels() and not min(ax.get_ylim())<=t.get_position()[1]<=max(ax.get_ylim()))
                 for ax in fig.axes)
        if skip: continue
        b=t.get_window_extent(renderer)
        if b.x0<0 or b.y0<0 or b.x1>width or b.y1>height: outside.append(t.get_text())
    assert not outside, outside
    for ext in ['pdf','svg','png']:
        fig.savefig(ROOT/f'figures/Fig2_encoding_preview.{ext}',dpi=300,facecolor='white')
    sd=defs['SD']; sd.panels.pop('2a',None)
    mapping={'2b':'2a','2c':'2c','2d':'2b','2e':'2d','2f':'2e'}
    sd.panels={mapping[k]:v for k,v in sd.panels.items()}
    sd.write(str(ROOT/'source_data/plotted_panels'))
    report=dict(numeric_coordinates_intervals_limits_unchanged=True,
                panel_source_tables_unchanged=True,markers_checked=checked,
                hollow='Class unknown',filled='Class known',
                frequency_colours={'Few':defs['L'].FEW,'Medium':defs['L'].MEDIUM,'Many':ink},
                gap_and_odds_colour='Neutral black; these statistics are not a frequency stratum',
                source_csv_sha256=source_hashes,
                numeric_artist_sha256=hashlib.sha256(baseline.encode()).hexdigest(),
                panel_layout='a/b top, c/d/e bottom; original physical panel bounds preserved',
                canvas_mm=[180,126],text_outside_canvas=outside,
                panel_d_class_text_removed=True,
                manuscript_modified=False)
    (ROOT/'verification/verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report,indent=2))

if __name__=='__main__': main()
