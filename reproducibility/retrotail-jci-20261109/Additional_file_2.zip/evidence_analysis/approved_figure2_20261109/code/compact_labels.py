"""Preview label simplification on live artists, without changing data."""
from matplotlib.font_manager import FontProperties
FONT=FontProperties(fname='C:/Windows/Fonts/ARIALN.TTF',size=9.1)

def legend(ax,labels,xy=(1,1.035)):
    old=ax.get_legend()
    handles=old.legend_handles
    new=ax.legend(handles,labels,loc='lower right',bbox_to_anchor=xy,ncol=2,
        prop=FONT,handlelength=.8,handletextpad=.3,columnspacing=.7,
        borderaxespad=0,labelspacing=.2)
    return new

def apply(fig,n):
    if n==2:
        top,gap,fine,threshold,odds=fig.axes
        # Put panel b's descriptor and sample counts above its plot, keeping
        # the count x positions tied to their original frequency bins.
        fine.xaxis.set_label_position('top')
        fine.xaxis.set_label_coords(.5,1.17)
        fine.xaxis.label.set_verticalalignment('bottom')
        for t in fine.texts:
            if t.get_text().startswith('n='):
                x,_=t.get_position()
                t.set_position((x,1.025))
                t.set_ha('center');t.set_va('bottom')
        gap.set_ylabel('Head-tail gap (pp)',fontproperties=FONT)
        # Explicit placement prevents the ylabel from crowding tick numbers.
        # Only text moves; the panel, data and confidence intervals stay fixed.
        gap.yaxis.set_label_coords(-.22,.5)
        gap.set_xticks(range(4),['1','3','5','10'],fontproperties=FONT)
        gap.set_xlabel('Top-k',fontproperties=FONT,labelpad=4)
        for t in gap.texts:
            if t.get_text()=='Newcombe 95% intervals':
                t.set_text('Newcombe 95% CI')
                t.set_position((.5,1.035));t.set_ha('center');t.set_va('bottom')
        # Keep the actual cutoff values in the panel; place repeated sample
        # sizes and threshold semantics in the proposed caption.
        threshold.set_position([75/180,17/118,42/180,32/118])
        positions=threshold.get_yticks()
        threshold.set_yticks(positions,['10/50','20/100','50/200']*2,fontproperties=FONT)
        threshold.set_xlabel('Top-1 (%)',fontproperties=FONT,labelpad=4)
        for t in threshold.texts:
            if t.get_text()=='Thresholds (few-shot n)':t.set_visible(False)
            elif t.get_text()in ['Unknown','Known']:
                t.set_text('U'if t.get_text()=='Unknown'else'K')
            elif t.get_text().endswith(' pp'):t.set_text(t.get_text()[:-3])
        legend(threshold,['Few','Many'],(1,1.035))
        odds.set_yticks(odds.get_yticks(),['F','F+C','F+C+S'],fontproperties=FONT)
        odds.set_xlabel('Top-1 OR per 10×',fontproperties=FONT,labelpad=4)
        legend(odds,['U','K'],(1,1.035))
    if n==4:
        # Six extra millimetres of top margin house the common model legend.
        # Preserve every other data panel's physical size and position.
        old_height=112
        new_height=118
        old_positions=[ax.get_position().bounds for ax in fig.axes]
        common=fig.axes[1].get_legend()
        handles=common.legend_handles
        labels=[t.get_text()for t in common.get_texts()]
        common.remove()
        fig.set_size_inches(180/25.4,new_height/25.4,forward=True)
        for ax,(x,y,w,h)in zip(fig.axes,old_positions):
            ax.set_position([x,y*old_height/new_height,w,h*old_height/new_height])
        fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(80/180,116.2/118),
            ncol=2,prop=FONT,frameon=False,borderaxespad=0,
            handlelength=.8,handletextpad=.3,columnspacing=.8)
        d=fig.axes[3]
        pos=d.get_position()
        # Use part of the existing row gap without changing the other five
        # data panels. A taller forest increases row
        # separation; positions in data coordinates stay untouched.
        height_mm=48
        d.set_position([pos.x0,pos.y0,pos.width,height_mm/new_height])
        d.set_yticks(d.get_yticks(),['1','3','5','10']*4,fontproperties=FONT)
        d.set_ylabel('Top-k',fontproperties=FONT,labelpad=4)
        d.set_xlabel('Δ accuracy (pp)',fontproperties=FONT,labelpad=4)
        for t in d.texts:
            replacements={'Many-shot':'Many','Medium-shot':'Medium','Few-shot':'Few'}
            if t.get_text()in replacements:t.set_text(replacements[t.get_text()])
