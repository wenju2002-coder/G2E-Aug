from pathlib import Path
import shutil,json,hashlib,sys
ROOT=Path('E:/issue_code/G2E-Aug')
BASE=ROOT/'新建文件夹/张文举_G2E_261102_2022_v03/output'
SRC=BASE/'DMKD_图1位置紧凑版_20261106'
OUT=BASE/'DMKD_图2cde_图4d疏排预览_20261106'
OLD=SRC/'06_修改代码与核对/本轮浅灰文字加深'
def main():
    if OUT.exists():raise RuntimeError('Preserve existing preview')
    OUT.mkdir()
    for folder in ['code','original_code','source_data']:
        shutil.copytree(OLD/folder,OUT/folder,ignore=shutil.ignore_patterns('__pycache__'))
    for folder in ['figures','verification','before']:(OUT/folder).mkdir()
    for n in [2,4]:
        for ext in ['pdf','svg']:
            shutil.copy2(SRC/f'01_Manuscript/fig{n}.{ext}',OUT/f'before/Fig{n}.{ext}')
    protected={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in SRC.rglob('*')if p.is_file()and not p.name.startswith('~')}
    (OUT/'verification/protected.json').write_text(json.dumps(protected,ensure_ascii=False,indent=2),encoding='utf8')
    print(OUT)
if __name__=='__main__':sys.stdout.reconfigure(encoding='utf8');main()
