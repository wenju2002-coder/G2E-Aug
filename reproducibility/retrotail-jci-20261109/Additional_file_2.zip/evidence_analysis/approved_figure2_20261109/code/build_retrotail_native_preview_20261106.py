"""Prepare isolated original-code figure preview; never touch a manuscript."""
from pathlib import Path
import re,shutil,json,hashlib,sys
ROOT=Path('E:/issue_code/G2E-Aug')
BASE=ROOT/'新建文件夹/张文举_G2E_261102_2022_v03'
PKG=BASE/'附件/261101_0658_论文_G2E_CILS重写包/G2E_CILS_rewrite_package'
OUT=BASE/'output/DMKD_原绘图代码字号预览_20261106'

def main():
    for name in['code','original_code','source_data/analysis_tables','source_data/figure_panels','figures','verification']:(OUT/name).mkdir(parents=True,exist_ok=True)
    for name in['make_figures.py','make_fig1_svg.py','figstyle.py','figlocal.py']:
        shutil.copy2(PKG/'scripts'/name,OUT/'original_code'/name)
    shutil.copytree(PKG/'scripts/figkit',OUT/'original_code/figkit',dirs_exist_ok=True)
    for dirname in['analysis_tables','figure_panels']:
        for p in(PKG/'source_data'/dirname).glob('*.csv'):shutil.copy2(p,OUT/'source_data'/dirname/p.name)
    for name in['figstyle.py','figlocal.py']:shutil.copy2(PKG/'scripts'/name,OUT/'code'/name)
    raw=(PKG/'scripts/make_figures.py').read_text(encoding='utf8').split('\ndef fig1():')[0]
    raw=raw.replace('fs.setup()','fs.setup()\nplt.rcParams.update({"font.family":"Arial","font.sans-serif":["Arial"],"font.size":9.1,"axes.titlesize":9.1,"axes.labelsize":9.1,"xtick.labelsize":9.1,"ytick.labelsize":9.1,"legend.fontsize":9.1})')
    raw=re.sub(r'fontsize=(\d+(?:\.\d+)?)',lambda m:'fontsize='+str(max(9.1,float(m[1]))),raw)
    # tag() has explicit tiny sizes in the source; the shared helper handles its floor.
    raw+='\n# Preview-specific text placement is in the adjacent typography module.\n'
    (OUT/'code/make_figures_readable.py').write_text(raw,encoding='utf8')
    loc=(OUT/'code/figlocal.py').read_text(encoding='utf8').replace('fontsize=size,','fontsize=max(9.1,size),')
    (OUT/'code/figlocal.py').write_text(loc,encoding='utf8')
    shutil.copy2(ROOT/'tools/retrotail_native_typography_20261106.py',OUT/'code/typography.py')
    # Figure 1 is rebuilt by its original Fig drawing calls, not by editing an SVG.
    raw=(PKG/'scripts/make_fig1_svg.py').read_text(encoding='utf8').split('    if target:\n')[0]+'    return f\n'
    raw=raw.replace('def build(target: bool):','def build():').replace('Fig(180, 157 if target else 124)','Fig(180, 124)')
    raw=raw.replace('from figkit.svgkit','from figkit.svgkit').replace('round(5*25.4/72*10,2)','round(9.1*25.4/72*10,2)')
    raw=raw.replace('f.text(x0 + W * 0.9948 + 0.8, y0 + 12.6, "1.0%", size=5, c=FEW)','f.text(50.5, y0 + 12.6, "1.0%", size=9.1, c=FEW, anchor="end")')
    for x in['X0 + 14','X0 + 17','X0 + 20']:
        raw=raw.replace('f.text('+x+',','f.text(X1 - 1,')
    for s in['"41 labels >100"','"21 labels 20–100"','"96 labels <20"']:
        # Original callouts stay inside the rank-frequency panel after enlargement.
        raw=re.sub(r'(f\.text\([^\n]*'+re.escape(s)+r'[^\n]*?)\)',r'\1, anchor="end")',raw)
    raw=raw.replace('paired design assumes 15% disagreement','paired design: 15% correctness discordance')
    raw=raw.replace('f._u(ay1 - 6)','f._u(ay1 + 2)').replace('f._u(fy1 - 3)','f._u(fy1 + 1)')
    raw=raw.replace('Top-1 (%), Wilson 95% interval','Top-1 accuracy (%)')
    raw=raw.replace('f.line(ax0, ay0, ax0, ay1, sw=0.25);', 'f.text(ax1, ay0 + 2.5, "Wilson 95% CI", size=9.1, anchor="end", c=GREY)\n    f.line(ax0, ay0, ax0, ay1, sw=0.25);')
    raw=raw.replace('"""Fig. 1 overview,', '"""Evidence-only Fig. 1 overview,')
    raw=raw[raw.index('import json, math, sys'):]
    (OUT/'code/make_fig1_readable.py').write_text(raw,encoding='utf8')
    shutil.copytree(PKG/'scripts/figkit',OUT/'code/figkit',dirs_exist_ok=True)
    svgkit=(OUT/'code/figkit/svgkit.py').read_text(encoding='utf8')
    svgkit=svgkit.replace('FONT = "Arial, Helvetica, sans-serif"','FONT = "Arial Narrow"')
    svgkit=svgkit.replace('fs = round(size * 25.4 / 72 * self.k, 2)','size = max(9.1, size)\n        fs = round(size * 25.4 / 72 * self.k, 2)')
    svgkit=svgkit.replace('        if lines:\n', '''        if str(s) in ['10²','10⁴']:
            exp = '2' if s == '10²' else '4'
            self.items.append(f'<text x="{self._u(x-1.3)}" y="{self._u(y)}" font-family="{FONT}" font-size="{fs}" fill="{c}" text-anchor="end">10</text>')
            self.items.append(f'<text x="{self._u(x)}" y="{self._u(y-.95)}" font-family="{FONT}" font-size="{fs*.75}" fill="{c}" text-anchor="end">{exp}</text>')
            return
        if lines:
''',1)
    (OUT/'code/figkit/svgkit.py').write_text(svgkit,encoding='utf8')
    icons=(OUT/'code/figkit/icons.py').read_text(encoding='utf8')
    icons=icons.replace('o = d.drawOptions();','o = d.drawOptions(); o.fixedFontSize = 129;')
    (OUT/'code/figkit/icons.py').write_text(icons,encoding='utf8')
    protected={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for folder in[PKG/'scripts',BASE/'output/DMKD_术语与补充信息修正版_20261106']for p in folder.rglob('*')if p.is_file()}
    (OUT/'verification/protected_sources.json').write_text(json.dumps(protected,ensure_ascii=False,indent=2),encoding='utf8')
    shutil.copy2(__file__,OUT/'code'/Path(__file__).name)
    print(OUT)

if __name__=='__main__':main()
