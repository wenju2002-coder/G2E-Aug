"""Generate Figure 1 directly through its Fig drawing calls, then convert."""
from pathlib import Path
import sys,hashlib,json,shutil
DEFAULT=Path('E:/issue_code/G2E-Aug/新建文件夹/张文举_G2E_261102_2022_v03/output/DMKD_原绘图代码字号预览_20261106')
OUT=Path(__file__).resolve().parent.parent if Path(__file__).parent.name=='code'else DEFAULT
sys.path.insert(0,str(OUT/'code'))
try:import rdkit
except ImportError:
    if sys.version_info[:2]!=(3,12):raise RuntimeError('Install RDKit in this Python environment before drawing Figure 1')
    sys.path.insert(0,r'E:/issue_code/G2E-Aug/outputs/CILS/CILS_Verified_Submission_2026-10-13_QA/_rdkit_2024')
try:import svglib
except ImportError:sys.path.insert(0,r'E:/issue_code/G2E-Aug/tmp/dmkd_retarget_20261105/libs')
from rdkit import Chem
import rdkit
import make_fig1_readable as src
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
from svglib.fonts import register_font_family
sys.stdout.reconfigure(encoding='utf8')

def main():
    # RDKit is required: do not permit the old icon helper's placeholder fallback.
    mols=['O=C(NCc1ccccc1)c1ccccc1','O=C(Cl)c1ccccc1','O=C(c1ccccc1)n1ccnc1']
    assert all(Chem.MolFromSmiles(s) is not None for s in mols)
    for name,fn in[('Arial','arial.ttf'),('Arial Narrow','ARIALN.TTF'),('Arial-Bold','arialbd.ttf'),('Arial Narrow-Bold','ARIALNB.TTF'),('Helvetica','arial.ttf')]:
        pdfmetrics.registerFont(TTFont(name,str(Path('C:/Windows/Fonts')/fn)))
    for name,fn,bfn in[('Arial','arial.ttf','arialbd.ttf'),('Arial Narrow','ARIALN.TTF','ARIALNB.TTF')]:
        register_font_family(name,str(Path('C:/Windows/Fonts')/fn),str(Path('C:/Windows/Fonts')/bfn))
    f=src.build();svg=f.svg()
    assert svg.count('class=')>0,'Molecule rendering failed'
    (OUT/'figures/Fig1.svg').write_text(svg,encoding='utf8')
    renderPDF.drawToFile(svg2rlg(str(OUT/'figures/Fig1.svg')),str(OUT/'figures/Fig1.pdf'))
    import subprocess
    subprocess.run([r'E:/texlive/2026/bin/windows/pdftoppm.exe','-r','220','-singlefile','-png',str(OUT/'figures/Fig1.pdf'),str(OUT/'figures/Fig1')],check=True,capture_output=True)
    report={'canvas_mm':[180,124],'source':'code/make_fig1_readable.py and code/figkit/',
        'rdkit_version':rdkit.__version__,'molecule_smiles':mols,'rdkit_fixed_font_size_px':129,
        'svg_generated_by_original_drawing_calls':True,'ordinary_text_floor_source_pt':9.1,
        'note':'Illustrative molecules are regenerated from unchanged SMILES with larger atom-label font; molecular drawing geometry can reflow inside the same cards. No test-reaction or experimental values are regenerated.'}
    (OUT/'verification/fig1_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    if Path(__file__).resolve()!=(OUT/'code/run_fig1.py').resolve():shutil.copy2(__file__,OUT/'code/run_fig1.py')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
