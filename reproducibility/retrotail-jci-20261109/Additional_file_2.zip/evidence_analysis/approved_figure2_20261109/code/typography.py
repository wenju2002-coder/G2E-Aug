"""Typography and text placement on live Matplotlib artists, before export.

No exported SVG/PDF is parsed or edited. Coordinates of scientific artists,
axis limits, statistical values, seeds and KDE inputs are not changed.
"""
FONT_FLOOR=9.1
FONT='Arial'

def legends(ax,xy,loc='lower center',ncol=1,title=None):
    old=ax.get_legend()
    if not old:return
    handles=getattr(old,'legend_handles',getattr(old,'legendHandles',[]))
    labels=[t.get_text().replace(' net gain','')for t in old.get_texts()]
    if title is None:title=old.get_title().get_text()
    old.remove()
    return ax.legend(handles,labels,title=title,loc=loc,bbox_to_anchor=xy,ncol=ncol,
        fontsize=FONT_FLOOR,title_fontsize=FONT_FLOOR,handlelength=.8,
        columnspacing=.6,handletextpad=.3,labelspacing=.2,borderaxespad=0)

def apply(fig,n):
    from matplotlib.text import Text,Annotation
    from matplotlib.font_manager import FontProperties
    for t in fig.findobj(Text):
        t.set_fontsize(max(t.get_fontsize(),FONT_FLOOR))
        t.set_fontfamily(FONT);t.set_linespacing(1.12)
    for ax in fig.axes:
        ax.tick_params(labelsize=FONT_FLOOR,pad=1.8)
        for t in ax.get_xticklabels()+ax.get_yticklabels():t.set_fontfamily(FONT)
        for t in ax.texts:
            if t.get_text()in list('abcdef')and t.get_fontweight()=='bold':
                t.set_fontfamily('Arial');t.set_fontsize(10);t.set_fontweight('normal')
        ax.xaxis.labelpad=4;ax.yaxis.labelpad=4
    if n==2:
        # Keep the current five-panel screen positions and canvas exactly.
        top,gap,fine,threshold,odds=fig.axes
        for ax,letter,rect in[(top,'a',(17,73,54,35)),(fine,'b',(94,73,80,35)),(gap,'c',(13,17,41,32)),(threshold,'d',(77,17,40,32)),(odds,'e',(140,17,37,32))]:
            x,y,w,h=rect;ax.set_position([x/180,y/118,w/180,h/118])
            for t in ax.texts:
                if t.get_text()in list('abcdef')and t.get_fontweight()in ['bold','normal']and len(t.get_text())==1:
                    t.set_text(letter);t.set_position((-.12 if ax is fine else -.3,1.10))
        for t in top.texts:
            if t.get_text().startswith('pooled'):
                t.set_text(t.get_text().replace('\n',' '));t.set_ha('right');t.set_x(3.05)
        legends(top,(1.0,1.03),loc='lower right',ncol=1)
        fine.set_xticks(fine.get_xticks(),['<5','5–9','10–19','20–49','50–100','101–300','301–1k','>1k'])
        for t in fine.texts:
            if t.get_text().startswith('n='):
                t.set_text(t.get_text().replace(',',''));x,y=t.get_position();t.set_position((x,-.31))
        fine.set_xlabel('Rarest required edit: training occurrences',labelpad=31)
        gap.set_ylabel('Many-shot minus\nfew-shot (pp)')
        for t in gap.texts:
            if t.get_text()=='Newcombe 95% intervals':t.set_fontfamily(FONT)
        threshold.set_ylabel('')
        threshold.text(.15,1.17,'Thresholds (few-shot n)',transform=threshold.transAxes,ha='center',va='bottom',fontsize=FONT_FLOOR,fontfamily=FONT)
        for t in threshold.texts:
            if t.get_text()in['Class unknown','Class known']:
                x,y=t.get_position();t.set_x(84);t.set_ha('right');t.set_text(t.get_text().replace('Class ','').capitalize())
        legends(threshold,(.5,1.05),ncol=2)
        odds.set_yticks(odds.get_yticks(),['Frequency','+ edits, LG,\nclass','+ similarity'])
        odds.set_xlabel('Top-1 odds ratio\nper 10-fold increase\nin (count + 1)',labelpad=4)
        legends(odds,(1.0,1.05),ncol=2,loc='lower right')
        for t in odds.get_legend().get_texts():t.set_text(t.get_text().replace('Class ','').capitalize())
        for t in gap.texts:
            if t.get_text()=='c':t.set_position((-.30,1.03))
        for t in threshold.texts+odds.texts:
            if t.get_text()in['d','e']:t.set_position((-.40,1.03))
    if n==3:
        a,b,c,d,e,f=fig.axes
        a.set_xlabel('Gain in pooled top-1\nif group reaches 100% (pp)',labelpad=4)
        a.tick_params(axis='y',pad=3)
        legends(a,(1,.10),loc='lower right')
        c.set_ylabel('Unpaired MDD\n80% power (pp)')
        for t in c.texts:
            if t.get_text().startswith(('few\n','medium\n','many\n')):t.set_visible(False)
        c.text(.5,1.02,'Few/Medium/Many: 52/120/4,832',transform=c.transAxes,ha='center',va='bottom',color='#8A8F98',fontsize=FONT_FLOOR,fontfamily=FONT)
        d.set_ylabel('Paired MDD\n80% power (pp)')
        legends(d,(1,.98),loc='upper right',title='Correctness-discordant\nreactions (%)')
        e.set_ylabel('Correctness-discordant\nreactions (%)')
        legends(e,(1,1.02),loc='upper right',ncol=2)
        equal=[t for t in e.texts if t.get_text()=='15.0']
        if len(equal)==2:
            # Both labels above their own bars; equal heights need a small
            # outward horizontal offset to keep the two 15.0 labels distinct.
            equal[0].set_position((-5,3));equal[1].set_position((5,3))
            for t in equal:t.set_va('bottom')
        for t in e.texts:
            if t.get_text()=='11.5':
                t.set_position((5,3));t.set_va('bottom')
            elif t.get_text()=='13.5':
                t.set_position((-3,3));t.set_va('bottom')
        f.set_xlabel('Correctness-discordant\nreactions (%)')
        f.set_ylabel('Reactions needed\npaired test')
        legends(f,(.50,1.02),ncol=3)
        for t in f.texts:
            if t.get_rotation()==90:t.set_position((0,-15))
    if n==4:
        a,b,c,d,e,f=fig.axes
        for ax in[a,b]:
            for t in ax.texts:
                if ' pp ('in t.get_text():t.set_text(t.get_text().replace(' (','\n('))
        legends(b,(-1.05,-.25),loc='upper center',ncol=2)
        for t in c.get_yticklabels():t.set_text(t.get_text().replace('Class unknown','Unknown').replace('Class known','Known'))
        c.set_yticks(c.get_yticks(),[t.get_text().replace('Class unknown','Unknown').replace('Class known','Known')for t in c.get_yticklabels()])
        c.set_xlabel('Reactions solved by\none model only',labelpad=7)
        for t in c.texts:
            if t.get_text() in ['Graph2Edits only','Aug only']:
                t.set_transform(c.transAxes);t.set_position((0 if t.get_text()=='Graph2Edits only'else 1,1.02));t.set_va('bottom')
        for t in d.get_yticklabels():t.set_fontfamily('Calibri')
        d.set_xlabel('Aug minus Graph2Edits (pp)\npaired bootstrap 95% interval',labelpad=0)
        d.xaxis.label.set_linespacing(1.0);d.tick_params(axis='x',pad=1)
        for t in e.texts:
            if 'few-shot top-10'in t.get_text():
                # Retain the original data-coordinate anchor (the red point).
                # Place the text just to its right and slightly below it,
                # in the empty region beneath the higher-ranked grey points.
                t.set_anncoords('offset points');t.set_position((9,3))
                t.set_ha('left');t.set_va('top')
                if t.arrow_patch:t.arrow_patch.set_visible(True)
                t.set_text('Few-shot top-10\np = 0.031\nHolm p = 0.84')
            elif t.get_text()=='Holm threshold':
                # Keep the grey explanation below its low step segment,
                # away from the red-point annotation.
                t.set_position((3,0.00155));t.set_va('top')
        e.set_xlabel('Comparisons ranked by raw p',labelpad=3)
        f.set_title('Net extra successes (Aug − baseline)',fontsize=FONT_FLOOR)
        for t in f.texts:
            if t.get_text().startswith('U, class'):t.set_position((.5,-.22))
    if n==5:
        a,b,c,d,e=fig.axes
        a.set_yticks(a.get_yticks(),[t.get_text().replace('Heteroatom alkylation/arylation','Heteroatom alkyl./arylation')for t in a.get_yticklabels()])
        a.set_xlabel('Share of class test reactions (%)\nWhite numbers: medium-/few-shot counts',labelpad=5)
        legends(a,(.45,1.04),ncol=3)
        b.set_title('Top-1 accuracy, % (n)\nCells with n < 5 not shown',fontsize=FONT_FLOOR,pad=0)
        b.title.set_linespacing(1.0)
        d.set_ylabel('Nearest training product,\nTanimoto similarity')
        legends(c,(0,1.12),loc='upper left')
        for ax in[c,d,e]:
            for t in ax.texts:
                if t.get_text() in list('cde'):
                    x,y=t.get_position();t.set_position((x,1.02))
        for t in d.texts:
            if t.get_text().startswith('median '):t.set_text(t.get_text().replace('median ',''))
        e.set_yticks(e.get_yticks(),[t.get_text().replace('Few, seen labels','Few, seen')for t in e.get_yticklabels()])
        for t in e.texts:
            if t.get_text()=='Class unknown':t.set_position((87,-.65))
            elif t.get_text()=='Class known':t.set_position((87,2.95))
    # Newly created labels also use the explicit type floor.
    for t in fig.findobj(Text):
        if t.get_text():
            size=max(FONT_FLOOR,t.get_fontsize())
            name='calibri.ttf'if 'Calibri'in t.get_fontfamily()else('ARIALNB.TTF'if t.get_fontweight()=='bold'else'ARIALN.TTF')
            t.set_fontproperties(FontProperties(family='Calibri'if name=='calibri.ttf'else'Arial Narrow',
                fname='C:/Windows/Fonts/'+name,size=size,weight='bold'if name=='ARIALNB.TTF'else'normal'))
    # Author-approved scope: change light-grey Text artists only. Do not alter
    # grey data artists, grid lines, legend handles, fills or other colors.
    from matplotlib.colors import to_rgb
    for t in fig.findobj(Text):
        if t.get_visible() and t.get_text():
            color = to_rgb(t.get_color())
            if min(color) >= .50 and max(color) - min(color) < .07 and max(color) < .8:
                t.set_color('#595959')
    # Author-approved contrast fix: change only the identified Text artists,
    # leaving their associated data markers, curves and legend handles intact.
    if n == 3:
        from matplotlib.colors import to_hex
        for t in fig.findobj(Text):
            if (t.get_text() in ['27.2','38.5% baseline']
                    and to_hex(t.get_color()).upper() in ['#B06A66','#C98A86']):
                t.set_color('#985A54')
    if n == 4:
        from matplotlib.colors import to_hex
        for t in fig.findobj(Text):
            if t.get_text() == 'Aug only' and to_hex(t.get_color()).upper() == '#3E9C8B':
                t.set_color('#276C5B')
