"""Shared figure toolkit for the manuscript rewrite batch (NC-style, 88/180 mm canvases).

Usage in a paper's figure script::

    import sys; sys.path.insert(0, "<...>/_shared")
    import figstyle as fs
    fs.setup()
    fig, axs = fs.grid(width="double", height_mm=110, nrows=2, ncols=3)
    ...
    fs.panel_label(axs[0][0], "a")
    fs.save(fig, "fig2_main", outdir)

Rules baked in (task prompt, section 6): Arial/Helvetica, 5-7 pt text, 0.5 pt axes,
pdf.fonttype 42, no 3D/gradients/pie/dual axes, colour = role (ours / strongest baseline /
neutral), colour-blind safe, 600 dpi PNG preview + PDF + SVG, every plotted point backed by a
source-data CSV through ``SourceData``.
"""
from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patches
from matplotlib.colors import LinearSegmentedColormap

MM = 1 / 25.4
WIDTH_MM = {"single": 88.0, "onehalf": 135.0, "double": 180.0}

# ---- colour roles ---------------------------------------------------------------------
OURS = "#C8423B"        # the method / finding the paper is about
BASE = "#2C6E9B"        # strongest baseline
NEUT = ["#8A8F98", "#B6BBC3", "#D8DBE0"]   # other baselines, dark -> light
INK = "#1F2430"         # text
GRID = "#E7E9ED"
CAT = ["#2C6E9B", "#C8423B", "#E0A33A", "#3E9C8B", "#7B5EA7", "#6B7280"]   # <= 6 categories
GOOD, WARN = "#3E9C8B", "#E0A33A"
PRESET = "#7B5EA7"      # reserved for conditional-target (unmeasured) panels

CMAP_SEQ = "viridis"
CMAP_DIV = LinearSegmentedColormap.from_list("rdbu_soft", ["#2C6E9B", "#F4F5F7", "#C8423B"])
CMAP_BLUE = LinearSegmentedColormap.from_list("blue_soft", ["#F4F7FB", "#9CC1DC", "#2C6E9B", "#173F5F"])


def setup(base: float = 6.0) -> None:
    """Global rcParams: small, quiet, vector-safe."""
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "Helvetica Neue", "DejaVu Sans"],
        "font.size": base, "axes.titlesize": base + 0.5, "axes.labelsize": base + 0.5,
        "xtick.labelsize": base - 0.5, "ytick.labelsize": base - 0.5,
        "legend.fontsize": base - 0.5, "figure.dpi": 150, "savefig.dpi": 600,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none",
        "axes.linewidth": 0.5, "xtick.major.width": 0.5, "ytick.major.width": 0.5,
        "xtick.major.size": 2.0, "ytick.major.size": 2.0, "xtick.major.pad": 1.8,
        "ytick.major.pad": 1.8, "axes.labelpad": 2.0, "axes.titlepad": 3.0,
        "lines.linewidth": 0.9, "lines.markersize": 3.2, "patch.linewidth": 0.5,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.edgecolor": INK, "axes.labelcolor": INK, "text.color": INK,
        "xtick.color": INK, "ytick.color": INK, "legend.frameon": False,
        "legend.handlelength": 1.2, "legend.handletextpad": 0.4, "legend.columnspacing": 1.0,
        "axes.axisbelow": True, "figure.facecolor": "white", "axes.facecolor": "white",
        "image.cmap": CMAP_SEQ, "mathtext.default": "regular",
    })


# ---- canvas ---------------------------------------------------------------------------
def grid(width="double", height_mm=100.0, nrows=1, ncols=1, wspace=0.42, hspace=0.55,
         width_ratios=None, height_ratios=None, left=0.075, right=0.985, top=0.95, bottom=0.10):
    w = WIDTH_MM[width] if isinstance(width, str) else float(width)
    fig = plt.figure(figsize=(w * MM, height_mm * MM))
    gs = fig.add_gridspec(nrows, ncols, left=left, right=right, top=top, bottom=bottom,
                          wspace=wspace, hspace=hspace, width_ratios=width_ratios,
                          height_ratios=height_ratios)
    axs = [[fig.add_subplot(gs[r, c]) for c in range(ncols)] for r in range(nrows)]
    return fig, axs


def panel_label(ax, letter: str, dx: float = -0.20, dy: float = 1.07, size: float = 8.0) -> None:
    """Bold lower-case panel letter, 8 pt, placed in axes coordinates."""
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=size, fontweight="bold",
            va="bottom", ha="left", color=INK)


def light_grid(ax, axis="y"):
    ax.grid(axis=axis, color=GRID, linewidth=0.4)
    ax.set_axisbelow(True)


def direct_label(ax, x, y, text, color=INK, dx=0.0, dy=0.0, ha="left", va="center", size=None,
                 weight="normal"):
    ax.annotate(text, (x, y), xytext=(dx, dy), textcoords="offset points", ha=ha, va=va,
                color=color, fontsize=size or plt.rcParams["font.size"], fontweight=weight)


def hline(ax, y, **kw):
    ax.axhline(y, color=kw.pop("color", NEUT[0]), lw=kw.pop("lw", 0.5), ls=kw.pop("ls", (0, (3, 2))), **kw)


def vline(ax, x, **kw):
    ax.axvline(x, color=kw.pop("color", NEUT[0]), lw=kw.pop("lw", 0.5), ls=kw.pop("ls", (0, (3, 2))), **kw)


# ---- chart primitives -----------------------------------------------------------------
def raincloud(ax, groups: dict, colors=None, orient="v", width=0.36, point_size=4.5,
              show_mean=False, seed=0, point_alpha=0.85, cloud_alpha=0.28):
    """Half-violin + box + all points. ``groups``: {label: 1-D values}. n<=30 shows every point."""
    rng = np.random.default_rng(seed)
    labels = list(groups)
    colors = colors or [CAT[i % len(CAT)] for i in range(len(labels))]
    from scipy.stats import gaussian_kde
    for i, lab in enumerate(labels):
        v = np.asarray(groups[lab], float)
        v = v[~np.isnan(v)]
        c = colors[i]
        if len(v) >= 4 and np.ptp(v) > 0:
            kde = gaussian_kde(v)
            ys = np.linspace(v.min(), v.max(), 100)
            d = kde(ys)
            d = d / d.max() * width
            if orient == "v":
                ax.fill_betweenx(ys, i, i + d, color=c, alpha=cloud_alpha, lw=0)
            else:
                ax.fill_between(ys, i, i + d, color=c, alpha=cloud_alpha, lw=0)
        jit = rng.uniform(-width * 0.55, -width * 0.05, len(v))
        if orient == "v":
            ax.scatter(i + jit, v, s=point_size, color=c, alpha=point_alpha, lw=0, zorder=3)
            q1, med, q3 = np.percentile(v, [25, 50, 75])
            ax.plot([i - 0.02, i - 0.02], [q1, q3], color=INK, lw=1.0, solid_capstyle="butt", zorder=4)
            ax.scatter([i - 0.02], [med], s=9, color="white", ec=INK, lw=0.6, zorder=5)
            if show_mean:
                ax.scatter([i + 0.06], [v.mean()], marker="D", s=7, color="white", ec=INK, lw=0.5, zorder=5)
        else:
            ax.scatter(v, i + jit, s=point_size, color=c, alpha=point_alpha, lw=0, zorder=3)
            q1, med, q3 = np.percentile(v, [25, 50, 75])
            ax.plot([q1, q3], [i - 0.02, i - 0.02], color=INK, lw=1.0, zorder=4)
            ax.scatter([med], [i - 0.02], s=9, color="white", ec=INK, lw=0.6, zorder=5)
            if show_mean:
                ax.scatter([v.mean()], [i + 0.06], marker="D", s=7, color="white", ec=INK, lw=0.5, zorder=5)
    if orient == "v":
        ax.set_xticks(range(len(labels)), labels)
        ax.set_xlim(-0.6, len(labels) - 0.2)
    else:
        ax.set_yticks(range(len(labels)), labels)
        ax.set_ylim(len(labels) - 0.2, -0.6)
    return ax


def dumbbell(ax, labels, a, b, a_label="baseline", b_label="ours", ca=BASE, cb=OURS,
             annotate=True, fmt="{:+.2f}", sort=True):
    """Paired difference per row; the segment length IS the improvement."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    idx = np.argsort(b - a)[::-1] if sort else np.arange(len(a))
    for k, i in enumerate(idx):
        ax.plot([a[i], b[i]], [k, k], color=NEUT[1], lw=1.4, zorder=1, solid_capstyle="round")
        ax.scatter(a[i], k, s=14, color=ca, zorder=3, lw=0)
        ax.scatter(b[i], k, s=14, color=cb, zorder=3, lw=0)
        if annotate:
            ax.annotate(fmt.format(b[i] - a[i]), (max(a[i], b[i]), k), xytext=(4, 0),
                        textcoords="offset points", va="center", fontsize=5, color=INK)
    ax.set_yticks(range(len(idx)), [labels[i] for i in idx])
    ax.set_ylim(len(idx) - 0.4, -0.7)
    ax.scatter([], [], s=14, color=ca, label=a_label)
    ax.scatter([], [], s=14, color=cb, label=b_label)
    lo, hi = float(min(a.min(), b.min())), float(max(a.max(), b.max()))
    ax.set_xlim(lo - 0.06 * (hi - lo), hi + 0.22 * (hi - lo))   # room for the delta text
    light_grid(ax, "x")
    return idx   # legend: ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.0), ncol=2)


def forest(ax, labels, est, lo, hi, colors=None, ref=0.0, sizes=None, annotate=True, fmt="{:.2f} [{:.2f}, {:.2f}]"):
    est, lo, hi = map(lambda v: np.asarray(v, float), (est, lo, hi))
    colors = colors or [INK] * len(est)
    for k in range(len(est)):
        ax.plot([lo[k], hi[k]], [k, k], color=colors[k], lw=1.0, solid_capstyle="round")
        ax.scatter(est[k], k, s=(sizes[k] if sizes is not None else 16), color=colors[k], zorder=3, lw=0)
        if annotate:
            ax.annotate(fmt.format(est[k], lo[k], hi[k]), (hi[k], k), xytext=(4, 0), textcoords="offset points",
                        va="center", fontsize=5)
    vline(ax, ref)
    ax.set_yticks(range(len(est)), labels)
    ax.set_ylim(len(est) - 0.4, -0.7)
    if annotate:
        l0, h0 = float(lo.min()), float(hi.max())
        ax.set_xlim(l0 - 0.05 * (h0 - l0), h0 + 0.55 * (h0 - l0))
    light_grid(ax, "x")


def annotated_heatmap(fig, ax, M, xlabels, ylabels, cmap=CMAP_BLUE, vmin=None, vmax=None,
                      fmt="{:.2f}", cbar_label=None, text_size=5, mark=None, cbar=True):
    """Heatmap with numbers in cells; ``mark`` = boolean array outlining the best cell(s)."""
    M = np.asarray(M, float)
    im = ax.imshow(M, cmap=cmap, vmin=vmin, vmax=vmax, aspect="auto")
    ax.set_xticks(range(len(xlabels)), xlabels, rotation=0)
    ax.set_yticks(range(len(ylabels)), ylabels)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)
    norm = im.norm
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if np.isnan(M[i, j]):
                continue
            rgba = im.cmap(norm(M[i, j]))
            lum = 0.299 * rgba[0] + 0.587 * rgba[1] + 0.114 * rgba[2]
            ax.text(j, i, fmt.format(M[i, j]), ha="center", va="center", fontsize=text_size,
                    color="white" if lum < 0.5 else INK)
            if mark is not None and mark[i, j]:
                ax.add_patch(patches.Rectangle((j - .5, i - .5), 1, 1, fill=False, ec=INK, lw=0.9))
    if cbar:
        cb = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.02, shrink=0.9)
        cb.outline.set_linewidth(0.4)
        cb.ax.tick_params(length=1.5, width=0.4, labelsize=5)
        if cbar_label:
            cb.set_label(cbar_label, fontsize=5.5)
    return im


def parity(ax, y, yhat, color=OURS, label_xy=(0.04, 0.96), unit=""):
    y, yhat = np.asarray(y, float), np.asarray(yhat, float)
    lo, hi = min(y.min(), yhat.min()), max(y.max(), yhat.max())
    pad = 0.04 * (hi - lo)
    ax.plot([lo - pad, hi + pad], [lo - pad, hi + pad], color=NEUT[0], lw=0.6, ls=(0, (3, 2)))
    ax.scatter(y, yhat, s=4, color=color, alpha=0.55, lw=0)
    r = np.corrcoef(y, yhat)[0, 1]
    rmse = float(np.sqrt(np.mean((y - yhat) ** 2)))
    r2 = 1 - np.sum((y - yhat) ** 2) / np.sum((y - y.mean()) ** 2)
    ax.text(*label_xy, f"r = {r:.2f}\nR$^2$ = {r2:.2f}\nRMSE = {rmse:.2f}{unit}\nn = {len(y)}",
            transform=ax.transAxes, va="top", fontsize=5)
    ax.set_xlim(lo - pad, hi + pad)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_aspect("equal", adjustable="box")
    return dict(r=r, r2=r2, rmse=rmse, n=len(y))


def bars_with_points(ax, labels, values, colors=None, ci=None, point_size=5, bar_alpha=0.30, seed=0, ylim=None):
    """Bar = mean, points = every independent unit, whisker = 95% CI (or s.d.) supplied via ``ci``."""
    rng = np.random.default_rng(seed)
    colors = colors or [CAT[i % len(CAT)] for i in range(len(labels))]
    for i, v in enumerate(values):
        v = np.asarray(v, float)
        m = v.mean()
        ax.bar(i, m, width=0.62, color=colors[i], alpha=bar_alpha, lw=0)
        ax.scatter(i + rng.uniform(-0.18, 0.18, len(v)), v, s=point_size, color=colors[i], lw=0, zorder=3)
        if ci is not None:
            lo, hi = ci[i]
            ax.plot([i, i], [lo, hi], color=INK, lw=0.7, zorder=4)
        ax.plot([i - 0.31, i + 0.31], [m, m], color=colors[i], lw=1.2, zorder=4)
    ax.set_xticks(range(len(labels)), labels)
    ax.set_xlim(-0.6, len(labels) - 0.4)
    if ylim:
        ax.set_ylim(*ylim)
    light_grid(ax, "y")


def band_line(ax, x, mean, sd, color, label=None, lw=1.0, alpha=0.18):
    x, mean, sd = map(lambda v: np.asarray(v, float), (x, mean, sd))
    ax.plot(x, mean, color=color, lw=lw, label=label)
    ax.fill_between(x, mean - sd, mean + sd, color=color, alpha=alpha, lw=0)


def slope(ax, labels, left_vals, right_vals, left_name="before", right_name="after", highlight=None):
    """Slope chart: one line per item; ``highlight`` (set of labels) coloured, others neutral."""
    highlight = highlight or set()
    for lab, a, b in zip(labels, left_vals, right_vals):
        c = OURS if lab in highlight else NEUT[1]
        ax.plot([0, 1], [a, b], color=c, lw=1.1 if lab in highlight else 0.7, marker="o", ms=2.6, zorder=3 if lab in highlight else 2)
        if lab in highlight:
            direct_label(ax, 1, b, lab, color=OURS, dx=4)
    ax.set_xticks([0, 1], [left_name, right_name])
    ax.set_xlim(-0.2, 1.6)


# ---- schematics -----------------------------------------------------------------------
def schematic_axes(fig, rect, xlim=(0, 100), ylim=(0, 100)):
    """Blank data-coordinate axes (mm-like grid) for hand-built schematics; rect in figure fraction."""
    ax = fig.add_axes(rect)
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.axis("off")
    return ax


def rbox(ax, x, y, w, h, text="", fc="#EEF3F8", ec=BASE, lw=0.7, size=5.5, color=INK, r=1.8,
         weight="normal", ha="center", va="center", ls="-"):
    """Rounded box with text; (x, y) is the bottom-left corner."""
    p = patches.FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}", fc=fc, ec=ec,
                               lw=lw, ls=ls, zorder=2)
    ax.add_patch(p)
    if text:
        tx = x + (w / 2 if ha == "center" else 2.0)
        ax.text(tx, y + h / 2, text, ha=ha, va=va, fontsize=size, color=color, fontweight=weight,
                zorder=3, linespacing=1.15)
    return p


def arrow(ax, p0, p1, color=INK, lw=0.8, style="-|>", rad=0.0, ms=6, ls="-"):
    a = patches.FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=ms, color=color, lw=lw,
                                connectionstyle=f"arc3,rad={rad}", shrinkA=0, shrinkB=0, ls=ls, zorder=1)
    ax.add_patch(a)
    return a


def lane(ax, x, y, w, h, title, color=BASE, size=5.5):
    """Background swim-lane with a small caps title; children drawn on top."""
    ax.add_patch(patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=2.2",
                                        fc=color + "14", ec="none", zorder=0))
    ax.text(x + 2, y + h - 1.8, title.upper(), ha="left", va="top", fontsize=size - 0.5,
            color=color, fontweight="bold", zorder=1)


def pipeline(ax, steps, y=40, h=18, gap=7, x0=2, total_w=96, colors=None, size=5.5):
    """Left-to-right chain of boxes joined by arrows (input -> method -> output -> validation)."""
    n = len(steps)
    w = (total_w - gap * (n - 1)) / n
    colors = colors or [BASE] * n
    for i, s in enumerate(steps):
        x = x0 + i * (w + gap)
        rbox(ax, x, y, w, h, s, fc=colors[i] + "1A", ec=colors[i], size=size)
        if i < n - 1:
            arrow(ax, (x + w + 0.6, y + h / 2), (x + w + gap - 0.6, y + h / 2))


# ---- conditional-target (unmeasured) panels -------------------------------------------
def preset_overlay(ax, exp_id: str, text: str | None = None):
    """Stamp a panel as unmeasured: dashed purple frame + banner. Never draws individual points."""
    for sp in ax.spines.values():
        sp.set_visible(True)
        sp.set_edgecolor(PRESET)
        sp.set_linestyle((0, (3, 2)))
        sp.set_linewidth(0.8)
    ax.text(0.5, 1.015, text or f"PRESET · NOT MEASURED · {exp_id}", transform=ax.transAxes,
            ha="center", va="bottom", fontsize=5.5, color=PRESET, fontweight="bold")


def preset_band(ax, x, lo, hi, label=None, color=PRESET, alpha=0.18):
    """Expected interval as a band (no markers); ``lo``/``hi`` come from a stated basis only."""
    ax.fill_between(x, lo, hi, color=color, alpha=alpha, lw=0, hatch="////", edgecolor=color)
    if label:
        direct_label(ax, x[-1], np.asarray(hi)[-1], label, color=color, dy=5, ha="right", va="bottom")


def preset_threshold(ax, y, label, color=PRESET):
    ax.axhline(y, color=color, lw=0.8, ls=(0, (4, 2)))
    ax.text(0.99, y, label, transform=ax.get_yaxis_transform(), ha="right", va="bottom", fontsize=5, color=color)


# ---- source data & saving -------------------------------------------------------------
@dataclass
class SourceData:
    """Collect every plotted table + provenance; write one CSV per panel and a JSON index."""
    script: str = ""
    panels: dict = field(default_factory=dict)

    def add(self, panel: str, table, source: str = "", note: str = ""):
        import pandas as pd
        df = table if isinstance(table, pd.DataFrame) else pd.DataFrame(table)
        sha = ""
        if source and os.path.isfile(source):
            sha = hashlib.sha256(open(source, "rb").read()).hexdigest()[:16]
        self.panels[panel] = dict(df=df, source=source, sha256=sha, note=note)

    def write(self, outdir: str, prefix: str = "source_data"):
        os.makedirs(outdir, exist_ok=True)
        idx = {}
        for k, v in self.panels.items():
            fn = f"{prefix}_{k}.csv"
            v["df"].to_csv(os.path.join(outdir, fn), index=False)
            idx[k] = dict(file=fn, rows=len(v["df"]), source=v["source"], sha256_16=v["sha256"],
                          note=v["note"], script=self.script)
        json.dump(idx, open(os.path.join(outdir, f"{prefix}_index.json"), "w"), indent=1, ensure_ascii=False)


def save(fig, stem: str, outdir: str, formats=("pdf", "svg", "png"), dpi: int = 600):
    os.makedirs(outdir, exist_ok=True)
    paths = []
    for f in formats:
        p = os.path.join(outdir, f"{stem}.{f}")
        fig.savefig(p, dpi=dpi, facecolor="white")
        paths.append(p)
    plt.close(fig)
    return paths


def check_pdf_fonts(pdf_path: str) -> list[str]:
    """Return the embedded font names; a 'Type 3' hit means the figure must be re-exported."""
    import fitz
    names = set()
    with fitz.open(pdf_path) as d:
        for pg in d:
            for f in pg.get_fonts(full=True):
                names.add(f"{f[3]}|{f[2]}")
    return sorted(names)
