"""Regenerate Figures 2 and 4 with verified numerical identity."""
from pathlib import Path
import sys,json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
import run_figures as base
import typography
import compact_labels

OUT=Path(__file__).resolve().parent.parent
def main():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--figures',nargs='+',type=int,choices=[2,4],default=[2,4])
    selected=parser.parse_args().figures
    definitions=base.definitions(OUT/'code/make_figures_readable.py')
    target=OUT/'verification/compact_checks.json'
    checks=json.loads(target.read_text(encoding='utf8'))if target.exists()else{}
    for n in selected:
        fig=definitions[f'fig{n}']()
        if n==2:fig.delaxes(fig.axes[0])
        typography.apply(fig,n)
        before=base.snapshot(fig)
        fig.canvas.draw()
        boxes=[ax.get_position().bounds for ax in fig.axes]
        old_size=fig.get_size_inches()*25.4
        compact_labels.apply(fig,n)
        after=base.snapshot(fig)
        assert before==after,'Scientific artist or scale changed'
        for i,ax in enumerate(fig.axes):
            if (n,i)not in [(2,3),(4,3)]:
                for j,(a,b)in enumerate(zip(ax.get_position().bounds,boxes[i])):
                    old_mm=b*old_size[j%2]
                    new_mm=a*(fig.get_size_inches()*25.4)[j%2]
                    assert abs(old_mm-new_mm)<1e-10
        fig.canvas.draw()
        renderer=fig.canvas.get_renderer();w,h=fig.canvas.get_width_height()
        if n==2:
            panel_b=fig.axes[2]
            count_boxes=[t.get_window_extent(renderer)for t in panel_b.texts if t.get_text().startswith('n=')]
            descriptor_box=panel_b.xaxis.label.get_window_extent(renderer)
            assert len(count_boxes)==8
            assert all(b.y0>panel_b.bbox.y1 for b in count_boxes)
            assert descriptor_box.y0>max(b.y1 for b in count_boxes)
        label_ax=fig.axes[1 if n==2 else 3]
        label_box=label_ax.yaxis.label.get_window_extent(renderer)
        tick_boxes=[t.get_window_extent(renderer)for t in label_ax.get_yticklabels()if t.get_visible()]
        label_gap_pt=min(b.x0-label_box.x1 for b in tick_boxes)*72/fig.dpi
        assert label_gap_pt>2,'Y-axis title crowds tick labels'
        outside=[]
        for t in fig.findobj(Text):
            if not t.get_visible()or not t.get_text().strip():continue
            # Ignore cached automatic tick objects outside the visible limits.
            skip=any((t in ax.get_xticklabels()and not min(ax.get_xlim())<=t.get_position()[0]<=max(ax.get_xlim()))or(t in ax.get_yticklabels()and not min(ax.get_ylim())<=t.get_position()[1]<=max(ax.get_ylim()))for ax in fig.axes)
            if skip:continue
            b=t.get_window_extent(renderer)
            if b.x0<0 or b.y0<0 or b.x1>w or b.y1>h:outside.append(t.get_text())
        for ext in ['pdf','svg','png']:fig.savefig(OUT/f'figures/Fig{n}.{ext}',dpi=300,facecolor='white')
        checks[str(n)]={'scientific_artists_and_limits_unchanged':True,
            'data_artist_sha256':hashlib.sha256(before.encode()).hexdigest(),
            'canvas_mm':(fig.get_size_inches()*25.4).tolist(),
            'text_outside_canvas':outside,
            'ylabel_to_tick_gap_pt':label_gap_pt,
            'ylabel':label_ax.get_ylabel(),
            'other_data_panels_same_physical_geometry':True}
        if n==4:
            ax=fig.axes[3];y=ax.get_yticks();xy=ax.transData.transform([[0,y[0]],[0,y[1]]])
            checks[str(n)]['forest_row_pitch_pt']=abs(xy[0,1]-xy[1,1])*72/fig.dpi
        plt.close(fig)
    (OUT/'verification/compact_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
    print(json.dumps(checks,indent=2))
if __name__=='__main__':sys.stdout.reconfigure(encoding='utf8');main()
