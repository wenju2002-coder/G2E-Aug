# Additional file 1

RetroTail: Edit-frequency stratified evaluation for single-step retrosynthesis prediction

Journal of Cheminformatics

Wenju Zhang^1,2^, Xiaorui Wang^3^, Pei Yang^1,2^, Yachao Cui^1,2,*^, Yuquan Li^4,5,6,†^

^1^ Qinghai University, School of Computer Technology and Applications, Xining 810016, China

^2^ Qinghai Provincial Laboratory for Intelligent Computing and Application, Xining 810016, China

^3^ College of Pharmaceutical Sciences, Zhejiang University, Hangzhou 310058, China

^4^ Guizhou Provincial Laboratory of Big Data, State Key Laboratory of Public Big Data, College of Computer Science and Technology, Guizhou University, Guiyang 550025, China

^5^ State Key Laboratory of Green Pesticide, Center for Research and Development of Fine Chemicals, Guizhou University, Guiyang 550025, China

^6^ Kway AI, China

^*^ Corresponding author: Yachao Cui; E-mail: yachaocui@qhu.edu.cn; ORCID: https://orcid.org/0000-0002-8650-9013

† Corresponding author: Yuquan Li; E-mail: yvquan.li@gzu.edu.cn; ORCID: https://orcid.org/0000-0003-2756-0449

RetroTail is an evaluation workflow. The empirical case study is restricted to the Graph2Edits family on one USPTO-50K split; cross-family and cross-split validity has not been established.

## Data provenance and interpretation

This PDF is a supplementary statistical report, not an independent dataset or a new model evaluation. Observed summaries use the archived processed USPTO-50K data and four model–setting prediction tables for the same 5,004 test reactions: Graph2Edits and Graph2Edits-Aug, each with reaction-class input withheld or supplied. The four ranked-record tables are Analysis/baseline_unknown_per_reaction.csv, Analysis/baseline_known_per_reaction.csv, Analysis/aug_unknown_per_reaction.csv and Analysis/aug_known_per_reaction.csv in Additional file 2 (Additional_file_2.zip).

Tables S1–S4 and S6–S8 summarize the archived records or features derived from the processed data. Table S5 contains power-planning calculations under specified sample-size, baseline-accuracy, effect-size and correctness-discordance assumptions. Its values are not observed model improvements, extra test sets or multi-seed experiments. Hypothetical planning is distinguished from measured performance throughout.

Unless stated otherwise, percentages are rounded to one decimal and counts are exact. Values are rounded directly from unrounded integer ratios, never from already-rounded displays. Thus 4,471/5,004 is 89.35% at two decimals in main-text Table 1 but 89.3% here; 3,360/5,004 is 67.15% at two decimals but 67.1% here. These are identical predictions. Wilson intervals are 95% confidence intervals. Planning baselines in S5a are specified rounded values (13.5%, 38.5% and 56.2%), whereas observed accuracies and conditional ceilings use exact counts.

Many, Medium and Few abbreviate many-shot, medium-shot and few-shot. Pooled combines all 5,004 reactions. Known/Unknown refer only to whether the reaction-class label is supplied to the predictor. Correctness discordance means that exactly one model is correct at a specified top-k cut-off; different predictions that are both incorrect are not discordant pairs. Frequency is defined from the recorded reference edits, not from chemical novelty.

Source notes below name files relative to evidence_analysis/source_data/analysis_tables/ inside Additional_file_2.zip. The evidence-only make_si_evidence_jci.py reads these CSVs and creates this Markdown; typeset_si_jci.py produces the PDF. Both are in evidence_analysis/scripts/. README_JCI.md provides commands. These scripts do not generate model predictions.


## Table S1  Top-k accuracy by edit-frequency group for all four model and setting combinations

Source: acc_by_bucket.csv. Integer success counts and Wilson intervals from the four archived per-reaction tables; expands main-text Table 1.

| Model and setting | Group | n | Top-1 | Top-3 | Top-5 | Top-10 |
|:--|--:|--:|--:|--:|--:|--:|
| Graph2Edits, class unknown | Many | 4832 | 56.2 (2714; 54.8–57.6) | 78.3 (3783; 77.1–79.4) | 84.6 (4089; 83.6–85.6) | 90.4 (4370; 89.6–91.2) |
| Graph2Edits, class unknown | Medium | 120 | 29.2 (35; 21.8–37.8) | 47.5 (57; 38.8–56.4) | 53.3 (64; 44.4–62.0) | 67.5 (81; 58.7–75.2) |
| Graph2Edits, class unknown | Few | 52 | 13.5 (7; 6.7–25.3) | 30.8 (16; 19.9–44.3) | 36.5 (19; 24.8–50.1) | 38.5 (20; 26.5–52.0) |
| Graph2Edits, class unknown | Pooled | 5004 | 55.1 (2756; 53.7–56.4) | 77.1 (3856; 75.9–78.2) | 83.4 (4172; 82.3–84.4) | 89.3 (4471; 88.5–90.2) |
| Graph2Edits, class known | Many | 4832 | 68.1 (3290; 66.8–69.4) | 88.2 (4260; 87.2–89.0) | 92.5 (4468; 91.7–93.2) | 94.5 (4564; 93.8–95.1) |
| Graph2Edits, class known | Medium | 120 | 48.3 (58; 39.6–57.2) | 65.0 (78; 56.1–72.9) | 73.3 (88; 64.8–80.4) | 81.7 (98; 73.8–87.6) |
| Graph2Edits, class known | Few | 52 | 23.1 (12; 13.7–36.1) | 40.4 (21; 28.2–53.9) | 51.9 (27; 38.7–64.9) | 57.7 (30; 44.2–70.1) |
| Graph2Edits, class known | Pooled | 5004 | 67.1 (3360; 65.8–68.4) | 87.1 (4359; 86.2–88.0) | 91.6 (4583; 90.8–92.3) | 93.8 (4692; 93.1–94.4) |
| Graph2Edits-Aug, class unknown | Many | 4832 | 56.6 (2734; 55.2–58.0) | 79.3 (3832; 78.1–80.4) | 85.9 (4149; 84.9–86.8) | 91.2 (4408; 90.4–92.0) |
| Graph2Edits-Aug, class unknown | Medium | 120 | 25.8 (31; 18.8–34.3) | 42.5 (51; 34.0–51.4) | 50.8 (61; 42.0–59.6) | 69.2 (83; 60.4–76.7) |
| Graph2Edits-Aug, class unknown | Few | 52 | 19.2 (10; 10.8–31.9) | 32.7 (17; 21.5–46.2) | 42.3 (22; 29.9–55.8) | 50.0 (26; 36.9–63.1) |
| Graph2Edits-Aug, class unknown | Pooled | 5004 | 55.5 (2775; 54.1–56.8) | 77.9 (3900; 76.8–79.1) | 84.6 (4232; 83.5–85.5) | 90.3 (4517; 89.4–91.1) |
| Graph2Edits-Aug, class known | Many | 4832 | 68.4 (3306; 67.1–69.7) | 88.6 (4283; 87.7–89.5) | 92.4 (4464; 91.6–93.1) | 95.1 (4597; 94.5–95.7) |
| Graph2Edits-Aug, class known | Medium | 120 | 46.7 (56; 38.0–55.6) | 62.5 (75; 53.6–70.6) | 72.5 (87; 63.9–79.7) | 82.5 (99; 74.7–88.3) |
| Graph2Edits-Aug, class known | Few | 52 | 17.3 (9; 9.4–29.7) | 46.2 (24; 33.3–59.5) | 51.9 (27; 38.7–64.9) | 57.7 (30; 44.2–70.1) |
| Graph2Edits-Aug, class known | Pooled | 5004 | 67.4 (3371; 66.1–68.7) | 87.6 (4382; 86.6–88.5) | 91.5 (4578; 90.7–92.2) | 94.4 (4726; 93.8–95.0) |

Cells give percentage, the number of successes and the Wilson interval in parentheses.

## Table S2  Sensitivity of the head-to-tail gap to the group thresholds

Source: threshold_sensitivity_rederived.csv. The same records re-stratified under three threshold pairs; corresponds to Fig. 2d and does not involve retraining.

| Class input | Few below / many above | n many | n medium | n few | Many top-1 | Few top-1 | Gap top-1 (pp) | Many top-10 | Few top-10 |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| Unknown | 10 / 50 | 4898 | 75 | 31 | 56.0 | 9.7 | 46.3 | 90.4 | 35.5 |
| Unknown | 20 / 100 | 4832 | 120 | 52 | 56.2 | 13.5 | 42.7 | 90.4 | 38.5 |
| Unknown | 50 / 200 | 4584 | 320 | 100 | 57.1 | 13.0 | 44.1 | 91.0 | 40.0 |
| Known | 10 / 50 | 4898 | 75 | 31 | 68.0 | 16.1 | 51.9 | 94.4 | 48.4 |
| Known | 20 / 100 | 4832 | 120 | 52 | 68.1 | 23.1 | 45.0 | 94.5 | 57.7 |
| Known | 50 / 200 | 4584 | 320 | 100 | 68.8 | 26.0 | 42.8 | 94.8 | 64.0 |

Graph2Edits. The primary pair is 20 / 100. The leaving-group module of Graph2Edits-Aug uses head and tail thresholds of 50 and 10 occurrences, so the 10 / 50 pair coincides with that design.

## Table S3  Properties of the frequency groups

Source: per_reaction_features.csv (group and class summaries); similarity_by_bucket.csv provides a separate similarity summary. Relates to Fig. 5. Distinct-patent counts overlap across strata and must not be summed as a count of unique patents in the full test set.

| Group | n | Distinct patents | With leaving-group edit | With unseen edit label | Median non-terminal edits (range) | Median nearest-neighbour similarity | Product identical to a training product |
|:--|--:|--:|--:|--:|--:|--:|--:|
| Many | 4832 | 4071 | 4501 (93.1%) | 0 | 2 (1–8) | 0.53 | 67 |
| Medium | 120 | 113 | 114 (95.0%) | 0 | 3 (1–5) | 0.56 | 3 |
| Few | 52 | 51 | 52 (100.0%) | 5 | 2 (2–6) | 0.50 | 0 |

Nearest-neighbour similarity is the Tanimoto coefficient of Morgan fingerprints (radius 2, 2,048 bits) between the test product and the closest training product. Patents are identified from the reaction identifier.

Reaction classes 1–10 (stored evaluation index plus one) and group sizes:

| Class | Class name | Many | Medium | Few | Total |
|:--|--:|--:|--:|--:|--:|
| 1 | Heteroatom alkylation and arylation | 1513 | 2 | 1 | 1516 |
| 2 | Acylation and related processes | 1173 | 4 | 10 | 1187 |
| 3 | C–C bond formation | 507 | 49 | 11 | 567 |
| 4 | Heterocycle formation | 83 | 5 | 3 | 91 |
| 5 | Protections | 61 | 7 | 0 | 68 |
| 6 | Deprotections | 782 | 37 | 5 | 824 |
| 7 | Reductions | 445 | 5 | 12 | 462 |
| 8 | Oxidations | 81 | 0 | 1 | 82 |
| 9 | Functional-group interconversions | 164 | 11 | 9 | 184 |
| 10 | Functional-group additions | 23 | 0 | 0 | 23 |

## Table S4  Exact paired comparisons of Graph2Edits-Aug with Graph2Edits (32 tests)

Source: paired_tests.csv. Exactly matched reactions, baseline-only and Aug-only correctness counts, and 32 exact McNemar tests with Holm correction; corresponds to Fig. 4.

| Class input | Group | Cut-off | n | Baseline successes | Aug successes | Baseline only | Aug only | Diff (pp) | P exact | P Holm (32) |
|:--|--:|--:|--:|--:|--:|--:|--:|--:|--:|--:|
| Unknown | Many | Top-1 | 4832 | 2714 | 2734 | 414 | 434 | 0.41 | 0.5141 | 1 |
| Unknown | Many | Top-3 | 4832 | 3783 | 3832 | 250 | 299 | 1.01 | 0.0404 | 1 |
| Unknown | Many | Top-5 | 4832 | 4089 | 4149 | 196 | 256 | 1.24 | 0.00546 | 0.1747 |
| Unknown | Many | Top-10 | 4832 | 4370 | 4408 | 142 | 180 | 0.79 | 0.03905 | 1 |
| Unknown | Medium | Top-1 | 120 | 35 | 31 | 11 | 7 | -3.33 | 0.4807 | 1 |
| Unknown | Medium | Top-3 | 120 | 57 | 51 | 14 | 8 | -5.0 | 0.2863 | 1 |
| Unknown | Medium | Top-5 | 120 | 64 | 61 | 16 | 13 | -2.5 | 0.7111 | 1 |
| Unknown | Medium | Top-10 | 120 | 81 | 83 | 8 | 10 | 1.67 | 0.8145 | 1 |
| Unknown | Few | Top-1 | 52 | 7 | 10 | 2 | 5 | 5.77 | 0.4531 | 1 |
| Unknown | Few | Top-3 | 52 | 16 | 17 | 2 | 3 | 1.92 | 1 | 1 |
| Unknown | Few | Top-5 | 52 | 19 | 22 | 0 | 3 | 5.77 | 0.25 | 1 |
| Unknown | Few | Top-10 | 52 | 20 | 26 | 0 | 6 | 11.54 | 0.03125 | 0.8438 |
| Unknown | Pooled | Top-1 | 5004 | 2756 | 2775 | 427 | 446 | 0.38 | 0.5424 | 1 |
| Unknown | Pooled | Top-3 | 5004 | 3856 | 3900 | 266 | 310 | 0.88 | 0.07309 | 1 |
| Unknown | Pooled | Top-5 | 5004 | 4172 | 4232 | 212 | 272 | 1.2 | 0.00726 | 0.225 |
| Unknown | Pooled | Top-10 | 5004 | 4471 | 4517 | 150 | 196 | 0.92 | 0.01543 | 0.463 |
| Known | Many | Top-1 | 4832 | 3290 | 3306 | 319 | 335 | 0.33 | 0.5575 | 1 |
| Known | Many | Top-3 | 4832 | 4260 | 4283 | 161 | 184 | 0.48 | 0.2362 | 1 |
| Known | Many | Top-5 | 4832 | 4468 | 4464 | 126 | 122 | -0.08 | 0.849 | 1 |
| Known | Many | Top-10 | 4832 | 4564 | 4597 | 84 | 117 | 0.68 | 0.02376 | 0.6891 |
| Known | Medium | Top-1 | 120 | 58 | 56 | 8 | 6 | -1.67 | 0.7905 | 1 |
| Known | Medium | Top-3 | 120 | 78 | 75 | 8 | 5 | -2.5 | 0.5811 | 1 |
| Known | Medium | Top-5 | 120 | 88 | 87 | 7 | 6 | -0.83 | 1 | 1 |
| Known | Medium | Top-10 | 120 | 98 | 99 | 6 | 7 | 0.83 | 1 | 1 |
| Known | Few | Top-1 | 52 | 12 | 9 | 4 | 1 | -5.77 | 0.375 | 1 |
| Known | Few | Top-3 | 52 | 21 | 24 | 1 | 4 | 5.77 | 0.375 | 1 |
| Known | Few | Top-5 | 52 | 27 | 27 | 4 | 4 | 0.0 | 1 | 1 |
| Known | Few | Top-10 | 52 | 30 | 30 | 4 | 4 | 0.0 | 1 | 1 |
| Known | Pooled | Top-1 | 5004 | 3360 | 3371 | 331 | 342 | 0.22 | 0.6999 | 1 |
| Known | Pooled | Top-3 | 5004 | 4359 | 4382 | 170 | 193 | 0.46 | 0.2482 | 1 |
| Known | Pooled | Top-5 | 5004 | 4583 | 4578 | 137 | 132 | -0.1 | 0.8074 | 1 |
| Known | Pooled | Top-10 | 5004 | 4692 | 4726 | 94 | 128 | 0.68 | 0.02655 | 0.7434 |

Two-sided exact McNemar test on the reactions solved by only one model; Holm adjustment over all 32 rows.

## Table S5  Planning calculations

Source: unpaired_mdd_curve.csv (S5a), paired_planning.csv (S5b) and paired_required_n.csv (S5c). These are calculations under specified planning assumptions, not additional model runs or observed gains; correspond to Fig. 3c,d,f.

**a. Unpaired minimum detectable difference (pp), 80% power, two-sided α = 0.05**

| n per model | baseline 13.5% | baseline 38.5% | baseline 56.2% |
|:--|--:|--:|--:|
| 30 | 32.4 | 35.3 | 31.9 |
| 40 | 27.5 | 30.8 | 28.3 |
| 52 | 23.7 | 27.2 | 25.2 |
| 75 | 19.2 | 22.7 | 21.4 |
| 100 | 16.2 | 19.7 | 18.8 |
| 120 | 14.6 | 18.0 | 17.2 |
| 200 | 11.0 | 14.0 | 13.5 |
| 300 | 8.8 | 11.4 | 11.1 |
| 500 | 6.7 | 8.8 | 8.7 |
| 1000 | 4.6 | 6.2 | 6.2 |
| 2000 | 3.2 | 4.4 | 4.4 |
| 4832 | 2.1 | 2.8 | 2.9 |

**b. Paired minimum detectable net gain (pp), 80% power, exact test, by share of correctness-discordant reactions**

| n | 5% correctness discordant | 10% correctness discordant | 15% correctness discordant | 20% correctness discordant | 30% correctness discordant |
|:--|--:|--:|--:|--:|--:|
| 52 | not reachable | not reachable | 14.9 | 17.3 | 21.5 |
| 120 | not reachable | 8.1 | 10.1 | 11.8 | 14.4 |
| 250 | 4.0 | 5.8 | 7.1 | 8.1 | 10.0 |
| 500 | 2.9 | 4.1 | 5.0 | 5.7 | 7.0 |
| 1000 | 2.0 | 2.9 | 3.5 | 4.0 | 4.9 |
| 2000 | 1.4 | 2.0 | 2.5 | 2.8 | 3.5 |

**c. Reactions needed for 80% power in an exact paired test**

| Net gain (pp) | 10% correctness discordant | 15% correctness discordant | 20% correctness discordant | 30% correctness discordant |
|:--|--:|--:|--:|--:|
| 3.0 | 920 | 1362 | 1800 | 2677 |
| 5.0 | 337 | 498 | 658 | 975 |
| 10.0 | 78 | 122 | 168 | 249 |

## Table S6  Association of top-1 success with the training count of the rarest edit

Source: logit_exploratory.csv and logit_with_similarity.csv. Exploratory associations with log10(training count + 1), conditional on the stated covariates; relates to Fig. 2e. These are not causal effects or changes to model-training logits.

| Model and setting | Adjustment | Odds ratio per 10-fold increase in (training count + 1) (95% interval) |
|:--|--:|--:|
| Graph2Edits, class unknown | None | 2.06 (1.87–2.27) |
| Graph2Edits, class unknown | Edit count, leaving-group edit, class | 2.16 (1.90–2.45) |
| Graph2Edits, class unknown | As above plus nearest-neighbour similarity | 2.17 (1.91–2.47) (similarity per unit: 9.1, interval 6.0–13.8) |
| Graph2Edits, class known | None | 1.89 (1.72–2.07) |
| Graph2Edits, class known | Edit count, leaving-group edit, class | 2.24 (1.97–2.54) |
| Graph2Edits, class known | As above plus nearest-neighbour similarity | 2.24 (1.97–2.54) (similarity per unit: 5.2, interval 3.3–8.1) |
| Graph2Edits-Aug, class unknown | None | 1.93 (1.76–2.13) |
| Graph2Edits-Aug, class unknown | Edit count, leaving-group edit, class | 2.08 (1.83–2.37) |
| Graph2Edits-Aug, class unknown | As above plus nearest-neighbour similarity | 2.09 (1.83–2.37) (similarity per unit: 7.1, interval 4.7–10.7) |
| Graph2Edits-Aug, class known | None | 2.02 (1.84–2.22) |
| Graph2Edits-Aug, class known | Edit count, leaving-group edit, class | 2.24 (1.98–2.54) |
| Graph2Edits-Aug, class known | As above plus nearest-neighbour similarity | 2.24 (1.98–2.54) (similarity per unit: 5.4, interval 3.5–8.5) |

Binomial generalised linear models with robust (HC1) standard errors; exploratory.

## Table S7  Top-1 accuracy of Graph2Edits in finer frequency bins

Source: fine_bins.csv. Eight finer strata of the same archived Graph2Edits predictions; corresponds to the submitted Fig. 2b, not its historical panel label.

| Rarest edit, training count | n | Graph2Edits, class unknown | Graph2Edits, class known |
|:--|--:|--:|--:|
| <5 | 16 | 12.5 (2; 3.5–36.0) | 18.8 (3; 6.6–43.0) |
| 5-9 | 15 | 6.7 (1; 1.2–29.8) | 13.3 (2; 3.7–37.9) |
| 10-19 | 21 | 19.0 (4; 7.7–40.0) | 33.3 (7; 17.2–54.6) |
| 20-49 | 48 | 12.5 (6; 5.9–24.7) | 29.2 (14; 18.2–43.2) |
| 50-100 | 72 | 40.3 (29; 29.7–51.8) | 61.1 (44; 49.6–71.5) |
| 101-300 | 375 | 34.4 (129; 29.8–39.3) | 49.1 (184; 44.0–54.1) |
| 301-1000 | 570 | 42.8 (244; 38.8–46.9) | 53.3 (304; 49.2–57.4) |
| >1000 | 3887 | 60.2 (2341; 58.7–61.8) | 72.1 (2802; 70.7–73.5) |

## Table S8  Gap between many-shot and few-shot accuracy

Source: gap_newcombe.csv and cluster_bootstrap_gap.csv. Differences of observed subgroup accuracies and patent-cluster sensitivity intervals; relates to Fig. 2c.

| Model and setting | Cut-off | Gap (pp) (Newcombe 95% interval) |
|:--|--:|--:|
| Graph2Edits, class unknown | Top-1 | 42.7 (30.8–49.6) |
| Graph2Edits, class unknown | Top-3 | 47.5 (34.0–58.4) |
| Graph2Edits, class unknown | Top-5 | 48.1 (34.5–59.9) |
| Graph2Edits, class unknown | Top-10 | 52.0 (38.4–64.0) |
| Graph2Edits, class known | Top-1 | 45.0 (31.9–54.5) |
| Graph2Edits, class known | Top-3 | 47.8 (34.2–60.0) |
| Graph2Edits, class known | Top-5 | 40.5 (27.5–53.8) |
| Graph2Edits, class known | Top-10 | 36.8 (24.3–50.3) |

Patent-level resampling of the top-1 gap (4,194 patents, 5,000 resamples): class unknown 32.4–51.3 pp; class known 32.8–56.7 pp.

## Note S1 Definitions

**Group assignment.** The count of an edit label is its number of occurrences among the non-terminal edits of all 39,985 processed training reactions. A test reaction is assigned by the smallest count among its non-terminal edits. **Ceiling.** 100 × (n/N)(1 − p) percentage points for a group of n reactions with accuracy p expressed as a proportion in [0,1] among N = 5,004, holding predictions for all other groups fixed. **Unpaired MDD.** Smallest increase over a baseline proportion detectable with 80% power by an equal-size two-sided two-proportion test at α = 0.05 (search step 0.1 percentage points). **Paired MDD.** Smallest net gain δ detectable with 80% power by the exact two-sided McNemar test when a share d of reactions is solved by exactly one model; the number of discordant reactions is binomial(n, d) and the number favouring the second model is binomial(m, (1 + δ/d)/2).


Correctness discordance d and net gain δ in the paired-planning distribution are proportions, not percentages; 0 < d ≤ 1 and 0 ≤ δ ≤ d. Multiply δ by 100 to report a gain in percentage points. "Not reachable" means that the target power cannot be attained at the stated n and d, even at the largest admissible net gain; it is not a missing experiment. S5a uses the specified rounded baselines; the remaining unpaired values in main-text Table 2 use their stated group baselines.
