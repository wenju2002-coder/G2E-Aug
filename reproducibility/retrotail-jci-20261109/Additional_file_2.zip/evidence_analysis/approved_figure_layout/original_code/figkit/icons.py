"""figkit.icons — 原创手写 SVG 图标（100×100 单位框，扁平填色，无渐变/阴影）。

每个函数返回 SVG 片段字符串，坐标在 0–100 内；用 Fig.g(icon, x_mm, y_mm, s) 放置，
s=1.0 约等于 10 mm（Fig 的 1 mm=10 单位，图标框 100 单位）。全部为本库原创绘制，不含任何生成式 AI 像素。
"""
from __future__ import annotations
import math

INK = "#222222"; GREY = "#949494"; LIGHT = "#EDEDED"
BLUE = "#0173B2"; ORANGE = "#DE8F05"; GREEN = "#029E73"; PINK = "#CC78BC"; RED = "#C0392B"
_T = {BLUE: "#CFE3F0", ORANGE: "#F6DDB0", GREEN: "#BFE4D9", PINK: "#EBCDE5", GREY: "#E3E3E3", RED: "#EFC6C0"}


def tint(c):
    return _T.get(c, "#E8E8E8")


def _s(sw=2):
    return f'stroke="{INK}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"'


def test_tubes(colors=(BLUE, ORANGE, GREEN), levels=(0.6, 0.45, 0.7)):
    out = [f'<rect x="8" y="78" width="84" height="8" rx="2" fill="{LIGHT}" {_s(1.6)}/>']
    for i, (c, lv) in enumerate(zip(colors, levels)):
        x = 18 + i * 26
        top, bot = 14, 76
        liq = bot - (bot - top - 8) * lv
        out.append(f'<path d="M{x} {top} V{bot-9} A9 9 0 0 0 {x+18} {bot-9} V{top}" fill="white" {_s()}/>')
        out.append(f'<path d="M{x} {liq} H{x+18} V{bot-9} A9 9 0 0 1 {x} {bot-9} Z" fill="{c}" fill-opacity=".85" stroke="none"/>')
        out.append(f'<path d="M{x} {top} V{bot-9} A9 9 0 0 0 {x+18} {bot-9} V{top}" fill="none" {_s()}/>')
        out.append(f'<line x1="{x-3}" y1="{top}" x2="{x+21}" y2="{top}" {_s()}/>')
    return "".join(out)


def petri_dish(c=BLUE, n=9, seed=3):
    import random
    r = random.Random(seed)
    out = [f'<ellipse cx="50" cy="56" rx="42" ry="22" fill="white" {_s()}/>',
           f'<ellipse cx="50" cy="50" rx="42" ry="22" fill="{tint(c)}" {_s()}/>',
           f'<path d="M8 50 V56 A42 22 0 0 0 92 56 V50" fill="white" fill-opacity=".6" {_s()}/>']
    for _ in range(n):
        a, d = r.uniform(0, 6.28), r.uniform(0, 0.8)
        out.append(f'<circle cx="{50+34*d*math.cos(a):.1f}" cy="{50+16*d*math.sin(a):.1f}" r="{r.uniform(2.2,4):.1f}" fill="{c}" stroke="{INK}" stroke-width="1"/>')
    return "".join(out)


def well_plate(rows=3, cols=4, filled=((0, 0), (1, 1), (2, 2), (0, 3)), c=BLUE):
    out = [f'<rect x="6" y="16" width="88" height="68" rx="6" fill="white" {_s()}/>']
    for i in range(rows):
        for j in range(cols):
            cx, cy = 22 + j * 20, 33 + i * 20
            on = (i, j) in filled
            out.append(f'<circle cx="{cx}" cy="{cy}" r="7.5" fill="{c if on else "white"}" fill-opacity="{.85 if on else 1}" {_s(1.6)}/>')
    return "".join(out)


def mouse(c=GREY, tumor=ORANGE):
    return (f'<ellipse cx="46" cy="62" rx="32" ry="20" fill="{tint(c)}" {_s()}/>'
            f'<circle cx="82" cy="56" r="12" fill="{tint(c)}" {_s()}/>'
            f'<circle cx="78" cy="42" r="6" fill="{tint(c)}" {_s()}/>'
            f'<circle cx="86" cy="53" r="1.6" fill="{INK}"/><circle cx="93" cy="58" r="1.8" fill="{INK}"/>'
            f'<path d="M14 62 C2 60 2 44 12 40" fill="none" {_s()}/>'
            f'<ellipse cx="38" cy="50" rx="9" ry="7" fill="{tumor}" {_s()}/>'
            f'<path d="M30 80 v6 M42 80 v6 M60 80 v6 M72 78 v8" {_s()}/>')


def cell(c=GREEN, nucleus=BLUE):
    return (f'<path d="M50 12 C78 8 92 34 86 56 C82 80 56 92 36 84 C12 74 8 44 20 28 C28 16 40 14 50 12Z" fill="{tint(c)}" {_s()}/>'
            f'<circle cx="52" cy="48" r="17" fill="{nucleus}" fill-opacity=".8" {_s()}/>'
            f'<circle cx="52" cy="48" r="5" fill="white" fill-opacity=".8"/>'
            f'<ellipse cx="26" cy="64" rx="7" ry="4" fill="{ORANGE}" fill-opacity=".8" {_s(1.2)}/>'
            f'<ellipse cx="76" cy="26" rx="6" ry="3.5" fill="{PINK}" fill-opacity=".9" {_s(1.2)}/>')


def helix(x0, y0, length, turns, amp=9, c=BLUE, sw=7):
    n = 60
    pts = []
    for i in range(n + 1):
        t = i / n
        pts.append((x0 + length * t, y0 + amp * math.sin(2 * math.pi * turns * t)))
    d = "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts)
    return (f'<path d="{d}" fill="none" stroke="{INK}" stroke-width="{sw+2.4}" stroke-linecap="round" stroke-linejoin="round"/>'
            f'<path d="{d}" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>')


def beta_arrow(x, y, w, c=ORANGE, h=11):
    return (f'<path d="M{x} {y-h/2+2} H{x+w-9} V{y-h/2-3} L{x+w} {y} L{x+w-9} {y+h/2+3} V{y+h/2-2} H{x} Z" '
            f'fill="{c}" {_s(1.6)}/>')


def protein(pocket=True, ligand=True, c1=BLUE, c2=ORANGE, c3=GREY):
    """卡通蛋白：螺旋＋β 折叠＋环，可带口袋与配体棒状。"""
    o = [f'<path d="M10 70 C12 52 28 46 40 52 S60 30 78 38 92 60 84 74" fill="none" stroke="{c3}" stroke-width="5" stroke-linecap="round"/>']
    o.append(helix(14, 34, 38, 3.2, 6, c1, 7))
    o.append(helix(52, 76, 36, 3, 5, c1, 7))
    o.append(beta_arrow(26, 58, 34, c2))
    o.append(beta_arrow(46, 20, 34, c2, 10))
    if pocket:
        o.append(f'<ellipse cx="62" cy="52" rx="12" ry="9" fill="{PINK}" fill-opacity=".35" stroke="{PINK}" stroke-width="1.6" stroke-dasharray="3 2.5"/>')
    if ligand:
        o.append(f'<path d="M55 55 L60 49 L66 54 L72 48" fill="none" stroke="{INK}" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/>'
                 f'<circle cx="55" cy="55" r="2.6" fill="{GREEN}" stroke="{INK}" stroke-width="1"/><circle cx="72" cy="48" r="2.6" fill="{RED}" stroke="{INK}" stroke-width="1"/>')
    return "".join(o)


def antibody(c=BLUE):
    arm = lambda sx: (f'<path d="M50 56 L{50+sx*26} 22" stroke="{INK}" stroke-width="15" stroke-linecap="round"/>'
                      f'<path d="M50 56 L{50+sx*26} 22" stroke="{c}" stroke-width="11" stroke-linecap="round"/>')
    return (arm(-1) + arm(1) + f'<path d="M50 56 V88" stroke="{INK}" stroke-width="15" stroke-linecap="round"/>'
            f'<path d="M50 56 V88" stroke="{tint(c)}" stroke-width="11" stroke-linecap="round"/>'
            f'<circle cx="24" cy="22" r="4" fill="{ORANGE}" stroke="{INK}" stroke-width="1"/><circle cx="76" cy="22" r="4" fill="{ORANGE}" stroke="{INK}" stroke-width="1"/>')


def dna(c1=BLUE, c2=ORANGE):
    pts1 = [(30 + 18 * math.sin(i / 6 * math.pi), 10 + i * 6.2) for i in range(0, 15)]
    pts2 = [(70 - 18 * math.sin(i / 6 * math.pi), y) for (_, y), i in zip(pts1, range(15))]
    d1 = "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts1)
    d2 = "M" + " L".join(f"{x:.1f} {y:.1f}" for x, y in pts2)
    rungs = "".join(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{GREY}" stroke-width="2"/>'
                    for a, b in list(zip(pts1, pts2))[1::2])
    return rungs + f'<path d="{d1}" fill="none" stroke="{c1}" stroke-width="4.5" stroke-linecap="round"/><path d="{d2}" fill="none" stroke="{c2}" stroke-width="4.5" stroke-linecap="round"/>'


def chip(c=BLUE, label=""):
    pins = "".join(f'<line x1="{x}" y1="14" x2="{x}" y2="26" {_s(2)}/><line x1="{x}" y1="74" x2="{x}" y2="86" {_s(2)}/>' for x in (34, 50, 66))
    pins += "".join(f'<line x1="14" y1="{y}" x2="26" y2="{y}" {_s(2)}/><line x1="74" y1="{y}" x2="86" y2="{y}" {_s(2)}/>' for y in (34, 50, 66))
    return pins + f'<rect x="24" y="24" width="52" height="52" rx="5" fill="{tint(c)}" {_s()}/><rect x="36" y="36" width="28" height="28" rx="3" fill="{c}" fill-opacity=".85" {_s(1.6)}/>'


def database(c=BLUE, n=3):
    o = []
    for i in range(n):
        y = 22 + i * 22
        o.append(f'<path d="M16 {y} V{y+16} A34 9 0 0 0 84 {y+16} V{y}" fill="{tint(c)}" {_s()}/>')
        o.append(f'<ellipse cx="50" cy="{y}" rx="34" ry="9" fill="{c if i==0 else tint(c)}" fill-opacity="{.8 if i==0 else 1}" {_s()}/>')
    return "".join(o)


def document(c=BLUE, lines=4):
    o = [f'<path d="M24 8 H62 L78 24 V92 H24 Z" fill="white" {_s()}/><path d="M62 8 V24 H78" fill="{tint(c)}" {_s()}/>']
    for i in range(lines):
        o.append(f'<line x1="32" y1="{38+i*12}" x2="{70 if i%2==0 else 60}" y2="{38+i*12}" stroke="{c}" stroke-width="3" stroke-linecap="round"/>')
    return "".join(o)


def flask(c=ORANGE, level=0.5):
    liq = 88 - 40 * level
    return (f'<path d="M40 10 H60 M43 10 V40 L16 84 A6 6 0 0 0 21 92 H79 A6 6 0 0 0 84 84 L57 40 V10" fill="white" {_s()}/>'
            f'<path d="M{30-(liq-56)*0.1:.1f} {liq} H{70+(liq-56)*0.1:.1f} L84 84 A6 6 0 0 1 79 92 H21 A6 6 0 0 1 16 84 Z" fill="{c}" fill-opacity=".8" stroke="none"/>'
            f'<path d="M40 10 H60 M43 10 V40 L16 84 A6 6 0 0 0 21 92 H79 A6 6 0 0 0 84 84 L57 40 V10" fill="none" {_s()}/>')


def funnel(c=BLUE, n=3):
    o = [f'<path d="M10 14 H90 L58 54 V86 L42 78 V54 Z" fill="{tint(c)}" {_s()}/>']
    for i in range(n):
        o.append(f'<circle cx="{30+i*20}" cy="{26}" r="5" fill="{c}" fill-opacity=".85" stroke="{INK}" stroke-width="1"/>')
    return "".join(o)


def shield_check(c=GREEN):
    return (f'<path d="M50 8 L86 20 V48 C86 70 70 84 50 92 C30 84 14 70 14 48 V20 Z" fill="{tint(c)}" {_s()}/>'
            f'<path d="M32 50 L45 63 L69 37" fill="none" stroke="{c}" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>')


def magnifier(c=BLUE):
    return (f'<circle cx="42" cy="42" r="26" fill="{tint(c)}" {_s(3)}/><line x1="62" y1="62" x2="88" y2="88" stroke="{INK}" stroke-width="9" stroke-linecap="round"/>'
            f'<path d="M30 40 Q42 26 54 40" fill="none" stroke="white" stroke-width="3" stroke-linecap="round"/>')


def network(c=BLUE, seed=5, n=9):
    import random
    r = random.Random(seed)
    pts = [(r.uniform(14, 86), r.uniform(14, 86)) for _ in range(n)]
    o = []
    for i, a in enumerate(pts):
        for b in pts[i + 1:i + 3]:
            o.append(f'<line x1="{a[0]:.1f}" y1="{a[1]:.1f}" x2="{b[0]:.1f}" y2="{b[1]:.1f}" stroke="{GREY}" stroke-width="2"/>')
    for i, (x, y) in enumerate(pts):
        o.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="6" fill="{[BLUE, ORANGE, GREEN][i%3] if c is None else c}" stroke="{INK}" stroke-width="1.4"/>')
    return "".join(o)


def balance(c=BLUE):
    return (f'<line x1="50" y1="14" x2="50" y2="84" {_s(3)}/><line x1="20" y1="30" x2="80" y2="30" {_s(3)}/>'
            f'<path d="M12 56 H36 Q24 70 12 56Z M64 56 H88 Q76 70 64 56Z" fill="{tint(c)}" {_s(2)}/>'
            f'<line x1="20" y1="30" x2="12" y2="56" {_s(1.4)}/><line x1="20" y1="30" x2="36" y2="56" {_s(1.4)}/>'
            f'<line x1="80" y1="30" x2="64" y2="56" {_s(1.4)}/><line x1="80" y1="30" x2="88" y2="56" {_s(1.4)}/>'
            f'<path d="M36 90 H64" {_s(4)}/>')


def lock(c=GREY):
    return (f'<path d="M32 44 V32 A18 18 0 0 1 68 32 V44" fill="none" {_s(5)}/>'
            f'<rect x="22" y="44" width="56" height="42" rx="6" fill="{tint(c)}" {_s()}/><circle cx="50" cy="62" r="5" fill="{INK}"/><line x1="50" y1="64" x2="50" y2="76" {_s(3)}/>')


def mini_bars(vals=(0.4, 0.7, 0.55, 0.9), c=BLUE, hi=3):
    o = [f'<line x1="10" y1="88" x2="92" y2="88" {_s(2)}/>']
    w = 82 / len(vals)
    for i, v in enumerate(vals):
        o.append(f'<rect x="{12+i*w:.1f}" y="{88-v*70:.1f}" width="{w*0.7:.1f}" height="{v*70:.1f}" fill="{RED if i==hi else c}" fill-opacity=".9" stroke="{INK}" stroke-width="1.4"/>')
    return "".join(o)


def tick(c=GREEN):
    return f'<circle cx="50" cy="50" r="36" fill="{c}" stroke="{INK}" stroke-width="2"/><path d="M32 52 L45 65 L69 37" fill="none" stroke="white" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>'


def cross(c=RED):
    return f'<circle cx="50" cy="50" r="36" fill="{c}" stroke="{INK}" stroke-width="2"/><path d="M34 34 L66 66 M66 34 L34 66" stroke="white" stroke-width="9" stroke-linecap="round"/>'


def question(c=GREY):
    return f'<circle cx="50" cy="50" r="36" fill="white" stroke="{c}" stroke-width="4" stroke-dasharray="6 5"/><text x="50" y="66" font-family="Arial, Helvetica, sans-serif" font-size="46" font-weight="700" text-anchor="middle" fill="{c}">?</text>'


def tree(c=GREEN):
    return (f'<line x1="50" y1="90" x2="50" y2="50" {_s(4)}/><path d="M50 62 L26 38 M50 62 L74 38 M26 38 L16 18 M26 38 L36 18 M74 38 L64 18 M74 38 L84 18" fill="none" {_s(3)}/>'
            + "".join(f'<circle cx="{x}" cy="{y}" r="6" fill="{c}" stroke="{INK}" stroke-width="1.4"/>' for x, y in [(16, 16), (36, 16), (64, 16), (84, 16), (50, 90)]))


def pill(c=ORANGE):
    return (f'<g transform="rotate(-35 50 50)"><rect x="12" y="34" width="76" height="32" rx="16" fill="white" {_s()}/>'
            f'<path d="M50 34 H28 A16 16 0 0 0 28 66 H50 Z" fill="{c}" {_s()}/><line x1="50" y1="34" x2="50" y2="66" {_s()}/></g>')


def plant(c=GREEN):
    return (f'<path d="M50 90 V44" {_s(4)}/><path d="M50 62 C28 62 22 44 24 30 C42 30 50 44 50 62Z M50 52 C72 52 80 36 78 22 C60 22 50 36 50 52Z" fill="{c}" fill-opacity=".85" {_s(2)}/>')


def rdkit_mol(smiles: str, w=100, h=100, bw=1.6):
    """RDKit 矢量分子：返回 (svg 片段, w, h)，放入 Fig.g 时 s=缩放。失败返回占位六边形。"""
    try:
        from rdkit import Chem
        from rdkit.Chem.Draw import rdMolDraw2D
        m = Chem.MolFromSmiles(smiles)
        d = rdMolDraw2D.MolDraw2DSVG(w * 4, h * 4)
        o = d.drawOptions(); o.bondLineWidth = bw * 2; o.clearBackground = False; o.padding = 0.05
        rdMolDraw2D.PrepareAndDrawMolecule(d, m)
        d.FinishDrawing()
        s = d.GetDrawingText()
        s = s[s.index("<rect") if "<rect" in s else s.index("<path"):s.rindex("</svg>")]
        import re
        s = re.sub(r"<rect[^>]*style='opacity:1\.0;fill:#FFFFFF[^>]*/>", "", s, count=1)
        return f'<g transform="scale(0.25)">{s}</g>'
    except Exception:
        pts = " ".join(f"{50+30*math.cos(a*math.pi/3):.1f},{50+30*math.sin(a*math.pi/3):.1f}" for a in range(6))
        return f'<polygon points="{pts}" fill="none" stroke="{INK}" stroke-width="2.4"/>'


ALL = {k: v for k, v in dict(test_tubes=test_tubes, petri_dish=petri_dish, well_plate=well_plate, mouse=mouse, cell=cell,
                             protein=protein, antibody=antibody, dna=dna, chip=chip, database=database, document=document,
                             flask=flask, funnel=funnel, shield_check=shield_check, magnifier=magnifier, network=network,
                             balance=balance, lock=lock, mini_bars=mini_bars, tick=tick, cross=cross, question=question,
                             tree=tree, pill=pill, plant=plant).items()}
