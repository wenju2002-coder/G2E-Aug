"""Local extensions on top of the shared figure toolkit (same visual language)."""
import os, sys
_HERE = os.path.dirname(os.path.abspath(__file__))
for _c in (_HERE, os.path.join(_HERE, "..", "_shared")):
    if os.path.exists(os.path.join(_c, "figstyle.py")):
        sys.path.insert(0, _c)
        break
import numpy as np
import figstyle as fs
from matplotlib import patches
import matplotlib.pyplot as plt

MANY, MEDIUM, FEW = fs.BASE, fs.WARN, fs.OURS      # frequency groups: head / middle / tail
GCOL = {"Many": MANY, "Medium": MEDIUM, "Few": FEW}
GLAB = {"Many": "Many-shot", "Medium": "Medium-shot", "Few": "Few-shot"}
M_BASE, M_AUG = "#6B7280", "#3E9C8B"                # Graph2Edits (grey) vs Graph2Edits-Aug (teal)


def ci_point(ax, x, y, lo, hi, color, filled=True, s=14, lw=0.9, orient="v", zorder=3, label=None):
    """Point with interval; hollow marker = reaction class known."""
    if orient == "v":
        ax.plot([x, x], [lo, hi], color=color, lw=lw, solid_capstyle="round", zorder=zorder - 1)
        ax.scatter([x], [y], s=s, facecolor=color if filled else "white", edgecolor=color, linewidth=0.9, zorder=zorder, label=label)
    else:
        ax.plot([lo, hi], [y, y], color=color, lw=lw, solid_capstyle="round", zorder=zorder - 1)
        ax.scatter([x], [y], s=s, facecolor=color if filled else "white", edgecolor=color, linewidth=0.9, zorder=zorder, label=label)


def shade_groups(ax, edges_x, orient="x", alpha=0.07):
    """Background bands for the three frequency groups; edges_x = [(x0,x1,group), ...]."""
    for x0, x1, g in edges_x:
        if orient == "x":
            ax.axvspan(x0, x1, color=GCOL[g], alpha=alpha, lw=0, zorder=0)
        else:
            ax.axhspan(x0, x1, color=GCOL[g], alpha=alpha, lw=0, zorder=0)


def tag(ax, text, x=0.02, y=0.97, size=5.2, color=fs.INK, ha="left", va="top", weight="normal"):
    ax.text(x, y, text, transform=ax.transAxes, ha=ha, va=va, fontsize=size, color=color, fontweight=weight, linespacing=1.25)


def legend_marker(ax, entries, loc="upper right", bbox=None, ncol=1, size=5.2):
    """entries: [(label, color, filled)]"""
    hs = []
    for lab, col, filled in entries:
        hs.append(plt.Line2D([0], [0], marker="o", ls="", markersize=3.6, markerfacecolor=col if filled else "white", markeredgecolor=col, markeredgewidth=0.9, label=lab))
    return ax.legend(handles=hs, loc=loc, bbox_to_anchor=bbox, ncol=ncol, fontsize=size, borderaxespad=0.2, handletextpad=0.3)
