# Final native-source manuscript figures 2026-11-06

The final figures are in ../figures/. Regenerate Figures 2 and 4 with python code/run_compact_previews.py; regenerate Figures 3 and 5 with python code/run_figures.py --figures 3 5; Figure 1 uses python code/run_fig1.py. Do not use an older bulk generator to overwrite the submitted Figures 2 and 4. Create local figures/ and verification/ if missing. The scripts retain the existing Windows font and rendering dependencies.

Figure 2b has its descriptor and bin counts above the panel. Figure 2c has an explicitly placed left axis title; panels d/e use abbreviations defined in the manuscript caption. Figure 4d uses Top-k and increased row spacing; the common model legend is above the top row. Numerical coordinates, intervals, colours, predictions and statistics are unchanged. Earlier approved Figure 3e and Figure 4e annotations are retained.

Additional approved narrow revision: low-contrast colored text in Figures 3/4 is darkened; Figure 1 molecular bonds and point outlines have a thicker stroke. All path coordinates, text positions, numbers, data, curves and layout remain unchanged. Minimum Figure 1 stroke at the current manuscript widths exceeds 0.3 pt.
