# RetroTail evidence source map

## Data provenance and interpretation

This PDF is a supplementary statistical report, not an independent dataset or a new model evaluation. Observed summaries use the archived processed USPTO-50K data and four model–setting prediction tables for the same 5,004 test reactions: Graph2Edits and Graph2Edits-Aug, each with reaction-class input withheld or supplied. The four ranked-record tables are Analysis/baseline_unknown_per_reaction.csv, Analysis/baseline_known_per_reaction.csv, Analysis/aug_unknown_per_reaction.csv and Analysis/aug_known_per_reaction.csv in Online Resource 2 (ESM_2.zip).

Tables S1–S4 and S6–S8 summarize the archived records or features derived from the processed data. Table S5 contains power-planning calculations under specified sample-size, baseline-accuracy, effect-size and correctness-discordance assumptions. Its values are not observed model improvements, extra test sets or multi-seed experiments. Hypothetical planning is distinguished from measured performance throughout.

Unless stated otherwise, percentages are rounded to one decimal and counts are exact. Values are rounded directly from unrounded integer ratios, never from already-rounded displays. Thus 4,471/5,004 is 89.35% at two decimals in main-text Table 1 but 89.3% here; 3,360/5,004 is 67.15% at two decimals but 67.1% here. These are identical predictions. Wilson intervals are 95% confidence intervals. Planning baselines in S5a are specified rounded values (13.5%, 38.5% and 56.2%), whereas observed accuracies and conditional ceilings use exact counts.

Many, Medium and Few abbreviate many-shot, medium-shot and few-shot. Pooled combines all 5,004 reactions. Known/Unknown refer only to whether the reaction-class label is supplied to the predictor. Correctness discordance means that exactly one model is correct at a specified top-k cut-off; different predictions that are both incorrect are not discordant pairs. Frequency is defined from the recorded reference edits, not from chemical novelty.

Source notes below name files relative to evidence_analysis/source_data/analysis_tables/ inside ESM_2.zip. The evidence-only make_si_evidence.py reads these CSVs and creates this Markdown; typeset_si.py produces the PDF. Both are in evidence_analysis/scripts/. README_DMKD.md provides commands. These scripts do not generate model predictions.


## Table S1

acc_by_bucket.csv. Integer success counts and Wilson intervals from the four archived per-reaction tables; expands main-text Table 1.

## Table S2

threshold_sensitivity_rederived.csv. The same records re-stratified under three threshold pairs; corresponds to Fig. 2d and does not involve retraining.

## Table S3

per_reaction_features.csv (group and class summaries); similarity_by_bucket.csv provides a separate similarity summary. Relates to Fig. 5. Distinct-patent counts overlap across strata and must not be summed as a count of unique patents in the full test set.

## Table S4

paired_tests.csv. Exactly matched reactions, baseline-only and Aug-only correctness counts, and 32 exact McNemar tests with Holm correction; corresponds to Fig. 4.

## Table S5

unpaired_mdd_curve.csv (S5a), paired_planning.csv (S5b) and paired_required_n.csv (S5c). These are calculations under specified planning assumptions, not additional model runs or observed gains; correspond to Fig. 3c,d,f.

## Table S6

logit_exploratory.csv and logit_with_similarity.csv. Exploratory associations with log10(training count + 1), conditional on the stated covariates; relates to Fig. 2e. These are not causal effects or changes to model-training logits.

## Table S7

fine_bins.csv. Eight finer strata of the same archived Graph2Edits predictions; corresponds to the submitted Fig. 2b, not its historical panel label.

## Table S8

gap_newcombe.csv and cluster_bootstrap_gap.csv. Differences of observed subgroup accuracies and patent-cluster sensitivity intervals; relates to Fig. 2c.

Current Fig. 2 mapping: a = accuracy by group (S1); b = finer bins (S7); c = head-to-tail gaps (S8); d = threshold sensitivity (S2); e = logistic associations (S6). Original source_data/figure_panels identifiers are historical and are not current panel names.

Fig. 1b contains illustrative molecules, not evaluated test reactions. Fig. 5d uses a displayed random sample of up to 150 reactions per group for its half-violin, points and white summaries; printed medians use complete groups.
