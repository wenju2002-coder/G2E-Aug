"""Create an isolated, evidence-only figure layout copy. No model execution."""
from pathlib import Path
import shutil, sys, json, hashlib, copy, re, textwrap, subprocess
import numpy as np
from lxml import etree as ET

ROOT = Path(r'E:\issue_code\G2E-Aug')
BASE = ROOT / '新建文件夹/张文举_G2E_261102_2022_v03'
PACKAGE = BASE / '附件/261101_0658_论文_G2E_CILS重写包/G2E_CILS_rewrite_package'
SOURCE = BASE / 'output/DMKD3区B类/01_Manuscript/figures'
DEST = BASE / 'output/DMKD_图件字号优化副本_20261105'
PACKAGED = Path(__file__).parent.name == 'code'
if PACKAGED:
    DEST = Path(__file__).resolve().parent.parent
PY = Path(sys.executable)
LIBS = ROOT / 'tmp/dmkd_retarget_20261105/libs'
sys.path.insert(0, str(LIBS))
sys.path.insert(0, str(ROOT / 'tmp/dmkd_figures_readability_20261105/libs'))
sys.path.insert(0, str(DEST / 'code'))
sys.path.append(r'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\Lib\site-packages')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    for name in ['code', 'source_data/analysis_tables', 'original_svg', 'figures', 'verification']:
        (DEST/name).mkdir(parents=True, exist_ok=True)
    if PACKAGED:
        return
    for name in ['make_figures.py', 'figstyle.py', 'figlocal.py']:
        shutil.copy2(PACKAGE/'scripts'/name, DEST/'code'/name)
    for path in (PACKAGE/'source_data/analysis_tables').glob('*.csv'):
        shutil.copy2(path, DEST/'source_data/analysis_tables'/path.name)
    for path in SOURCE.glob('*.svg'):
        shutil.copy2(path, DEST/'original_svg'/path.name)
    shutil.copy2(__file__, DEST/'code'/Path(__file__).name)

def scientific_snapshot(fig):
    """Data coordinates, uncertainty lines, patches, colors, scales and limits only."""
    axes = []
    def arr(value):
        a = np.ma.asarray(value)
        return {'values': np.asarray(a.filled(np.nan), dtype=float).tolist(),
                'mask': np.ma.getmaskarray(a).tolist()}
    for ax in fig.axes:
        item = dict(xlim=ax.get_xlim(), ylim=ax.get_ylim(), xscale=ax.get_xscale(), yscale=ax.get_yscale(), lines=[], collections=[], patches=[])
        for line in ax.lines:
            item['lines'].append([arr(line.get_xdata()), arr(line.get_ydata()), str(line.get_color()), line.get_linestyle(), line.get_marker()])
        for col in ax.collections:
            item['collections'].append(dict(offsets=arr(col.get_offsets()), paths=[arr(p.vertices) for p in col.get_paths()], colors=arr(col.get_facecolors())))
        for p in ax.patches:
            entry = dict(path=arr(p.get_path().vertices), color=p.get_facecolor())
            if hasattr(p, 'get_xy'): entry['xy'] = np.asarray(p.get_xy()).tolist()
            if hasattr(p, 'get_width'): entry['width'] = p.get_width()
            if hasattr(p, 'get_height'): entry['height'] = p.get_height()
            item['patches'].append(entry)
        axes.append(item)
    return json.dumps(axes, sort_keys=True, allow_nan=True,default=lambda v:v.item() if isinstance(v,np.generic) else str(v))

def plot_figures():
    # Import definitions only: do not execute the original batch writer/main loop.
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.text import Text
    from matplotlib.legend import Legend
    codepath = DEST/'code/make_figures.py'
    raw = codepath.read_text(encoding='utf-8')
    definitions = raw.split('\nFIGS = dict(')[0]
    argv = sys.argv[:]
    sys.argv = [str(codepath), str(DEST/'source_data/analysis_tables'), str(DEST/'verification')]
    scope = {'__file__': str(codepath), '__name__': 'figure_definitions'}
    exec(compile(definitions, str(codepath), 'exec'), scope)
    sys.argv = argv
    report = {}
    # All rectangles are in millimetres from the bottom-left of a 174-mm canvas.
    layouts = {
        2: (243, [(20,176,61,54),(108,176,61,54),(20,95,61,54),(115,95,54,54),(60,16,109,45)]),
        3: (235, [(22,169,60,52),(108,169,61,52),(22,91,60,52),(108,91,61,52),(22,16,60,50),(108,16,61,50)]),
        4: (242, [(21,171,61,55),(108,171,61,55),(35,94,47,56),(108,94,61,56),(21,17,61,58),(113,17,56,58)]),
        5: (246, [(64,182,105,50),(22,90,62,67),(111,90,58,67),(22,18,62,49),(114,18,55,49)]),
    }
    for n in range(2,6):
        fig = scope[f'fig{n}']()
        if n == 2:
            fig.delaxes(fig.axes[0])
            # Match the current evidence manuscript's five-panel lettering and unit.
            for i,ax in enumerate(fig.axes):
                for t in ax.texts:
                    if t.get_text() in list('bcdef') and t.get_fontweight() == 'bold':
                        t.set_text(chr(ord('a')+i))
            fig.axes[-1].set_xlabel('Odds ratio of top-1 success\nper 10-fold increase in (count + 1)')
        before = scientific_snapshot(fig)
        h, rects = layouts[n]
        fig.set_size_inches(174/25.4, h/25.4)
        for ax, (x,y,w,ah) in zip(fig.axes, rects):
            ax.set_position([x/174,y/h,w/174,ah/h])
            ax.tick_params(axis='both', which='major', labelsize=8, pad=3)
            ax.xaxis.label.set_size(8.5); ax.yaxis.label.set_size(8.5)
            ax.xaxis.labelpad=6; ax.yaxis.labelpad=6
            ax.title.set_fontsize(8)
            for t in ax.texts:
                if t.get_text() in list('abcdef') and t.get_fontweight() == 'bold':
                    t.set_position((-0.21,1.09)); t.set_fontsize(11)
                else:
                    t.set_fontsize(8)
                    t.set_linespacing(1.15)
            # Wrap long axis labels without altering any words or numerical units.
            for label in [ax.xaxis.label, ax.yaxis.label]:
                txt=label.get_text()
                if '\n' not in txt and len(txt)>40:
                    label.set_text(textwrap.fill(txt, width=38, break_long_words=False, break_on_hyphens=False))
            leg = ax.get_legend()
            if leg:
                for t in leg.get_texts(): t.set_fontsize(7.5)
                leg.get_title().set_fontsize(7.5)
        # Layout-specific typography; scientific artists remain unmodified.
        if n==2:
            a,b,c,d,e=fig.axes
            for t in c.get_xticklabels():
                t.set_fontsize(7);t.set_rotation(35);t.set_ha('right')
            ni=0
            for t in c.texts:
                if t.get_text().startswith('n='):
                    t.set_fontsize(7.5)
                    tx,ty=t.get_position();t.set_position((tx,-.24 if ni%2==0 else -.31));ni+=1
            c.xaxis.labelpad=46
            d.set_ylabel('Thresholds (few-shot n)')
            e.set_yticklabels(['Frequency alone','+ edits, leaving group, class','+ product similarity'])
            for ax in [a,d,e]:
                leg=ax.get_legend()
                if leg:
                    leg.set_bbox_to_anchor((1.0,1.16)); leg._loc=1
            # Reserve the last row's left margin for long forest-plot labels.
            for t in e.get_yticklabels(): t.set_fontsize(7.5)
            for t in e.texts:
                if t.get_text()=='e' and t.get_fontweight()=='bold':t.set_position((-.47,1.12))
        if n==3:
            fig.axes[0].set_xlabel('Gain in pooled top-1 if group\nreaches 100% (pp)')
            fig.axes[5].set_xlabel('Reactions on which\nmodels differ (%)')
            leg=fig.axes[5].get_legend()
            if leg:
                leg.remove()
                fig.axes[5].legend(loc='lower center',bbox_to_anchor=(.5,1.01),fontsize=7,ncol=1,handlelength=1)
            for t in fig.axes[5].texts:
                if t.get_rotation()==90: t.set_fontsize(7)
        if n==4:
            a,b,c,d,e,f=fig.axes
            # Preserve ordinary reading order: a/b, c/d, e/f.
            for ax,rect in [(d,(108,94,61,56)),(e,(21,17,61,58)),(f,(113,17,56,58))]:
                x,y,w,ah=rect; ax.set_position([x/174,y/h,w/174,ah/h])
            for ax in [a,b]: ax.set_xlabel('Few-shot accuracy,\nn = 52 (%)')
            c.set_yticklabels([t.get_text().replace(' · ', '\n') for t in c.get_yticklabels()],fontsize=7)
            c.set_xlabel('Reactions solved by\none model only')
            for t in c.texts:
                if ' only' in t.get_text(): t.set_fontsize(6.5)
            for t in d.get_yticklabels(): t.set_fontsize(7)
            for t in d.texts:
                if '-shot' in t.get_text() or t.get_text()=='Pooled': t.set_fontsize(7)
            e.set_xlabel('Comparisons ranked\nby raw p')
            d.set_xlabel('Aug minus Graph2Edits (pp)\npaired bootstrap 95% interval')
            f.set_title('Net extra successes\n(Aug − Graph2Edits)',fontsize=8)
            for t in f.get_yticklabels(): t.set_fontsize(7)
            for t in f.texts:
                if 'U, class' in t.get_text(): t.set_text('U, class unknown;\nK, class known'); t.set_position((.5,-.19));t.set_fontsize(7)
        if n==5:
            a,b,c,d,e=fig.axes
            a.set_xlabel('Share of class test reactions (%); white numbers:\nmedium-shot / few-shot counts')
            a.set_position([64/174,182/h,105/174,50/h])
            for t in a.get_yticklabels(): t.set_fontsize(7.5)
            a.texts[-1].set_position((-.57,1.10))
            b.set_title('Top-1 accuracy, % (n);\ncells with n < 5 not shown',fontsize=8)
            for t in b.texts:
                if t.get_text() not in list('abcde'): t.set_fontsize(7.5)
            d.set_ylabel('Nearest training product,\nTanimoto similarity')
            for t in d.texts:
                if t.get_text().startswith('median'):t.set_fontsize(6.5)
            for t in e.get_yticklabels():t.set_fontsize(7)
            for t in e.texts:
                if t.get_text().startswith('Class '):t.set_fontsize(7)
        after=scientific_snapshot(fig)
        assert before==after, f'Numerical artist mutation: fig{n}'
        report[f'fig{n}']={'scientific_artist_sha256_before':hashlib.sha256(before.encode()).hexdigest(),
                           'scientific_artist_sha256_after':hashlib.sha256(after.encode()).hexdigest(),
                           'unchanged':True,'canvas_mm':[174,h]}
        for fmt in ['pdf','svg']:
            fig.savefig(DEST/f'figures/fig{n}.{fmt}',facecolor='white')
        plt.close(fig)
    # Export the actual values used, excluding the deliberately removed old panel 2a.
    scope['SD'].panels.pop('2a',None)
    for old,new in [('2b','2a'),('2c','2b'),('2d','2c'),('2e','2d'),('2f','2e')]:
        scope['SD'].panels[new]=scope['SD'].panels.pop(old)
    scope['SD'].write(str(DEST/'source_data/plotted_panels'))
    return report

def fig1_layout():
    # Keep the original SVG primitives, molecular drawings and numerical labels.
    ns='http://www.w3.org/2000/svg'; tag=lambda x:f'{{{ns}}}{x}'
    original=ET.parse(str(DEST/'original_svg/fig1.svg')).getroot()
    groups=[]; current=None
    for child in original:
        if ET.QName(child).localname=='text' and ''.join(child.itertext()) in list('abcdef'):
            current=ET.Element(tag('g'));groups.append(current)
        if current is not None:current.append(copy.deepcopy(child))
    assert len(groups)==6
    # Larger fonts are obtained by uniform panel scale, never by changing paths.
    boxes=[(0,0,510,670),(520,0,760,670),(1290,0,510,600),(0,700,600,540),(610,700,610,540),(1210,700,590,540)]
    placements=[(3,3,80),(89,3,82),(3,111,80),(89,111,82),(3,211,80),(89,211,82)]
    out=ET.Element(tag('svg'),nsmap={None:ns},width='174mm',height='289mm',viewBox='0 0 174 289')
    ET.SubElement(out,tag('rect'),width='174',height='289',fill='white')
    for group,box,place in zip(groups,boxes,placements):
        x,y,w,hh=box; px,py,pw=place;s=pw/w
        group.set('transform',f'translate({px} {py}) scale({s}) translate({-x} {-y})')
        out.append(group)
    for i,group in enumerate(groups):
        for t in group.iter(tag('text')):
            t.set('font-family','Arial-Bold' if t.get('font-weight')=='700' else 'Arial')
        if i in [1,3,4,5]:
            for t in group.iter(tag('text')):
                if 'font-size' in t.attrib:
                    t.set('font-size',str(float(t.get('font-size'))*1.15))
        if i==1:
            # Wrap only the long heading. Its words and meaning are unchanged.
            for t in group:
                if ET.QName(t).localname=='text' and ''.join(t.itertext()).startswith('A reaction takes'):
                    t.text=None
                    for ch in list(t):t.remove(ch)
                    t.set('y','18')
                    for j,line in enumerate(['A reaction takes the count','of its rarest edit']):
                        span=ET.SubElement(t,tag('tspan'),x=t.get('x'),dy='0' if j==0 else '30');span.text=line
    dest=DEST/'figures/fig1.svg'
    ET.ElementTree(out).write(str(dest),encoding='utf-8',xml_declaration=True)
    # Verify every original scientific/non-text primitive is retained verbatim.
    before=[ET.tostring(el) for g in groups for el in g.iter() if ET.QName(el).localname in ['path','line','rect','circle','polygon','ellipse','polyline']]
    afterroot=ET.parse(str(dest)).getroot()
    after=[ET.tostring(el) for g in list(afterroot)[1:] for el in g.iter() if ET.QName(el).localname in ['path','line','rect','circle','polygon','ellipse','polyline']]
    assert before==after
    from svglib.svglib import svg2rlg
    from reportlab.graphics import renderPDF
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    # Explicit families retain the source SVG's bold emphasis and embed fonts.
    for name,file in [('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf'),('Times-Roman','times.ttf')]:
        pdfmetrics.registerFont(TTFont(name,str(Path(r'C:\Windows\Fonts')/file)))
    renderPDF.drawToFile(svg2rlg(str(dest)),str(DEST/'figures/fig1.pdf'))
    return {'unchanged_graphic_primitives':True,'primitive_count':len(before),'canvas_mm':[174,289]}

def main():
    prepare()
    source_svg = DEST/'original_svg' if PACKAGED else SOURCE
    originals={p.name:sha(p) for p in source_svg.glob('*.svg')}
    report=plot_figures();report['fig1']=fig1_layout()
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    # Rasterize final vector PDFs, not resized source bitmaps.
    poppler=r'E:\texlive\2026\bin\windows\pdftoppm.exe'
    for n in range(1,6):
        pdf=DEST/f'figures/fig{n}.pdf'
        subprocess.run([poppler,'-r','600','-singlefile','-png',str(pdf),str(DEST/f'figures/fig{n}')],check=True,capture_output=True)
        subprocess.run([poppler,'-r','110','-singlefile','-png',str(pdf),str(DEST/f'verification/fig{n}_preview')],check=True,capture_output=True)
    assert originals=={p.name:sha(p) for p in source_svg.glob('*.svg')}
    report['source_svg_sha256']=originals
    report['source_csv_sha256']={p.name:sha(p) for p in (DEST/'source_data/analysis_tables').glob('*.csv')}
    (DEST/'verification/data_integrity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(DEST)

if __name__=='__main__':main()
