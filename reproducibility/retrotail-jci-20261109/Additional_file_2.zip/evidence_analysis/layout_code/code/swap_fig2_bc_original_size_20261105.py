"""Keep Figure 2's original outer dimensions; swap former b/c panels."""
from pathlib import Path
import sys, json, hashlib, shutil, importlib.util, subprocess
import numpy as np

ROOT=Path(r'E:\issue_code\G2E-Aug')
BASE=ROOT/'新建文件夹/张文举_G2E_261102_2022_v03/output'
PRIOR=BASE/'DMKD_图件字号优化副本_20261105'
DEST=BASE/'DMKD_图2原尺寸_bc对调预览_20261105'
PACKAGED=Path(__file__).parent.name=='code'
if PACKAGED:DEST=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(DEST/'code'))
sys.path.append(r'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\Lib\site-packages')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    for d in ['code','data','original','qa']:(DEST/d).mkdir(parents=True,exist_ok=True)
    if not PACKAGED:
        shutil.copy2(__file__,DEST/'code'/Path(__file__).name)
        for name in ['make_figures.py','figstyle.py','figlocal.py','enlarge_dmkd_figures_20261105.py']:
            shutil.copy2(PRIOR/'code'/name,DEST/'code'/name)
        shutil.copytree(PRIOR/'source_data/analysis_tables',DEST/'data/analysis_tables',dirs_exist_ok=True)
        for ext in ['svg','pdf']:
            shutil.copy2(BASE/f'DMKD3区B类/03_LaTeX_Source/fig2.{ext}',DEST/f'original/Figure_2_before.{ext}')
    protected={str(p):sha(p) for p in (BASE/'DMKD3区B类').rglob('*') if p.suffix in ['.docx','.md','.tex','.svg','.pdf']}
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    spec=importlib.util.spec_from_file_location('audit',DEST/'code/enlarge_dmkd_figures_20261105.py')
    audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
    p=DEST/'code/make_figures.py'
    raw=p.read_text(encoding='utf-8').split('\nFIGS = dict(')[0]
    argv=sys.argv[:];sys.argv=[str(p),str(DEST/'data/analysis_tables'),str(DEST/'qa')]
    scope={'__file__':str(p),'__name__':'plot_definitions'}
    exec(compile(raw,str(p),'exec'),scope);sys.argv=argv
    fig=scope['fig2']();fig.delaxes(fig.axes[0])
    top1,gap,fine,threshold,odds=fig.axes
    before=audit.scientific_snapshot(fig)
    # The order in fig.axes stays the original scientific order for auditing.
    # Only the screen locations and panel letters are changed.
    W,H=180,118
    fig.set_size_inches(W/25.4,H/25.4)
    placements=[
        (top1,'a',(17,73,54,35)),
        (fine,'b',(94,73,80,35)),
        (gap,'c',(13,17,41,32)),
        (threshold,'d',(77,17,40,32)),
        (odds,'e',(140,17,37,32)),
    ]
    panel_old={top1:'b',gap:'c',fine:'d',threshold:'e',odds:'f'}
    for ax,letter,(x,y,w,h) in placements:
        ax.set_position([x/W,y/H,w/W,h/H])
        ax.tick_params(labelsize=5.5,pad=1.8)
        ax.xaxis.label.set_fontsize(6.2);ax.yaxis.label.set_fontsize(6.2)
        ax.xaxis.labelpad=3;ax.yaxis.labelpad=3
        for t in ax.texts:
            if t.get_text()==panel_old[ax] and t.get_fontweight()=='bold':
                t.set_text(letter);t.set_fontsize(8)
                t.set_position((-.12 if ax is fine else -.24,1.10))
            elif t.get_fontsize()<5.2:
                t.set_fontsize(5.2)
        leg=ax.get_legend()
        if leg:
            for t in leg.get_texts():t.set_fontsize(5.2)
    # An axes-width change changes the layout, not x/y data or marker shapes.
    fine.set_xticks(fine.get_xticks(),[t.get_text().replace('\n','') for t in fine.get_xticklabels()])
    fine.tick_params(axis='x',labelsize=5.5)
    fine.set_xlabel('Rarest required edit: training occurrences')
    fine.xaxis.labelpad=25
    counts=[]
    for t in fine.texts:
        if t.get_text().startswith('n='):
            x,y=t.get_position();t.set_position((x,-.25));t.set_fontsize(6);counts.append(t)
    assert len(counts)==8 and len({t.get_position()[1] for t in counts})==1
    odds.set_yticklabels(['Frequency alone','+ edits, leaving group,\nclass','+ product similarity'],fontsize=5.2)
    odds.set_xlabel('Odds ratio of top-1 success\nper 10-fold increase in (count + 1)')
    odds.xaxis.label.set_fontsize(5.6)
    gap.set_ylabel('Many-shot minus few-shot (pp)',fontsize=6)
    # Move the two setting tags away from the gap values, without changing words.
    for t in threshold.texts:
        if t.get_text() in ['Class unknown','Class known']:
            _,y=t.get_position();t.set_position((84,y));t.set_ha('right');t.set_fontsize(5.2)
        if t.get_text()=='d' and t.get_fontweight()=='bold':t.set_position((-.40,1.13))
    for t in odds.texts:
        if t.get_text()=='e' and t.get_fontweight()=='bold':t.set_position((-.40,1.13))
    for ax in [threshold,odds]:
        leg=ax.get_legend()
        if leg:leg.set_bbox_to_anchor((1,1.16));leg._loc=1
    fig.canvas.draw();renderer=fig.canvas.get_renderer()
    for l,r in zip(counts,counts[1:]):
        assert l.get_window_extent(renderer).x1+1<r.get_window_extent(renderer).x0,'Count labels overlap'
    after=audit.scientific_snapshot(fig)
    assert before==after,'Scientific data changed'
    for ext in ['pdf','svg','png']:
        fig.savefig(DEST/f'Figure_2_bc_Swapped.{ext}',dpi=600,facecolor='white')
    plt.close(fig)
    from pypdf import PdfReader
    old=PdfReader(DEST/'original/Figure_2_before.pdf').pages[0].mediabox
    new=PdfReader(DEST/'Figure_2_bc_Swapped.pdf').pages[0].mediabox
    assert abs(float(old.width-new.width))<.001 and abs(float(old.height-new.height))<.001
    poppler=r'E:\texlive\2026\bin\windows\pdftoppm.exe'
    subprocess.run([poppler,'-r','180','-singlefile','-png',str(DEST/'Figure_2_bc_Swapped.pdf'),str(DEST/'Figure_2_Preview')],check=True,capture_output=True)
    assert all(sha(Path(p))==v for p,v in protected.items()),'An original manuscript/artifact changed'
    report=dict(original_canvas_mm=[float(old.width)*25.4/72,float(old.height)*25.4/72],new_canvas_mm=[W,H],
        same_outer_size=True,scientific_sha256_before=hashlib.sha256(before.encode()).hexdigest(),
        scientific_sha256_after=hashlib.sha256(after.encode()).hexdigest(),data_and_curves_unchanged=True,
        panel_mapping={'old_a':'new_a','old_b':'new_c','old_c':'new_b','old_d':'new_d','old_e':'new_e'},
        counts_single_line=True,count_labels=[t.get_text() for t in counts],original_artifacts_unchanged=True,
        note='Preview only. Main text references and captions have not been edited. Original small-figure typography is retained; this is not a new final-print compliance claim.')
    (DEST/'qa/verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(DEST)

if __name__=='__main__':main()
