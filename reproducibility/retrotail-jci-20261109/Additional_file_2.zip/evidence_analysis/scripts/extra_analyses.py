"""Planning calculations and paired bootstrap intervals (no inference).  python3 -I scripts/extra_analyses.py <supp_root> <results_dir>"""
import os, sys, numpy as np, pandas as pd
from scipy import stats
ROOT, OUT = sys.argv[1], sys.argv[2]
AN = os.path.join(ROOT, "Analysis")
SETS = ["baseline_unknown", "baseline_known", "aug_unknown", "aug_known"]


def _thr(mmax):
    out = np.full(mmax + 1, -1)
    for m_ in range(1, mmax + 1):
        t = -1
        for cand in range(0, m_ // 2 + 1):
            if 2 * stats.binom.cdf(cand, m_, 0.5) <= 0.05:
                t = cand
            else:
                break
        out[m_] = t
    return out


THR = _thr(4000)


def paired_power(n, d, delta):
    q = 0.5 * (1 + delta / d)
    if q > 1:
        return np.nan
    ms = np.arange(1, n + 1)
    pm = stats.binom.pmf(ms, n, d)
    tt = THR[ms]
    ok = (tt >= 0) & (pm > 1e-14)
    ms, pm, tt = ms[ok], pm[ok], tt[ok]
    return float(np.sum(pm * (stats.binom.cdf(tt, ms, q) + stats.binom.sf(ms - tt - 1, ms, q))))


# 1. reactions needed for 80% power in a paired exact test
rows = []
for delta in [0.03, 0.05, 0.10]:
    for d in [0.10, 0.15, 0.20, 0.30]:
        if delta > d:
            rows.append(dict(delta_pp=delta * 100, discordance=d, n_required=np.nan)); continue
        lo, hi = 20, 3900
        if paired_power(hi, d, delta) < 0.8:
            rows.append(dict(delta_pp=delta * 100, discordance=d, n_required=np.nan)); continue
        while hi - lo > 1:
            mid = (lo + hi) // 2
            if paired_power(mid, d, delta) >= 0.8: hi = mid
            else: lo = mid
        rows.append(dict(delta_pp=delta * 100, discordance=d, n_required=hi))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "paired_required_n.csv"), index=False)

# 2. unpaired MDD curve vs n
def mdd(p1, n, za=1.95996, zb=0.84162):
    for step in range(1, 1000):
        p2 = p1 + step / 1000
        if p2 > 1: return np.nan
        pb = (p1 + p2) / 2
        if p2 - p1 >= za * np.sqrt(2 * pb * (1 - pb) / n) + zb * np.sqrt((p1 * (1 - p1) + p2 * (1 - p2)) / n):
            return step / 10.0
    return np.nan

rows = []
for p in [0.1346, 0.3846, 0.5617]:
    for n in [30, 40, 52, 75, 100, 120, 200, 300, 500, 1000, 2000, 4832]:
        rows.append(dict(p_base=p, n=n, mdd_pp=mdd(p, n)))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "unpaired_mdd_curve.csv"), index=False)

# 3. paired bootstrap CI for the aug - baseline difference
P = {s: pd.read_csv(os.path.join(AN, f"{s}_per_reaction.csv"), usecols=["reaction_index", "reaction_id", "class_number_1_based", "bucket", "min_edit_frequency", "nonterminal_edit_count", "top1", "top3", "top5", "top10"]) for s in SETS}
rng = np.random.default_rng(20261029)
rows = []
for sett in ["unknown", "known"]:
    B, A = P[f"baseline_{sett}"], P[f"aug_{sett}"]
    for b in ["Many", "Medium", "Few", "All"]:
        m = np.ones(len(B), bool) if b == "All" else (B.bucket.values == b)
        n = int(m.sum())
        idx = rng.integers(0, n, size=(10000, n))
        for kk in ["top1", "top3", "top5", "top10"]:
            diff = (A[kk].values[m] - B[kk].values[m]).astype(float)
            boot = diff[idx].mean(axis=1) * 100
            rows.append(dict(setting=sett, bucket=b, metric=kk, n=n, diff_pp=diff.mean() * 100,
                             lo=np.percentile(boot, 2.5), hi=np.percentile(boot, 97.5)))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "paired_bootstrap_ci.csv"), index=False)

# 4. compact per-reaction table for the transferable package
base = P["baseline_unknown"][["reaction_index", "reaction_id", "class_number_1_based", "bucket", "min_edit_frequency", "nonterminal_edit_count"]].copy()
for s in SETS:
    for kk in ["top1", "top3", "top5", "top10"]:
        base[f"{s}_{kk}"] = P[s][kk].values
base.to_csv(os.path.join(OUT, "per_reaction_flags_compact.csv"), index=False)
print("done", len(base))
