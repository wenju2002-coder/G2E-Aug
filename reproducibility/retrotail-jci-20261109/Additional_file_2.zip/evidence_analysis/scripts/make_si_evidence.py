"""Write the Supplementary Information (Markdown) from the analysis tables.  python3 make_si.py <tables_dir> <out.md>"""
import os, sys, pandas as pd, numpy as np
import re
SOURCES = {'S1': 'acc_by_bucket.csv. Integer success counts and Wilson intervals from the four archived per-reaction tables; expands main-text Table 1.', 'S2': 'threshold_sensitivity_rederived.csv. The same records re-stratified under three threshold pairs; corresponds to Fig. 2d and does not involve retraining.', 'S3': 'per_reaction_features.csv (group and class summaries); similarity_by_bucket.csv provides a separate similarity summary. Relates to Fig. 5. Distinct-patent counts overlap across strata and must not be summed as a count of unique patents in the full test set.', 'S4': 'paired_tests.csv. Exactly matched reactions, baseline-only and Aug-only correctness counts, and 32 exact McNemar tests with Holm correction; corresponds to Fig. 4.', 'S5': 'unpaired_mdd_curve.csv (S5a), paired_planning.csv (S5b) and paired_required_n.csv (S5c). These are calculations under specified planning assumptions, not additional model runs or observed gains; correspond to Fig. 3c,d,f.', 'S6': 'logit_exploratory.csv and logit_with_similarity.csv. Exploratory associations with log10(training count + 1), conditional on the stated covariates; relates to Fig. 2e. These are not causal effects or changes to model-training logits.', 'S7': 'fine_bins.csv. Eight finer strata of the same archived Graph2Edits predictions; corresponds to the submitted Fig. 2b, not its historical panel label.', 'S8': 'gap_newcombe.csv and cluster_bootstrap_gap.csv. Differences of observed subgroup accuracies and patent-cluster sensitivity intervals; relates to Fig. 2c.'}
def annotate(si):
    si=re.sub(r'Supplementary Table (\d+)\s*\|',r'Table S\1 ',si)
    si=si.replace('Supplementary Note 1 | Definitions','Note S1 Definitions')
    for k,v in SOURCES.items():
        si=re.sub(r'(## Table '+k+r'[^\n]*\n)',lambda m:m[1]+'\nSource: '+v+'\n',si,count=1)
    si=si.replace('share of reactions on which the models disagree','share of correctness-discordant reactions')
    si=si.replace('% disagree','% correctness discordant')
    si=si.replace('Odds ratio per 10-fold (95% interval)','Odds ratio per 10-fold increase in (training count + 1) (95% interval)')
    si=si.replace('**Ceiling.** (n/N)(1 − p) percentage points for a group of n reactions with accuracy p among N = 5,004.',
       '**Ceiling.** 100 × (n/N)(1 − p) percentage points for a group of n reactions with accuracy p expressed as a proportion in [0,1] among N = 5,004, holding predictions for all other groups fixed.')
    si=si.replace('**a. Unpaired minimum', '**a. Unpaired minimum')
    si=si.replace('## Note S1 Definitions','## Note S1 Definitions')
    si+='\nCorrectness discordance d and net gain δ in the paired-planning distribution are proportions, not percentages; 0 < d ≤ 1 and 0 ≤ δ ≤ d. Multiply δ by 100 to report a gain in percentage points. "Not reachable" means that the target power cannot be attained at the stated n and d, even at the largest admissible net gain; it is not a missing experiment. S5a uses the specified rounded baselines; the remaining unpaired values in main-text Table 2 use their stated group baselines.\n'
    return si

T, OUT = sys.argv[1], sys.argv[2]
rd = lambda n: pd.read_csv(os.path.join(T, n))
acc, thr, pt, pp, req, umdd, lr, lrs, fb = (rd(x) for x in ["acc_by_bucket.csv", "threshold_sensitivity_rederived.csv", "paired_tests.csv", "paired_planning.csv", "paired_required_n.csv", "unpaired_mdd_curve.csv", "logit_exploratory.csv", "logit_with_similarity.csv", "fine_bins.csv"])
feat = rd("per_reaction_features.csv"); cl = rd("cluster_bootstrap_gap.csv"); gap = rd("gap_newcombe.csv")
SETN = {"baseline_unknown": "Graph2Edits, class unknown", "baseline_known": "Graph2Edits, class known", "aug_unknown": "Graph2Edits-Aug, class unknown", "aug_known": "Graph2Edits-Aug, class known"}
def tab(df):
    cols = list(df.columns); out = ["| " + " | ".join(cols) + " |", "|" + "|".join([":--"] + ["--:"] * (len(cols) - 1)) + "|"]
    for r in df.itertuples(index=False): out.append("| " + " | ".join(str(v) for v in r) + " |")
    return "\n".join(out)
from pathlib import Path
L = [Path(__file__).with_name('ESM_frontmatter.md').read_text(encoding='utf8'), '']
# S1
L += ["## Supplementary Table 1 | Top-k accuracy by edit-frequency group for all four model and setting combinations", ""]
rows = []
for s in ["baseline_unknown", "baseline_known", "aug_unknown", "aug_known"]:
    for b in ["Many", "Medium", "Few", "All"]:
        r = {"Model and setting": SETN[s], "Group": "Pooled" if b == "All" else b, "n": int(acc[(acc.setting == s) & (acc.bucket == b)].n.iloc[0])}
        for k in ["top1", "top3", "top5", "top10"]:
            x = acc[(acc.setting == s) & (acc.bucket == b) & (acc.metric == k)].iloc[0]
            r[k.replace("top", "Top-")] = f"{x.pct:.1f} ({int(x.k)}; {x.ci_lo:.1f}–{x.ci_hi:.1f})"
        rows.append(r)
L += [tab(pd.DataFrame(rows)), "", "Cells give percentage, the number of successes and the Wilson interval in parentheses.", ""]
# S2
L += ["## Supplementary Table 2 | Sensitivity of the head-to-tail gap to the group thresholds", ""]
rows = []
for sett in ["unknown", "known"]:
    for lo, hi in [(10, 50), (20, 100), (50, 200)]:
        t = thr[(thr.lo == lo) & (thr.hi == hi) & (thr.setting == sett)].set_index("bucket")
        rows.append({"Class input": sett.capitalize(), "Few below / many above": f"{lo} / {hi}", "n many": int(t.loc["Many", "n"]), "n medium": int(t.loc["Medium", "n"]), "n few": int(t.loc["Few", "n"]),
                     "Many top-1": f"{t.loc['Many','pct1']:.1f}", "Few top-1": f"{t.loc['Few','pct1']:.1f}", "Gap top-1 (pp)": f"{t.loc['Many','pct1']-t.loc['Few','pct1']:.1f}", "Many top-10": f"{t.loc['Many','pct10']:.1f}", "Few top-10": f"{t.loc['Few','pct10']:.1f}"})
L += [tab(pd.DataFrame(rows)), "", "Graph2Edits. The primary pair is 20 / 100. The leaving-group module of Graph2Edits-Aug uses head and tail thresholds of 50 and 10 occurrences, so the 10 / 50 pair coincides with that design.", ""]
# S3
L += ["## Supplementary Table 3 | Properties of the frequency groups", ""]
feat["pat"] = feat.reaction_id.str.replace(r"[-_].*$", "", regex=True)
rows = []
for b in ["Many", "Medium", "Few"]:
    s = feat[feat.bucket == b]
    rows.append({"Group": b, "n": len(s), "Distinct patents": s.pat.nunique(), "With leaving-group edit": f"{int(s.has_leaving_group_edit.sum())} ({100*s.has_leaving_group_edit.mean():.1f}%)", "With unseen edit label": int(s.has_unseen_edit.sum()),
                 "Median non-terminal edits (range)": f"{s.nonterminal_edit_count.median():.0f} ({s.nonterminal_edit_count.min()}–{s.nonterminal_edit_count.max()})", "Median nearest-neighbour similarity": f"{s.product_nn_tanimoto.median():.2f}", "Product identical to a training product": int(s.product_in_train.sum())})
L += [tab(pd.DataFrame(rows)), "", "Nearest-neighbour similarity is the Tanimoto coefficient of Morgan fingerprints (radius 2, 2,048 bits) between the test product and the closest training product. Patents are identified from the reaction identifier.", ""]
cls = pd.crosstab(feat.class_number_1_based, feat.bucket)[["Many", "Medium", "Few"]].reset_index().rename(columns={"class_number_1_based": "Class"})
names = {1: "Heteroatom alkylation and arylation", 2: "Acylation and related processes", 3: "C–C bond formation", 4: "Heterocycle formation", 5: "Protections", 6: "Deprotections", 7: "Reductions", 8: "Oxidations", 9: "Functional-group interconversions", 10: "Functional-group additions"}
cls.insert(1, "Class name", cls.Class.map(names)); cls["Total"] = cls[["Many", "Medium", "Few"]].sum(axis=1)
L += ["Reaction classes 1–10 (stored evaluation index plus one) and group sizes:", "", tab(cls), ""]
# S4
L += ["## Supplementary Table 4 | Exact paired comparisons of Graph2Edits-Aug with Graph2Edits (32 tests)", ""]
d = pt.copy(); d = d.assign(**{"Class input": d.setting.str.capitalize(), "Group": d.bucket.replace({"All": "Pooled"}), "Cut-off": d.metric.str.replace("top", "Top-"), "Diff (pp)": d.diff_pp.round(2), "Baseline only": d.base_only, "Aug only": d.aug_only, "P exact": d.p_exact.map(lambda v: f"{v:.4g}"), "P Holm (32)": d.p_holm.map(lambda v: f"{v:.4g}")})
d = d.rename(columns={"base_k": "Baseline successes", "aug_k": "Aug successes"})
L += [tab(d[["Class input", "Group", "Cut-off", "n", "Baseline successes", "Aug successes", "Baseline only", "Aug only", "Diff (pp)", "P exact", "P Holm (32)"]]), "", "Two-sided exact McNemar test on the reactions solved by only one model; Holm adjustment over all 32 rows.", ""]
# S5
L += ["## Supplementary Table 5 | Planning calculations", ""]
L += ["**a. Unpaired minimum detectable difference (pp), 80% power, two-sided α = 0.05**", ""]
u = umdd.pivot(index="n", columns="p_base", values="mdd_pp"); u.columns = [f"baseline {100*c:.1f}%" for c in u.columns]
L += [tab(u.reset_index().rename(columns={"n": "n per model"})), ""]
L += ["**b. Paired minimum detectable net gain (pp), 80% power, exact test, by share of reactions on which the models disagree**", ""]
p2 = pp.pivot(index="n", columns="discordance", values="paired_mdd_pp"); p2.columns = [f"{int(100*c)}% disagree" for c in p2.columns]
L += [tab(p2.fillna("not reachable").reset_index()), "", "**c. Reactions needed for 80% power in an exact paired test**", ""]
r2 = req.pivot(index="delta_pp", columns="discordance", values="n_required"); r2.columns = [f"{int(100*c)}% disagree" for c in r2.columns]
L += [tab(r2.reset_index().rename(columns={"delta_pp": "Net gain (pp)"})), ""]
# S6
L += ["## Supplementary Table 6 | Association of top-1 success with the training count of the rarest edit", ""]
rows = []
for s in ["baseline_unknown", "baseline_known", "aug_unknown", "aug_known"]:
    for m in ["log10 min-frequency only", "+ edit count, LG flag, class"]:
        x = lr[(lr.setting == s) & (lr.model == m)].iloc[0]
        rows.append({"Model and setting": SETN[s], "Adjustment": "None" if m.startswith("log10") else "Edit count, leaving-group edit, class", "Odds ratio per 10-fold [95% interval]": f"{x.OR_per_10x:.2f} [{x.lo:.2f}, {x.hi:.2f}]"})
    x = lrs[(lrs.setting == s) & (lrs.term == "logf")].iloc[0]; y = lrs[(lrs.setting == s) & (lrs.term == "nn")].iloc[0]
    rows.append({"Model and setting": SETN[s], "Adjustment": "As above plus nearest-neighbour similarity", "Odds ratio per 10-fold [95% interval]": f"{x.OR:.2f} [{x.lo:.2f}, {x.hi:.2f}] (similarity per unit: {y.OR:.1f} [{y.lo:.1f}, {y.hi:.1f}])"})
L += [tab(pd.DataFrame(rows)), "", "Binomial generalised linear models with robust (HC1) standard errors; exploratory.", ""]
# S7
L += ["## Supplementary Table 7 | Top-1 accuracy of Graph2Edits in finer frequency bins", ""]
rows = []
for b in ["<5", "5-9", "10-19", "20-49", "50-100", "101-300", "301-1000", ">1000"]:
    r = {"Rarest edit, training count": b}
    for s in ["baseline_unknown", "baseline_known"]:
        x = fb[(fb.setting == s) & (fb.bin == b) & (fb.metric == "top1")].iloc[0]; r["n"] = int(x.n); r[SETN[s]] = f"{x.pct:.1f} ({int(x.k)}; {x.ci_lo:.1f}–{x.ci_hi:.1f})"
    rows.append(r)
L += [tab(pd.DataFrame(rows)), ""]
# S8
L += ["## Supplementary Table 8 | Gap between many-shot and few-shot accuracy", ""]
g = gap[gap.setting.isin(["baseline_unknown", "baseline_known"])].copy(); g["Model and setting"] = g.setting.map(SETN); g["Cut-off"] = g.metric.str.replace("top", "Top-")
g["Gap (pp) [Newcombe 95% interval]"] = g.apply(lambda r: f"{r.gap_pp:.1f} [{r.lo:.1f}, {r.hi:.1f}]", axis=1)
L += [tab(g[["Model and setting", "Cut-off", "Gap (pp) [Newcombe 95% interval]"]]), "", "Patent-level resampling of the top-1 gap (4,194 patents, 5,000 resamples): class unknown " + f"{cl.lo.iloc[0]:.1f}–{cl.hi.iloc[0]:.1f}" + " pp; class known " + f"{cl.lo.iloc[1]:.1f}–{cl.hi.iloc[1]:.1f}" + " pp.", ""]
L += ["## Supplementary Note 1 | Definitions", "", "**Group assignment.** The count of an edit label is its number of occurrences among the non-terminal edits of all 39,985 processed training reactions. A test reaction is assigned by the smallest count among its non-terminal edits. **Ceiling.** (n/N)(1 − p) percentage points for a group of n reactions with accuracy p among N = 5,004. **Unpaired MDD.** Smallest increase over a baseline proportion detectable with 80% power by an equal-size two-sided two-proportion test at α = 0.05 (search step 0.1 percentage points). **Paired MDD.** Smallest net gain δ detectable with 80% power by the exact two-sided McNemar test when a share d of reactions is solved by exactly one model; the number of discordant reactions is binomial(n, d) and the number favouring the second model is binomial(m, (1 + δ/d)/2).", ""]

import re
_txt = "\n".join(L) + "\n"
_txt = re.sub(r"\(similarity per unit: ([\d.]+) \[([\d.]+), ([\d.]+)\]\)", r"(similarity per unit: \1, interval \2–\3)", _txt)
_txt = re.sub(r"\[(-?[\d.]+), (-?[\d.]+)\]", r"(\1–\2)", _txt).replace("[95% interval]", "(95% interval)").replace("[Newcombe 95% interval]", "(Newcombe 95% interval)")
_txt = annotate(_txt)
open(OUT, 'w', encoding='utf8').write(_txt)
print("SI written", len(L))
