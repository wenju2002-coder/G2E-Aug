# Additional file 1

RetroTail: Edit-frequency stratified evaluation for single-step retrosynthesis prediction

Journal of Cheminformatics

Wenju Zhang^1,2^, Xiaorui Wang^3^, Pei Yang^1,2^, Yachao Cui^1,2,*^, Yuquan Li^4,5,6,†^

^1^ Qinghai University, School of Computer Technology and Applications, Xining 810016, China

^2^ Qinghai Provincial Laboratory for Intelligent Computing and Application, Xining 810016, China

^3^ College of Pharmaceutical Sciences, Zhejiang University, Hangzhou 310058, China

^4^ Guizhou Provincial Laboratory of Big Data, State Key Laboratory of Public Big Data, College of Computer Science and Technology, Guizhou University, Guiyang 550025, China

^5^ State Key Laboratory of Green Pesticide, Center for Research and Development of Fine Chemicals, Guizhou University, Guiyang 550025, China

^6^ Kway AI, China

^*^ Corresponding author: Yachao Cui; E-mail: yachaocui@qhu.edu.cn; ORCID: https://orcid.org/0000-0002-8650-9013

† Corresponding author: Yuquan Li; E-mail: yvquan.li@gzu.edu.cn; ORCID: https://orcid.org/0000-0003-2756-0449

RetroTail is an evaluation workflow. The empirical case study is restricted to the Graph2Edits family on one USPTO-50K split; cross-family and cross-split validity has not been established.

## Data provenance and interpretation

This PDF is a supplementary statistical report, not an independent dataset or a new model evaluation. Observed summaries use the archived processed USPTO-50K data and four model–setting prediction tables for the same 5,004 test reactions: Graph2Edits and Graph2Edits-Aug, each with reaction-class input withheld or supplied. The four ranked-record tables are Analysis/baseline_unknown_per_reaction.csv, Analysis/baseline_known_per_reaction.csv, Analysis/aug_unknown_per_reaction.csv and Analysis/aug_known_per_reaction.csv in Additional file 2 (Additional_file_2.zip).

Tables S1–S4 and S6–S8 summarize the archived records or features derived from the processed data. Table S5 contains power-planning calculations under specified sample-size, baseline-accuracy, effect-size and correctness-discordance assumptions. Its values are not observed model improvements, extra test sets or multi-seed experiments. Hypothetical planning is distinguished from measured performance throughout.

Unless stated otherwise, percentages are rounded to one decimal and counts are exact. Values are rounded directly from unrounded integer ratios, never from already-rounded displays. Thus 4,471/5,004 is 89.35% at two decimals in main-text Table 1 but 89.3% here; 3,360/5,004 is 67.15% at two decimals but 67.1% here. These are identical predictions. Wilson intervals are 95% confidence intervals. Planning baselines in S5a are specified rounded values (13.5%, 38.5% and 56.2%), whereas observed accuracies and conditional ceilings use exact counts.

Many, Medium and Few abbreviate many-shot, medium-shot and few-shot. Pooled combines all 5,004 reactions. Known/Unknown refer only to whether the reaction-class label is supplied to the predictor. Correctness discordance means that exactly one model is correct at a specified top-k cut-off; different predictions that are both incorrect are not discordant pairs. Frequency is defined from the recorded reference edits, not from chemical novelty.

Source notes below name files relative to evidence_analysis/source_data/analysis_tables/ inside Additional_file_2.zip. The evidence-only make_si_evidence_jci.py reads these CSVs and creates this Markdown; typeset_si_jci.py produces the PDF. Both are in evidence_analysis/scripts/. README_JCI.md provides commands. These scripts do not generate model predictions.