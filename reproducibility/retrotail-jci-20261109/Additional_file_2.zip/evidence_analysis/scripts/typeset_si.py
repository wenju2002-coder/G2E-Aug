"""Typeset the evidence-only supplementary Markdown. No model/data computation."""
from pathlib import Path
import argparse,html,re
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4,landscape
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

def inline(s):
    s=html.escape(s)
    s=re.sub(r'\*\*(.+?)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'\^([^\^]+)\^',r'<super>\1</super>',s)
    return s.replace('`','')

def render(src,out,font_dir=None):
    candidates=[Path(font_dir)]if font_dir else[Path('C:/Windows/Fonts'),Path('/usr/share/fonts/truetype/liberation2')]
    fonts=next((p for p in candidates if (p/'times.ttf').exists()or(p/'LiberationSerif-Regular.ttf').exists()),None)
    if fonts is None:raise RuntimeError('Provide --font-dir containing times.ttf/timesbd.ttf or LiberationSerif fonts')
    normal=fonts/('times.ttf'if(fonts/'times.ttf').exists()else'LiberationSerif-Regular.ttf')
    heavy=fonts/('timesbd.ttf'if(fonts/'timesbd.ttf').exists()else'LiberationSerif-Bold.ttf')
    pdfmetrics.registerFont(TTFont('RTSerif',str(normal)))
    pdfmetrics.registerFont(TTFont('RTSerifB',str(heavy)))
    # ReportLab's canvas initially registers Helvetica even when all body
    # text is serif. Embed that default resource too, rather than leaving
    # an unembedded standard-font entry in the delivered PDF.
    pdfmetrics.registerFont(TTFont('Helvetica',str(normal)))
    pdfmetrics.registerFontFamily('RTSerif',normal='RTSerif',bold='RTSerifB',italic='RTSerif',boldItalic='RTSerifB')
    styles=getSampleStyleSheet()
    for name in['Normal','BodyText','Title','Heading2']:
        styles[name].fontName='RTSerif';styles[name].textColor=colors.black
    styles['Normal'].fontSize=9.5;styles['Normal'].leading=11.5
    styles['Title'].fontSize=15;styles['Title'].leading=18
    styles['Heading2'].fontSize=12;styles['Heading2'].leading=14;styles['Heading2'].spaceBefore=9;styles['Heading2'].keepWithNext=True
    cell=ParagraphStyle('cell',fontName='RTSerif',fontSize=8.2,leading=10)
    head=ParagraphStyle('cellhead',parent=cell,fontName='RTSerifB')
    width=landscape(A4)[0]-72
    blocks=re.split(r'\n\s*\n',Path(src).read_text(encoding='utf8').strip())
    story=[]
    for block in blocks:
        if block.startswith('|'):
            rows=[[v.strip()for v in line.strip().strip('|').split('|')]for line in block.splitlines()if line.strip().startswith('|')]
            rows=[row for row in rows if not all(re.fullmatch('[: -]+',v)for v in row)]
            n=len(rows[0])
            if n==7:widths=[155,50,36]+[(width-241)/4]*4
            elif n==11:widths=[54,47,44,31]+[(width-176)/7]*7
            elif n==10:widths=[50,90,45,48,40,63,58,65,65,width-524]
            elif n==8:widths=[50,35,63,100,78,120,130,width-576]
            elif n==6:widths=[45,265]+[(width-310)/4]*4
            elif n==3:widths=[170,270,width-440]
            else:widths=[width/n]*n
            cells=[[Paragraph(inline(v),head if i==0 else cell)for v in row]for i,row in enumerate(rows)]
            t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
            t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EEEEEE')),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#CCCCCC')),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),2.1),('BOTTOMPADDING',(0,0),(-1,-1),2.1)]))
            story.extend([t,Spacer(1,6)])
        elif block.startswith('#'):
            level=len(block)-len(block.lstrip('#'));story.append(Paragraph(inline(block.lstrip('#').strip()),styles['Title'if level==1 else'Heading2']))
        else:
            p=Paragraph(inline(block.replace('\n',' ')),styles['Normal'])
            if block.startswith(('**a.','**b.','**c.','Source:')):p.keepWithNext=True
            story.extend([p,Spacer(1,6)])
    # Keep each heading and its source note with the first table when it fits;
    # long tables may still split cleanly with a repeated header.
    grouped=[];i=0
    while i<len(story):
        item=story[i]
        anchor=isinstance(item,Paragraph)and(item.style.name=='Heading2'or item.getPlainText().startswith(('a. ','b. ','c. ')))
        if anchor:
            j=i+1;chunk=[item]
            while j<len(story):
                other=story[j]
                if isinstance(other,Paragraph)and other.style.name=='Heading2':break
                chunk.append(other);j+=1
                if isinstance(other,Table):break
            if isinstance(chunk[-1],Table):grouped.append(KeepTogether(chunk));i=j;continue
        grouped.append(item);i+=1
    def footer(c,d):
        c.setFont('RTSerif',9);c.drawRightString(landscape(A4)[0]-36,20,'Online Resource 1 | '+str(d.page))
    pdf=SimpleDocTemplate(str(out),pagesize=landscape(A4),leftMargin=36,rightMargin=36,topMargin=30,bottomMargin=34,
        title='RetroTail supplementary information',author='Wenju Zhang; Xiaorui Wang; Pei Yang; Yachao Cui; Yuquan Li')
    pdf.build(grouped,onFirstPage=footer,onLaterPages=footer)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('markdown');p.add_argument('pdf');p.add_argument('--font-dir');a=p.parse_args()
    render(a.markdown,a.pdf,a.font_dir)
