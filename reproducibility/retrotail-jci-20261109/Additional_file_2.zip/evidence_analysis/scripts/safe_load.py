"""Restricted loader for zlib-compressed pickles: unknown classes become inert stubs, so no archive code runs."""
import io, pickle, zlib

_ALLOWED = {("collections", "Counter"), ("collections", "OrderedDict"), ("collections", "defaultdict"),
            ("builtins", "set"), ("builtins", "frozenset"), ("builtins", "dict"), ("builtins", "list"),
            ("builtins", "tuple"), ("builtins", "object"), ("copyreg", "_reconstructor")}


class Stub(tuple):
    def __new__(cls, *a):
        return tuple.__new__(cls, a)

    def __setstate__(self, st):
        if isinstance(st, dict):
            self.__dict__.update(st)
        elif isinstance(st, tuple) and len(st) == 2 and isinstance(st[1], dict):
            self.__dict__.update(st[1])
        else:
            self._state = st


class _U(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) in _ALLOWED:
            return super().find_class(module, name)
        return type(name, (Stub,), {"_orig": f"{module}.{name}"})


def load(path):
    raw = open(path, "rb").read()
    try:
        raw = zlib.decompress(raw)
    except zlib.error:
        pass
    return _U(io.BytesIO(raw)).load()
