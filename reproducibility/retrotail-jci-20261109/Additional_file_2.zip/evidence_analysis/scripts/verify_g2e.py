"""Independent re-derivation of every number used in the manuscript from the archived per-reaction records.

Reads only: processed train/test pickles (restricted loader), action_freq_map.pkl, and the four per-reaction CSVs.
No model is loaded and no inference is run.   python3 -I scripts/verify_g2e.py <supp_root> <out_dir>
"""
import json, os, sys, hashlib
import numpy as np, pandas as pd
from collections import Counter
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import safe_load as sl

ROOT, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
D = os.path.join(ROOT, "Graph2Edits-Aug/data/uspto_50k")
AN = os.path.join(ROOT, "Analysis")
SETS = ["baseline_unknown", "baseline_known", "aug_unknown", "aug_known"]
KS = ["top1", "top3", "top5", "top10"]
Z = 1.959963984540054


def wilson(k, n, z=Z):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h


def newcombe_diff(k1, n1, k2, n2):
    """Newcombe hybrid-score 95% CI for p1-p2 (independent proportions)."""
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1); l2, u2 = wilson(k2, n2)
    d = p1 - p2
    return d, d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


def mdd(p1, n, za=1.95996, zb=0.84162):
    for step in range(1, 1000):
        p2 = p1 + step / 1000
        if p2 > 1:
            return np.nan
        pb = (p1 + p2) / 2
        need = za * np.sqrt(2 * pb * (1 - pb) / n) + zb * np.sqrt((p1 * (1 - p1) + p2 * (1 - p2)) / n)
        if p2 - p1 >= need:
            return step / 10.0
    return np.nan


def mcnemar_exact(b, c):
    m = b + c
    if m == 0:
        return 1.0
    return min(1.0, 2 * stats.binom.cdf(min(b, c), m, 0.5))


res = {}
# ---- 1. frequency map and buckets, re-derived from the processed training / test files
tr = sl.load(os.path.join(D, "train/train.file.kekulized"))
te = sl.load(os.path.join(D, "test/test.file.kekulized"))
fm_file = sl.load(os.path.join(D, "train/action_freq_map.pkl"))
cnt = Counter()
for r in tr:
    for e in r[1]:
        if e != "Terminate":
            cnt[e] += 1
res["train_reactions"] = len(tr); res["test_reactions"] = len(te)
res["freq_actions_rederived"] = len(cnt); res["freq_actions_file"] = len(fm_file)
res["freq_map_identical"] = dict(cnt) == dict(fm_file)


def bucket_of(minf, lo=20, hi=100):
    return "Many" if minf > hi else ("Medium" if minf >= lo else "Few")


rows = []
for i, r in enumerate(te):
    eds = [e for e in r[1] if e != "Terminate"]
    mf = min(cnt.get(e, 0) for e in eds)
    rows.append(dict(reaction_index=i, min_freq=mf, n_edits=len(eds), has_lg=any(e[0] == "Attaching LG" for e in eds),
                     unseen=any(cnt.get(e, 0) == 0 for e in eds), rxn_class_idx=r[3], rxn_id=r[4], rxn_smi=r[0]))
T = pd.DataFrame(rows)
T["bucket"] = [bucket_of(x) for x in T.min_freq]
res["bucket_counts_rederived"] = T.bucket.value_counts().to_dict()

P = {}
for s in SETS:
    df = pd.read_csv(os.path.join(AN, f"{s}_per_reaction.csv"))
    assert len(df) == 5004
    assert (df.reaction_index.values == T.reaction_index.values).all()
    assert (df.reaction_id.values == T.rxn_id.values).all(), s
    P[s] = df
    res[f"{s}_bucket_matches_rederived"] = bool((df.bucket.values == T.bucket.values).all())
    res[f"{s}_minfreq_matches_rederived"] = bool((df.min_edit_frequency.values == T.min_freq.values).all())
    # flag consistency: first_match_rank vs top-k flags
    fr = df.first_match_rank.fillna(0).astype(int)
    ok = True
    for k, kk in zip([1, 3, 5, 10], KS):
        exp = ((fr >= 1) & (fr <= k)).astype(int)
        ok &= bool((exp.values == df[kk].values).all())
    res[f"{s}_flags_consistent_with_rank"] = ok

# ---- 2. bucket-level accuracies from integer counts
rows = []
for s in SETS:
    df = P[s]
    for b in ["Many", "Medium", "Few", "All"]:
        sub = df if b == "All" else df[df.bucket == b]
        n = len(sub)
        for kk in KS:
            k = int(sub[kk].sum()); lo, hi = wilson(k, n)
            rows.append(dict(setting=s, bucket=b, metric=kk, n=n, k=k, pct=100 * k / n, ci_lo=100 * lo, ci_hi=100 * hi))
ACC = pd.DataFrame(rows); ACC.to_csv(os.path.join(OUT, "acc_by_bucket.csv"), index=False)

# ---- 3. ceilings, MDD, gap with CI
rows = []
N = 5004
for s in SETS:
    for kk in KS:
        a = ACC[(ACC.setting == s) & (ACC.metric == kk)].set_index("bucket")
        for b in ["Many", "Medium", "Few"]:
            n = int(a.loc[b, "n"]); k = int(a.loc[b, "k"])
            rows.append(dict(setting=s, metric=kk, bucket=b, n=n, k=k, pct=100 * k / n,
                             ceiling_pp=100 * (n - k) / N, mdd_pp=mdd(k / n, n)))
        # joint ceiling
        jn = int(a.loc["Medium", "n"] + a.loc["Few", "n"]); jk = int(a.loc["Medium", "k"] + a.loc["Few", "k"])
        rows.append(dict(setting=s, metric=kk, bucket="Medium+Few", n=jn, k=jk, pct=100 * jk / jn,
                         ceiling_pp=100 * (jn - jk) / N, mdd_pp=np.nan))
CEIL = pd.DataFrame(rows); CEIL.to_csv(os.path.join(OUT, "ceiling_mdd.csv"), index=False)

rows = []
for s in SETS:
    for kk in KS:
        a = ACC[(ACC.setting == s) & (ACC.metric == kk)].set_index("bucket")
        d, lo, hi = newcombe_diff(int(a.loc["Many", "k"]), int(a.loc["Many", "n"]), int(a.loc["Few", "k"]), int(a.loc["Few", "n"]))
        rows.append(dict(setting=s, metric=kk, gap_pp=100 * d, lo=100 * lo, hi=100 * hi))
GAP = pd.DataFrame(rows); GAP.to_csv(os.path.join(OUT, "gap_newcombe.csv"), index=False)

# ---- 4. paired exact tests with Holm over 32
rows = []
for sett in ["unknown", "known"]:
    B, A = P[f"baseline_{sett}"], P[f"aug_{sett}"]
    for b in ["Many", "Medium", "Few", "All"]:
        m = np.ones(len(B), bool) if b == "All" else (B.bucket.values == b)
        for kk in KS:
            x, y = B[kk].values[m], A[kk].values[m]
            bo = int(((x == 1) & (y == 0)).sum()); ao = int(((x == 0) & (y == 1)).sum())
            rows.append(dict(setting=sett, bucket=b, metric=kk, n=int(m.sum()), base_k=int(x.sum()), aug_k=int(y.sum()),
                             base_only=bo, aug_only=ao, diff_pp=100 * (y.sum() - x.sum()) / m.sum(), p_exact=mcnemar_exact(bo, ao)))
PT = pd.DataFrame(rows)
order = np.argsort(PT.p_exact.values); m = len(PT); adj = np.empty(m); run = 0
for rank, idx in enumerate(order):
    run = max(run, (m - rank) * PT.p_exact.values[idx]); adj[idx] = min(1.0, run)
PT["p_holm"] = adj; PT.to_csv(os.path.join(OUT, "paired_tests.csv"), index=False)

# ---- 5. threshold sensitivity and unseen-edit exclusion
rows = []
for lo_, hi_ in [(10, 50), (20, 100), (50, 200)]:
    bk = np.array([bucket_of(x, lo_, hi_) for x in T.min_freq])
    for sett in ["unknown", "known"]:
        df = P[f"baseline_{sett}"]
        for b in ["Many", "Medium", "Few"]:
            m_ = bk == b
            rows.append(dict(lo=lo_, hi=hi_, setting=sett, bucket=b, n=int(m_.sum()), k1=int(df.top1.values[m_].sum()),
                             pct1=100 * df.top1.values[m_].mean(), k10=int(df.top10.values[m_].sum()), pct10=100 * df.top10.values[m_].mean()))
THR = pd.DataFrame(rows); THR.to_csv(os.path.join(OUT, "threshold_sensitivity_rederived.csv"), index=False)
res["unseen_few"] = int(T[(T.bucket == "Few")].unseen.sum())

# ---- 6. finer frequency bins (exploratory)
edges = [0, 5, 10, 20, 50, 100, 300, 1000, 10 ** 7]
labs = ["<5", "5-9", "10-19", "20-49", "50-100", "101-300", "301-1000", ">1000"]
labs_ = labs[:]
T["fbin"] = pd.cut(T.min_freq, bins=[-1, 4, 9, 19, 49, 100, 300, 1000, 10 ** 7], labels=labs)
rows = []
for s in SETS:
    df = P[s]
    for lab in labs:
        m_ = (T.fbin == lab).values
        n = int(m_.sum())
        if n == 0:
            continue
        for kk in ["top1", "top10"]:
            k = int(df[kk].values[m_].sum()); lo, hi = wilson(k, n)
            rows.append(dict(setting=s, bin=lab, metric=kk, n=n, k=k, pct=100 * k / n, ci_lo=100 * lo, ci_hi=100 * hi))
FB = pd.DataFrame(rows); FB.to_csv(os.path.join(OUT, "fine_bins.csv"), index=False)

# ---- 7. adjusted association (exploratory logistic regression)
import statsmodels.api as sm
rows = []
X = pd.DataFrame(dict(logf=np.log10(T.min_freq + 1), n_edits=T.n_edits, lg=T.has_lg.astype(int)))
cls = pd.get_dummies(T.rxn_class_idx, prefix="c", drop_first=True).astype(float)
X2 = pd.concat([X, cls], axis=1); X2 = sm.add_constant(X2)
for s in SETS:
    y = P[s].top1.values
    for name, XX in [("log10 min-frequency only", sm.add_constant(X[["logf"]])), ("+ edit count, LG flag, class", X2)]:
        fit = sm.GLM(y, XX, family=sm.families.Binomial()).fit(cov_type="HC1", maxiter=200)
        b = fit.params["logf"]; ci = fit.conf_int().loc["logf"].values
        rows.append(dict(setting=s, model=name, OR_per_10x=float(np.exp(b)), lo=float(np.exp(ci[0])), hi=float(np.exp(ci[1])), p=float(fit.pvalues["logf"])))
LR = pd.DataFrame(rows); LR.to_csv(os.path.join(OUT, "logit_exploratory.csv"), index=False)

# ---- 8. paired planning power (exact McNemar), n x discordance rate
_TT = {}


def _thr(mmax):
    """largest t such that the two-sided exact sign test at m discordant pairs rejects when min(b,c)<=t (else -1)."""
    out = np.full(mmax + 1, -1)
    for m_ in range(1, mmax + 1):
        t = -1
        for cand in range(0, m_ // 2 + 1):
            if 2 * stats.binom.cdf(cand, m_, 0.5) <= 0.05:
                t = cand
            else:
                break
        out[m_] = t
    return out


THR_ARR = _thr(3000)


def paired_power(n, d, delta):
    q = 0.5 * (1 + delta / d)
    if q > 1:
        return np.nan
    ms = np.arange(1, n + 1)
    pm = stats.binom.pmf(ms, n, d)
    tt = THR_ARR[ms]
    ok = (tt >= 0) & (pm > 1e-14)
    ms, pm, tt = ms[ok], pm[ok], tt[ok]
    return float(np.sum(pm * (stats.binom.cdf(tt, ms, q) + stats.binom.sf(ms - tt - 1, ms, q))))


def paired_mdd(n, d, target=0.8):
    lo, hi = 0.0, d
    if paired_power(n, d, hi) < target:
        return np.nan
    for _ in range(14):
        mid = (lo + hi) / 2
        if paired_power(n, d, mid) >= target:
            hi = mid
        else:
            lo = mid
    return round(hi * 100, 1)


rows = []
for n in [52, 120, 250, 500, 1000, 2000]:
    for d in [0.05, 0.10, 0.15, 0.20, 0.30]:
        rows.append(dict(n=n, discordance=d, paired_mdd_pp=paired_mdd(n, d)))
PP = pd.DataFrame(rows); PP.to_csv(os.path.join(OUT, "paired_planning.csv"), index=False)
# observed discordance rates
rows = []
for r in PT.itertuples():
    rows.append(dict(setting=r.setting, bucket=r.bucket, metric=r.metric, n=r.n, discordance=(r.base_only + r.aug_only) / r.n))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "observed_discordance.csv"), index=False)

# ---- 9. product similarity of test products to the training set (exploratory)
from rdkit import Chem, DataStructs, RDLogger
from rdkit.Chem import rdFingerprintGenerator
RDLogger.DisableLog("rdApp.*")
gen = rdFingerprintGenerator.GetMorganGenerator(radius=2, fpSize=2048)

def prod_fp(rxn_smi):
    p = rxn_smi.split(">>")[1]
    m = Chem.MolFromSmiles(p)
    for a in m.GetAtoms():
        a.SetAtomMapNum(0)
    return gen.GetFingerprint(m), Chem.MolToSmiles(m)

trfp, trsmi = zip(*[prod_fp(r[0]) for r in tr])
trset = set(trsmi)
nn = []; dup = []
for i, r in enumerate(te):
    fp, smi = prod_fp(r[0])
    sims = DataStructs.BulkTanimotoSimilarity(fp, list(trfp))
    nn.append(max(sims)); dup.append(smi in trset)
T["nn_tanimoto"] = nn; T["product_in_train"] = dup
SIM = []
for b in ["Many", "Medium", "Few"]:
    m_ = (T.bucket == b).values
    SIM.append(dict(bucket=b, n=int(m_.sum()), median_nn=float(np.median(T.nn_tanimoto[m_])), q25=float(np.percentile(T.nn_tanimoto[m_], 25)),
                    q75=float(np.percentile(T.nn_tanimoto[m_], 75)), product_in_train=int(T.product_in_train[m_].sum())))
pd.DataFrame(SIM).to_csv(os.path.join(OUT, "similarity_by_bucket.csv"), index=False)
res["product_in_train_total"] = int(T.product_in_train.sum())
# nn-similarity as extra covariate
X3 = X2.copy(); X3["nn"] = T.nn_tanimoto.values
rows = []
for s in SETS:
    y = P[s].top1.values
    fit = sm.GLM(y, X3, family=sm.families.Binomial()).fit(cov_type="HC1", maxiter=200)
    for v in ["logf", "nn"]:
        ci = fit.conf_int().loc[v].values
        rows.append(dict(setting=s, term=v, OR=float(np.exp(fit.params[v])), lo=float(np.exp(ci[0])), hi=float(np.exp(ci[1])), p=float(fit.pvalues[v])))
pd.DataFrame(rows).to_csv(os.path.join(OUT, "logit_with_similarity.csv"), index=False)
T.drop(columns=["rxn_smi"]).to_csv(os.path.join(OUT, "test_reaction_features.csv"), index=False)

# ---- 10. compare with archived analysis tables
a_pt = pd.read_csv(os.path.join(AN, "paired_tests.csv"))
mm = PT.merge(a_pt, left_on=["setting", "bucket", "metric"], right_on=["setting", "bucket", "metric"], suffixes=("", "_arch"))
res["paired_rows_compared"] = int(len(mm))
res["paired_max_abs_p_diff"] = float(np.abs(mm.p_exact - mm.p_exact_arch).max())
res["paired_max_abs_holm_diff"] = float(np.abs(mm.p_holm - mm.p_holm_32).max())
a_pc = pd.read_csv(os.path.join(AN, "power_and_ceiling.csv"))
c2 = CEIL[CEIL.setting.isin(["baseline_unknown", "baseline_known"])].copy()
c2["setting"] = c2.setting.str.replace("baseline_", "")
mm2 = c2.merge(a_pc, on=["setting", "bucket", "metric"], suffixes=("", "_arch"))
res["ceiling_rows_compared"] = int(len(mm2))
res["ceiling_max_abs_diff"] = float(np.abs(mm2.ceiling_pp - mm2.aggregate_ceiling_pp).max())
res["mdd_max_abs_diff"] = float(np.abs(mm2.mdd_pp - mm2.mdd_unpaired_80_percent_power_pp).max())
json.dump(res, open(os.path.join(OUT, "verify_summary.json"), "w"), indent=1, default=str)
print(json.dumps(res, indent=1, default=str))
