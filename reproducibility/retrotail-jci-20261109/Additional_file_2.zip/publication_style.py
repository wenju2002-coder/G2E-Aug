#!/usr/bin/env python3
"""Build CILS/Elsevier-ready figure files without changing the source figures.

The output uses a 190 mm full-page-width canvas, Arial lettering, vector PDF
for plots, and LZW-compressed RGB TIFF fallback files at 500 dpi.  Figure 1
is retained as a 600 dpi TIFF because its only available publication-quality
source is raster artwork.
"""

from __future__ import annotations

import importlib.util
import re
import shutil
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
SOURCE_FIGURES = ROOT / "outputs" / "CILS" / "Figures"
OUTPUT = ROOT / "outputs" / "CILS" / "Figures_SubmissionReady"
QA = ROOT / "outputs" / "CILS" / "_qa_figures_submission"
PLOT_SOURCE = ROOT / "plot_manuscript_figures.py"

WIDTH_MM = 190.0
WIDTH_IN = WIDTH_MM / 25.4
TIFF_DPI = 500
FRAMEWORK_DPI = 600


def load_plot_module():
    spec = importlib.util.spec_from_file_location("g2e_manuscript_figures", PLOT_SOURCE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {PLOT_SOURCE}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def configure_submission_style(plot) -> None:
    for font_path in (
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\arialbd.ttf",
        r"C:\Windows\Fonts\ariali.ttf",
        r"C:\Windows\Fonts\arialbi.ttf",
    ):
        font_manager.fontManager.addfont(font_path)

    plot.configure_style()
    mpl.rcParams.update(
        {
            "font.family": "Arial",
            "font.sans-serif": ["Arial"],
            "font.size": 8.0,
            "axes.titlesize": 9.5,
            "axes.labelsize": 8.5,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "legend.fontsize": 7.5,
            "figure.titlesize": 11.0,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "mathtext.fontset": "custom",
            "mathtext.rm": "Arial",
            "mathtext.it": "Arial:italic",
            "mathtext.bf": "Arial:bold",
            "mathtext.cal": "Arial",
            "savefig.facecolor": "white",
            "savefig.edgecolor": "white",
            "savefig.transparent": False,
        }
    )

    def compact_panel_label(ax, label: str) -> None:
        ax.text(
            -0.10,
            1.04,
            label,
            transform=ax.transAxes,
            fontsize=11,
            fontweight="bold",
            va="bottom",
            ha="left",
        )

    plot.panel_label = compact_panel_label


def resize_to_full_width(fig: plt.Figure, height_mm: float = 110.0) -> None:
    fig.set_size_inches(WIDTH_IN, height_mm / 25.4, forward=True)


def refine_layout(fig: plt.Figure, stem: str) -> None:
    """Reserve print-size space for legends, long labels, and the colorbar."""
    if stem == "Fig2_accuracy_by_edit_frequency":
        legend = fig.legends[0]
        legend.set_loc("lower center")
        legend.set_bbox_to_anchor((0.5, 0.015))
        fig.subplots_adjust(left=0.075, right=0.99, bottom=0.20, top=0.92, wspace=0.15)
    elif stem == "Fig4_few_shot_mdd_comparison":
        fig.subplots_adjust(left=0.085, right=0.99, bottom=0.24, top=0.92)
    elif stem == "Fig5_class_bucket_composition":
        grid = fig.axes[0].get_subplotspec().get_gridspec()
        grid.update(left=0.14, right=0.90, bottom=0.20, top=0.90, wspace=0.36)
        legend = fig.axes[0].get_legend()
        if legend is not None:
            legend.set_bbox_to_anchor((0.47, -0.12))


def save_plot(fig: plt.Figure, stem: str) -> None:
    pdf_path = OUTPUT / f"{stem}.pdf"
    tif_path = OUTPUT / f"{stem}.tif"
    preview_path = QA / f"{stem}.png"

    fig.savefig(
        pdf_path,
        format="pdf",
        metadata={"Title": stem, "Creator": "Matplotlib; prepared for Elsevier/CILS"},
    )
    fig.savefig(
        tif_path,
        format="tiff",
        dpi=TIFF_DPI,
        pil_kwargs={"compression": "tiff_lzw"},
    )
    with Image.open(tif_path) as rendered:
        if rendered.mode == "RGBA":
            white = Image.new("RGB", rendered.size, "white")
            white.paste(rendered, mask=rendered.getchannel("A"))
            rendered_rgb = white
        else:
            rendered_rgb = rendered.convert("RGB")
        rendered_rgb.save(
            tif_path,
            format="TIFF",
            compression="tiff_lzw",
            dpi=(TIFF_DPI, TIFF_DPI),
        )
    fig.savefig(preview_path, format="png", dpi=150)
    plt.close(fig)


def nonwhite_bbox(image: Image.Image, threshold: int = 250):
    rgb = image.convert("RGB")
    background = Image.new("RGB", rgb.size, (255, 255, 255))
    difference = ImageChops.difference(rgb, background).convert("L")
    mask = difference.point(lambda value: 255 if value > 255 - threshold else 0)
    return mask.getbbox()


def prepare_framework() -> None:
    source = SOURCE_FIGURES / "Fig1_Graph2Edits_Aug_framework.tif"
    target = OUTPUT / "Fig1_Graph2Edits_Aug_framework.tif"
    preview = QA / "Fig1_Graph2Edits_Aug_framework.png"

    Image.MAX_IMAGE_PIXELS = None
    with Image.open(source) as original:
        image = original.convert("RGB")
        bbox = nonwhite_bbox(image)
        if bbox:
            pad = 24  # approximately 1 mm at 600 dpi
            left = max(0, bbox[0] - pad)
            top = max(0, bbox[1] - pad)
            right = min(image.width, bbox[2] + pad)
            bottom = min(image.height, bbox[3] + pad)
            image = image.crop((left, top, right, bottom))
        target_width = round(WIDTH_IN * FRAMEWORK_DPI)
        if image.width != target_width:
            target_height = round(image.height * target_width / image.width)
            image = image.resize((target_width, target_height), Image.Resampling.LANCZOS)
        image.save(target, format="TIFF", compression="tiff_lzw", dpi=(FRAMEWORK_DPI, FRAMEWORK_DPI))
        image.thumbnail((1600, 1800), Image.Resampling.LANCZOS)
        image.save(preview, format="PNG", dpi=(150, 150))


def pdf_font_report(pdf_path: Path) -> str:
    """Return the font names reported by pdffonts when the utility is available."""
    import subprocess

    try:
        completed = subprocess.run(
            ["pdffonts", str(pdf_path)],
            check=True,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return "not checked"
    fonts = []
    for line in completed.stdout.splitlines()[2:]:
        fields = line.split()
        if fields:
            name = re.sub(r"^[A-Z]{6}\+", "", fields[0])
            if name not in fonts:
                fonts.append(name)
    return ", ".join(fonts) if fonts else "none reported"


def image_summary(path: Path) -> str:
    with Image.open(path) as image:
        dpi = image.info.get("dpi", (0, 0))
        dpi_x = float(dpi[0]) if dpi and dpi[0] else 0.0
        dpi_y = float(dpi[1]) if dpi and dpi[1] else 0.0
        width_mm = image.width / dpi_x * 25.4 if dpi_x else 0
        height_mm = image.height / dpi_y * 25.4 if dpi_y else 0
        return (
            f"{image.width} x {image.height} px; {dpi_x:.0f} dpi; "
            f"{width_mm:.1f} x {height_mm:.1f} mm; {image.mode}; LZW TIFF"
        )


def write_report(plot_stems: list[str]) -> None:
    lines = [
        "# CILS / Elsevier figure package",
        "",
        "These files were prepared as separate submission figures. The original files in `Figures` were not changed.",
        "",
        "## Recommended uploads",
        "",
        "- Figure 1: upload `Fig1_Graph2Edits_Aug_framework.tif` (600 dpi TIFF).",
        "- Figures 2-5: upload the PDF files (vector artwork with embedded Arial fonts).",
        "- TIFF files for Figures 2-5 are 500 dpi RGB fallbacks at a 190 mm full-width canvas.",
        "- Captions remain in the manuscript; they are intentionally not repeated inside the artwork.",
        "",
        "## File checks",
        "",
        f"- Fig. 1 TIFF: {image_summary(OUTPUT / 'Fig1_Graph2Edits_Aug_framework.tif')}",
    ]
    for stem in plot_stems:
        lines.append(f"- {stem} TIFF: {image_summary(OUTPUT / (stem + '.tif'))}")
        lines.append(f"- {stem} PDF fonts: {pdf_font_report(OUTPUT / (stem + '.pdf'))}")
    lines.extend(
        [
            "",
            "## Applied checks",
            "",
            "- Accepted Elsevier formats: TIFF and PDF.",
            "- RGB color space for color artwork.",
            "- Arial lettering; normal plotted text is 7 pt or larger at final size.",
            "- Plot line widths stay within Elsevier's 0.1-1.5 pt range.",
            "- Sequential filenames, separate figure files, tight content margins, and no figure-level caption text inside the artwork.",
        ]
    )
    (OUTPUT / "README_Figure_Compliance.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    if OUTPUT.exists() or QA.exists():
        raise FileExistsError("Submission-ready output already exists; refusing to overwrite it.")
    OUTPUT.mkdir(parents=True)
    QA.mkdir(parents=True)

    plot = load_plot_module()
    configure_submission_style(plot)
    prepare_framework()

    builders = [
        ("Fig2_accuracy_by_edit_frequency", plot.figure_1),
        ("Fig3_aggregate_tail_ceiling", plot.figure_2),
        ("Fig4_few_shot_mdd_comparison", plot.figure_3),
        ("Fig5_class_bucket_composition", plot.figure_4),
    ]
    for stem, builder in builders:
        figure = builder(include_figure_title=False)
        resize_to_full_width(figure, 112.0 if stem == "Fig5_class_bucket_composition" else 110.0)
        refine_layout(figure, stem)
        save_plot(figure, stem)

    write_report([stem for stem, _ in builders])
    shutil.make_archive(str(OUTPUT), "zip", OUTPUT.parent, OUTPUT.name)
    print(OUTPUT)
    print(OUTPUT.with_suffix(".zip"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
