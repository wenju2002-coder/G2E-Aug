#!/usr/bin/env python3
"""Generate the four frequency-stratified Graph2Edits manuscript figures.

The numerical values are transcribed from:
  * 张文举_长尾分层评测_manuscript_EN 1.md
  * Graph2Edits模型性能对比.xlsx

Usage:
    python -m pip install -r requirements-figures.txt
    python plot_manuscript_figures.py

By default the script writes PNG (300 dpi), PDF, and editable-text SVG files to
``figures/code_generated``. Use ``--formats png,svg`` or ``--output-dir PATH``
to change that behavior.
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle


# Color-blind-safe, print-friendly palette shared across figures.
NAVY = "#123B7A"
TEAL = "#168A8A"
AMBER = "#E9A400"
CORAL = "#EE624A"
SLATE = "#666A70"
BLUE = "#2F73C5"
GRID = "#D7DCE2"
LIGHT_BLUE = "#DDEBFA"
MISSING = "#ECEDEF"

TOPK = ("Top-1", "Top-3", "Top-5", "Top-10")
TOPK_COLORS = (NAVY, TEAL, AMBER, CORAL)
BUCKETS = ("Many-shot", "Medium-shot", "Few-shot")
BUCKET_N = np.array([4832, 120, 52], dtype=int)


# Reproduced Graph2Edits baseline from Table 1 (%), bucket rows x top-k columns.
BASELINE_PCT = {
    "Reaction class unknown": np.array(
        [
            [56.2, 78.3, 84.6, 90.4],
            [29.2, 47.5, 53.3, 67.5],
            [13.5, 30.8, 36.5, 38.5],
        ]
    ),
    "Reaction class known": np.array(
        [
            [68.1, 88.2, 92.5, 94.5],
            [48.3, 65.0, 73.3, 81.7],
            [23.1, 40.4, 51.9, 57.7],
        ]
    ),
}

AGGREGATE_TOP1 = {
    "Reaction class unknown": 55.11,
    "Reaction class known": 67.16,
}


def configure_style() -> None:
    """Apply a restrained journal-style Matplotlib theme."""
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9.5,
            "axes.titlesize": 12,
            "axes.titleweight": "bold",
            "axes.labelsize": 10.5,
            "axes.linewidth": 0.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "legend.fontsize": 9,
            "figure.titlesize": 17,
            "figure.titleweight": "bold",
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Return a Wilson score interval as percentages."""
    if n <= 0:
        return math.nan, math.nan
    p = successes / n
    denominator = 1.0 + z * z / n
    center = (p + z * z / (2.0 * n)) / denominator
    half_width = z * math.sqrt(p * (1.0 - p) / n + z * z / (4.0 * n * n)) / denominator
    return 100.0 * (center - half_width), 100.0 * (center + half_width)


def errors_from_percentages(values: np.ndarray, sample_sizes: np.ndarray) -> np.ndarray:
    """Convert point estimates to asymmetric Wilson errors for Matplotlib."""
    lower = np.zeros_like(values, dtype=float)
    upper = np.zeros_like(values, dtype=float)
    for row, n in enumerate(sample_sizes):
        for col, estimate in enumerate(values[row]):
            successes = int(round(estimate * n / 100.0))
            lo, hi = wilson_interval(successes, int(n))
            lower[row, col] = max(0.0, estimate - lo)
            upper[row, col] = max(0.0, hi - estimate)
    return np.stack([lower, upper])


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.10,
        1.04,
        label,
        transform=ax.transAxes,
        fontsize=15,
        fontweight="bold",
        va="bottom",
        ha="left",
    )


def save_figure(
    fig: plt.Figure,
    output_dir: Path,
    stem: str,
    formats: Iterable[str],
    dpi: int,
) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for extension in formats:
        path = output_dir / f"{stem}.{extension}"
        kwargs = {"bbox_inches": "tight", "pad_inches": 0.08}
        if extension == "png":
            kwargs["dpi"] = dpi
        fig.savefig(path, **kwargs)
        paths.append(path)
    plt.close(fig)
    return paths


def figure_1(include_figure_title: bool = True) -> plt.Figure:
    """Frequency-stratified Top-k accuracy with Wilson intervals."""
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 7.2), sharey=True)
    group_x = np.arange(len(BUCKETS), dtype=float)
    bar_width = 0.19
    offsets = (np.arange(len(TOPK)) - 1.5) * bar_width

    for panel, (setting, values) in enumerate(BASELINE_PCT.items()):
        ax = axes[panel]
        errors = errors_from_percentages(values, BUCKET_N)

        for metric, (label, color, offset) in enumerate(zip(TOPK, TOPK_COLORS, offsets)):
            x = group_x + offset
            heights = values[:, metric]
            yerr = np.vstack([errors[0, :, metric], errors[1, :, metric]])
            bars = ax.bar(
                x,
                heights,
                width=bar_width * 0.88,
                color=color,
                edgecolor="white",
                linewidth=0.6,
                yerr=yerr,
                capsize=2.5,
                error_kw={"elinewidth": 0.8, "capthick": 0.8, "ecolor": "#222222"},
                label=label,
                zorder=3,
            )
            for bar, value in zip(bars, heights):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 2.0,
                    f"{value:.1f}",
                    ha="center",
                    va="bottom",
                    fontsize=8.1,
                    color="#202124",
                )

        aggregate = AGGREGATE_TOP1[setting]
        ax.axhline(aggregate, color=NAVY, linestyle=(0, (4, 3)), linewidth=1.25, zorder=2)
        ax.text(
            0.99,
            aggregate + 1.2,
            f"Aggregate Top-1: {aggregate:.2f}%",
            transform=ax.get_yaxis_transform(),
            ha="right",
            va="bottom",
            fontsize=8.4,
            color=NAVY,
            fontweight="bold",
        )

        ax.set_title(setting, loc="left", pad=18)
        panel_label(ax, "a" if panel == 0 else "b")
        ax.set_xticks(group_x)
        ax.set_xticklabels(
            [
                "Many-shot\n($n$=4,832)",
                "Medium-shot\n($n$=120)",
                "Few-shot\n($n$=52)",
            ]
        )
        ax.set_ylim(0, 106)
        ax.set_yticks(np.arange(0, 101, 20))
        ax.grid(axis="y", color=GRID, linewidth=0.7, linestyle=(0, (3, 3)), zorder=0)
        ax.tick_params(axis="x", length=0)

    axes[0].set_ylabel("Exact-match accuracy (%)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.895))
    if include_figure_title:
        fig.suptitle("Accuracy falls as the rarest required edit becomes rarer", y=0.975)
    fig.subplots_adjust(
        left=0.075,
        right=0.99,
        bottom=0.12,
        top=0.80 if include_figure_title else 0.90,
        wspace=0.13,
    )
    return fig


def _draw_axis_break(ax_top: plt.Axes, ax_bottom: plt.Axes) -> None:
    """Draw diagonal marks between two vertically broken axes."""
    mark = 0.012
    kwargs_top = dict(transform=ax_top.transAxes, color="#222222", clip_on=False, linewidth=0.9)
    kwargs_bottom = dict(transform=ax_bottom.transAxes, color="#222222", clip_on=False, linewidth=0.9)
    ax_top.plot((-mark, +mark), (-mark, +mark), **kwargs_top)
    ax_top.plot((1 - mark, 1 + mark), (-mark, +mark), **kwargs_top)
    ax_bottom.plot((-mark, +mark), (1 - mark, 1 + mark), **kwargs_bottom)
    ax_bottom.plot((1 - mark, 1 + mark), (1 - mark, 1 + mark), **kwargs_bottom)


def _bracket(ax: plt.Axes, x1: float, x2: float, y: float, text: str, color: str) -> None:
    height = 0.14
    ax.plot([x1, x1, x2, x2], [y - height, y, y, y - height], color=color, linewidth=1.1)
    ax.text((x1 + x2) / 2.0, y + 0.08, text, color=color, ha="center", va="bottom", fontsize=8.3)


def figure_2(include_figure_title: bool = True) -> plt.Figure:
    """Aggregate ceiling if one frequency bucket were solved perfectly."""
    ceiling = {
        "Reaction class unknown": np.array([[42.30, 9.27], [1.70, 0.78], [0.90, 0.64]]),
        "Reaction class known": np.array([[30.80, 5.31], [1.24, 0.44], [0.80, 0.44]]),
    }
    tail_sums = {
        "Reaction class unknown": (2.60, 1.42),
        "Reaction class known": (2.04, 0.88),
    }

    fig = plt.figure(figsize=(13.6, 7.2))
    outer = fig.add_gridspec(
        1,
        2,
        left=0.075,
        right=0.99,
        bottom=0.16,
        top=0.82 if include_figure_title else 0.91,
        wspace=0.20,
    )
    legend_handles: list[Rectangle] = []

    for panel, (setting, values) in enumerate(ceiling.items()):
        inner = outer[panel].subgridspec(2, 1, height_ratios=(1.15, 1.0), hspace=0.05)
        ax_top = fig.add_subplot(inner[0])
        ax_bottom = fig.add_subplot(inner[1], sharex=ax_top)

        x = np.arange(3, dtype=float)
        width = 0.30
        positions = (x - width / 2, x + width / 2)
        for metric, (color, label) in enumerate(((NAVY, "Top-1 ceiling"), (TEAL, "Top-10 ceiling"))):
            for ax in (ax_top, ax_bottom):
                ax.bar(
                    positions[metric],
                    values[:, metric],
                    width=width * 0.90,
                    color=color,
                    edgecolor="white",
                    linewidth=0.7,
                    zorder=3,
                )
            if panel == 0:
                legend_handles.append(Rectangle((0, 0), 1, 1, facecolor=color, edgecolor="none", label=label))

        ax_top.set_ylim(4.0, 46.0)
        ax_bottom.set_ylim(0.0, 3.20)
        ax_top.spines["bottom"].set_visible(False)
        ax_bottom.spines["top"].set_visible(False)
        ax_top.tick_params(axis="x", which="both", bottom=False, labelbottom=False)
        _draw_axis_break(ax_top, ax_bottom)

        # Numerical labels: head values on the upper axis, tail values on the lower axis.
        for metric in range(2):
            ax_top.text(
                positions[metric][0],
                values[0, metric] + 0.9,
                f"{values[0, metric]:.2f}",
                ha="center",
                va="bottom",
                fontsize=8.8,
            )
            for bucket in (1, 2):
                value = values[bucket, metric]
                ax_bottom.text(
                    positions[metric][bucket],
                    value + 0.08,
                    f"{value:.2f}",
                    ha="center",
                    va="bottom",
                    fontsize=8.5,
                )

        # Exact combined tail ceilings for medium + few.
        top1_sum, top10_sum = tail_sums[setting]
        _bracket(
            ax_bottom,
            positions[0][1],
            positions[0][2],
            2.88,
            f"Both tail buckets: +{top1_sum:.2f} pp",
            NAVY,
        )
        _bracket(
            ax_bottom,
            positions[1][1],
            positions[1][2],
            2.35,
            f"Top-10: +{top10_sum:.2f} pp",
            TEAL,
        )

        ax_bottom.axvspan(0.55, 2.45, color="#F3F7FB", zorder=0)
        ax_top.set_title(setting, loc="left", pad=12)
        panel_label(ax_top, "a" if panel == 0 else "b")
        ax_bottom.set_xticks(x)
        ax_bottom.set_xticklabels(BUCKETS)
        ax_bottom.tick_params(axis="x", length=0)
        ax_top.grid(axis="y", color=GRID, linewidth=0.65, linestyle=(0, (3, 3)), zorder=0)
        ax_bottom.grid(axis="y", color=GRID, linewidth=0.65, linestyle=(0, (3, 3)), zorder=0)

    fig.supylabel("Maximum aggregate gain (percentage points)", x=0.018, fontsize=10.5)
    fig.legend(handles=legend_handles, loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, 0.045))
    if include_figure_title:
        fig.suptitle("The aggregate metric has almost no room to record tail progress", y=0.975)
    return fig


def figure_3(include_figure_title: bool = True) -> plt.Figure:
    """Few-shot model comparison with Wilson intervals and MDD bands."""
    baseline_counts = np.array([7, 16, 19, 20], dtype=int)
    augmented_counts = np.array([10, 17, 22, 26], dtype=int)
    n = 52
    baseline = 100.0 * baseline_counts / n
    augmented = 100.0 * augmented_counts / n
    mdd = np.array([23.7, 27.0, 27.2, 27.2])

    def intervals(counts: np.ndarray) -> np.ndarray:
        bounds = np.array([wilson_interval(int(value), n) for value in counts])
        estimate = 100.0 * counts / n
        return np.vstack([estimate - bounds[:, 0], bounds[:, 1] - estimate])

    fig, ax = plt.subplots(figsize=(13.6, 7.2))
    x = np.arange(4, dtype=float)
    offset = 0.13

    # Each band starts at the baseline estimate and ends at baseline + MDD.
    for i, (base, detectable) in enumerate(zip(baseline, mdd)):
        ax.add_patch(
            Rectangle(
                (i - 0.43, base),
                0.86,
                detectable,
                facecolor=LIGHT_BLUE,
                edgecolor=BLUE,
                linewidth=0.8,
                linestyle=(0, (3, 2)),
                alpha=0.55,
                zorder=0,
            )
        )
        ax.text(
            i,
            base + detectable + 1.0,
            f"MDD {detectable:.1f} pp",
            ha="center",
            va="bottom",
            color=BLUE,
            fontsize=8.8,
            fontweight="bold",
        )

    baseline_err = intervals(baseline_counts)
    augmented_err = intervals(augmented_counts)
    ax.errorbar(
        x - offset,
        baseline,
        yerr=baseline_err,
        fmt="o",
        markersize=5.5,
        color=SLATE,
        ecolor=SLATE,
        elinewidth=1.2,
        capsize=4,
        capthick=1.2,
        label="Graph2Edits",
        zorder=4,
    )
    ax.errorbar(
        x + offset,
        augmented,
        yerr=augmented_err,
        fmt="o",
        markersize=5.5,
        color=CORAL,
        ecolor=CORAL,
        elinewidth=1.2,
        capsize=4,
        capthick=1.2,
        label="Graph2Edits-Aug",
        zorder=4,
    )

    for xi, value in zip(x - offset, baseline):
        ax.text(xi - 0.02, value + 2.2, f"{value:.1f}%", ha="right", va="bottom", color=SLATE, fontsize=8.6)
    for xi, value in zip(x + offset, augmented):
        ax.text(xi + 0.02, value + 2.2, f"{value:.1f}%", ha="left", va="bottom", color=CORAL, fontsize=8.6)

    ax.annotate(
        "+11.5 pp = 6 reactions",
        xy=(3 + offset, augmented[-1]),
        xytext=(2.55, 44.5),
        color=CORAL,
        fontsize=9,
        fontweight="bold",
        arrowprops={"arrowstyle": "->", "color": CORAL, "linewidth": 1.2},
        ha="left",
        va="center",
    )

    ax.set_xticks(x)
    ax.set_xticklabels(TOPK)
    ax.set_xlim(-0.58, 3.58)
    ax.set_ylim(0, 75)
    ax.set_yticks(np.arange(0, 76, 15))
    ax.set_ylabel("Few-shot exact-match accuracy (%)")
    ax.grid(axis="y", color=GRID, linewidth=0.7, linestyle=(0, (3, 3)), zorder=-1)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.11), ncol=2, frameon=False)
    if include_figure_title:
        ax.set_title("Few-shot bucket, $n$ = 52; reaction class unknown", pad=15, fontweight="normal")
    if include_figure_title:
        fig.suptitle("A double-digit tail movement that the benchmark cannot resolve", y=0.975)
    fig.text(
        0.5,
        0.035,
        "Wilson 95% CI; MDD at 80% power, two-sided α = 0.05",
        ha="center",
        va="center",
        fontsize=8.8,
    )
    fig.subplots_adjust(
        left=0.085,
        right=0.99,
        bottom=0.19,
        top=0.80 if include_figure_title else 0.90,
    )
    return fig


def figure_4(include_figure_title: bool = True) -> plt.Figure:
    """Reaction-class composition and per-bucket baseline Top-1 heatmap."""
    counts = np.array(
        [
            [1513, 2, 1],
            [1173, 4, 10],
            [507, 49, 11],
            [83, 5, 3],
            [61, 7, 0],
            [782, 37, 5],
            [445, 5, 12],
            [81, 0, 1],
            [164, 11, 9],
            [23, 0, 0],
        ],
        dtype=int,
    )
    accuracy = np.array(
        [
            [57.1, 50.0, 100.0],
            [66.0, 100.0, 30.0],
            [41.2, 26.5, 9.1],
            [51.8, 40.0, 33.3],
            [63.9, 42.9, np.nan],
            [51.0, 27.0, 0.0],
            [53.5, 0.0, 8.3],
            [60.5, np.nan, 0.0],
            [49.4, 18.2, 0.0],
            [78.3, np.nan, np.nan],
        ]
    )
    totals = counts.sum(axis=1)
    shares = 100.0 * counts / totals[:, None]
    classes = [f"Class {i} ($n$={totals[i]:,})" for i in range(10)]
    y = np.arange(10)

    fig = plt.figure(figsize=(14.2, 7.6))
    grid = fig.add_gridspec(
        1,
        2,
        width_ratios=(1.22, 1.25),
        left=0.075,
        right=0.94,
        bottom=0.13,
        top=0.77 if include_figure_title else 0.90,
        wspace=0.28,
    )
    ax_comp = fig.add_subplot(grid[0])
    ax_heat = fig.add_subplot(grid[1])

    left = np.zeros(10)
    for bucket, color, col in zip(BUCKETS, (NAVY, TEAL, CORAL), range(3)):
        ax_comp.barh(
            y,
            shares[:, col],
            left=left,
            color=color,
            edgecolor="white",
            linewidth=0.7,
            height=0.69,
            label=bucket,
        )
        left += shares[:, col]

    # Many-shot counts are inside the large segment; exact tail counts sit to the right.
    for row in range(10):
        ax_comp.text(
            shares[row, 0] / 2.0,
            row,
            f"{counts[row, 0]:,}",
            ha="center",
            va="center",
            color="white",
            fontsize=8.2,
            fontweight="bold",
        )
        ax_comp.text(
            101.2,
            row,
            f"M={counts[row, 1]:>2}   F={counts[row, 2]:>2}",
            ha="left",
            va="center",
            fontsize=7.8,
            color="#34373B",
        )

    ax_comp.set_yticks(y)
    ax_comp.set_yticklabels(classes)
    ax_comp.invert_yaxis()
    ax_comp.set_xlim(0, 122)
    ax_comp.set_xticks(np.arange(0, 101, 20))
    ax_comp.set_xlabel("Share within reaction class (%)")
    ax_comp.grid(axis="x", color=GRID, linewidth=0.65, linestyle=(0, (3, 3)), zorder=0)
    ax_comp.set_axisbelow(True)
    ax_comp.set_title("Bucket composition by reaction class", loc="left", pad=12)
    panel_label(ax_comp, "a")
    ax_comp.legend(loc="upper center", bbox_to_anchor=(0.47, -0.13), ncol=3, frameon=False)
    ax_comp.text(
        101.2,
        -0.85,
        "Tail counts",
        ha="left",
        va="bottom",
        fontsize=8,
        fontweight="bold",
        color="#34373B",
    )

    purple_map = LinearSegmentedColormap.from_list(
        "journal_purple", ["#F7F5FA", "#C8B5DD", "#7D4CB0", "#3D0B82"]
    )
    purple_map.set_bad(MISSING)
    masked = np.ma.masked_invalid(accuracy)
    image = ax_heat.imshow(masked, cmap=purple_map, vmin=0, vmax=100, aspect="auto", interpolation="nearest")

    for row in range(10):
        for col in range(3):
            if np.isnan(accuracy[row, col]):
                text = "—"
                color = "#55585C"
            else:
                text = f"{accuracy[row, col]:.1f}%\n$n$={counts[row, col]}"
                color = "white" if accuracy[row, col] >= 72 else "#17181A"
            ax_heat.text(col, row, text, ha="center", va="center", fontsize=8.2, color=color)

    ax_heat.set_xticks(np.arange(3))
    ax_heat.set_xticklabels(BUCKETS)
    ax_heat.set_yticks(y)
    ax_heat.set_yticklabels([f"Class {i}" for i in range(10)])
    ax_heat.tick_params(length=0)
    ax_heat.set_title("Top-1 accuracy by class and frequency bucket", loc="left", pad=12)
    panel_label(ax_heat, "b")

    # White cell borders keep rows/columns readable without obscuring the data.
    ax_heat.set_xticks(np.arange(-0.5, 3, 1), minor=True)
    ax_heat.set_yticks(np.arange(-0.5, 10, 1), minor=True)
    ax_heat.grid(which="minor", color="white", linewidth=1.1)
    ax_heat.tick_params(which="minor", bottom=False, left=False)
    colorbar = fig.colorbar(image, ax=ax_heat, fraction=0.046, pad=0.045)
    colorbar.set_label("Top-1 accuracy (%)", rotation=270, labelpad=16)
    colorbar.set_ticks([0, 25, 50, 75, 100])

    if include_figure_title:
        fig.suptitle(
            "Frequency stratification and reaction-class stratification carry different information",
            y=0.975,
        )
        fig.text(
            0.5,
            0.875,
            "Rare-edit reactions occur across multiple reaction classes; class-wise reporting does not expose the head-to-tail gap.",
            ha="center",
            va="center",
            fontsize=10.5,
        )
    return fig


def parse_formats(raw: str) -> tuple[str, ...]:
    allowed = {"png", "pdf", "svg"}
    formats = tuple(item.strip().lower() for item in raw.split(",") if item.strip())
    invalid = sorted(set(formats) - allowed)
    if not formats or invalid:
        raise argparse.ArgumentTypeError(
            f"formats must be a comma-separated subset of png,pdf,svg; invalid: {invalid or 'empty'}"
        )
    return formats


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("figures") / "code_generated",
        help="Output directory (default: figures/code_generated)",
    )
    parser.add_argument(
        "--formats",
        type=parse_formats,
        default=("png", "pdf", "svg"),
        help="Comma-separated output formats chosen from png,pdf,svg",
    )
    parser.add_argument("--dpi", type=int, default=300, help="PNG resolution (default: 300 dpi)")
    parser.add_argument(
        "--journal-ready",
        action="store_true",
        help="Omit figure-level titles so titles and legends can be supplied in the manuscript.",
    )
    args = parser.parse_args(argv)

    configure_style()
    figures = (
        ("Fig2_accuracy_by_edit_frequency", figure_1),
        ("Fig3_aggregate_tail_ceiling", figure_2),
        ("Fig4_few_shot_mdd_comparison", figure_3),
        ("Fig5_class_bucket_composition", figure_4),
    )

    written: list[Path] = []
    for stem, builder in figures:
        written.extend(
            save_figure(
                builder(include_figure_title=not args.journal_ready),
                args.output_dir,
                stem,
                args.formats,
                args.dpi,
            )
        )

    for path in written:
        print(path.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
