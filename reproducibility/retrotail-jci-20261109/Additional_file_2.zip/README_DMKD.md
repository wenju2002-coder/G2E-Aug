# RetroTail supplementary code and data

RetroTail: Edit-frequency stratified evaluation for single-step retrosynthesis prediction

Data Mining and Knowledge Discovery
Authors: Wenju Zhang, Xiaorui Wang, Pei Yang, Yachao Cui, Yuquan Li
Correspondence: yachaocui@qhu.edu.cn; yvquan.li@gzu.edu.cn

RetroTail is an evaluation workflow, not a prediction model. Validation is limited to the Graph2Edits family and one USPTO-50K split. Model code, checkpoints, processed data, raw predictions and four Analysis/*_per_reaction.csv tables are preserved byte for byte from the previous release. No new model inference or experimental results were generated. Correctness discordance refers to exactly one model being correct at a stated top-k cutoff.

## Resources and provenance

ESM_1.pdf is the readable statistical report. ESM_2.zip is this code/data archive. All analysis CSVs for Tables S1–S8 are in evidence_analysis/source_data/analysis_tables/. Table S5 is conditional power planning, not observed performance. See evidence_analysis/SOURCE_MAP.md for each table's source and the current figure-panel mapping. Many/Medium/Few abbreviate the three edit-frequency strata; Known/Unknown refer to supplied/withheld reaction-class input. Observe the distinct rounding conventions explained in ESM_1.

## Recompute statistics from archived records

From the extracted archive root, in an isolated analysis environment:

    python -m pip install -r evidence_analysis/requirements.txt
    python evidence_analysis/scripts/verify_g2e.py . verification_out
    python evidence_analysis/scripts/extra_analyses.py . verification_out

These scripts require the analysis dependencies including RDKit. They operate on the archived processed files and predictions; do not unpickle untrusted model files outside a suitable isolated environment. The restricted loader is supplied.

## Regenerate the submitted supplement from archived analysis CSVs

    python -m pip install pandas numpy reportlab
    python evidence_analysis/scripts/make_si_evidence.py evidence_analysis/source_data/analysis_tables regenerated_ESM_1.md
    python evidence_analysis/scripts/typeset_si.py regenerated_ESM_1.md regenerated_ESM_1.pdf

The table generator is evidence-only: it contains no preset-scenario branch. It needs pandas and NumPy, not PyTorch or RDKit. The typesetter uses Times New Roman on Windows or Liberation Serif on Linux; pass --font-dir if necessary. PDF metadata/font implementations may differ across systems; compare table content, not PDF byte hashes. Numeric source tables are unchanged in this revision. Generated source/metadata notes explain the distinction between observed summaries, exploratory associations and planning calculations. For an independently recomputed analysis directory, substitute verification_out for the archived table directory after confirming required CSVs exist.

## Model inference

The checkpoints are Graph2Edits epoch 123 (class unknown) and epoch 92 (class known), and Graph2Edits-Aug epoch 86 (unknown) and epoch 124 (known). Each of the four ranked tables contains 5,004 matched reactions. Model-specific environments and original licenses remain in the corresponding directories. No public Zenodo DOI has been supplied; a linked partial GitHub project page is not described as a complete public data deposit.

## Figures and historical documentation

Scientific figure assets are unchanged in this revision. Figure 2 is the submitted five-panel layout, not the historical six-panel plotting batch. The typography-only previews from a separate folder are not silently substituted into this manuscript. Current panel labels are mapped in SOURCE_MAP.md. Historical documentation under prior_release_documentation is retained for provenance and does not define this manuscript's conclusions. Original licenses and redistribution conditions remain applicable.
