"""Recompute manuscript results from archived prediction flags, without inference.

Requires joblib and the Graph2Edits data/RDKit environment. Python 3.8+.
The archived files are immutable inputs; output must be a new directory.
"""
import argparse
import csv
import hashlib
import json
import math
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

KS = (1, 3, 5, 10)
BUCKETS = ('Many', 'Medium', 'Few')
NAMES = ('Heteroatom alkylation and arylation', 'Acylation and related processes',
         'C-C bond formation', 'Heterocycle formation', 'Protections', 'Deprotections',
         'Reductions', 'Oxidations', 'Functional-group interconversions', 'Functional-group additions')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def wilson(x, n):
    z = 1.959963984540054
    p = x / n
    denominator = 1 + z*z/n
    centre = (p + z*z/(2*n))/denominator
    half = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))/denominator
    return [100*(centre-half), 100*(centre+half)]


def mdd(n, p0):
    for step in range(1, int((1-p0)*1000)+1):
        delta = step/1000
        p1 = p0+delta
        pooled = (p0+p1)/2
        required = 1.959963984540054*math.sqrt(2*pooled*(1-pooled)/n) + \
            0.8416212335729143*math.sqrt((p0*(1-p0)+p1*(1-p1))/n)
        if delta >= required:
            return round(100*delta, 1)
    return None


def read_predictions(path):
    rows = []
    row = None
    for line in path.read_text(encoding='utf-8').splitlines():
        header = re.match(r'^\((\d+)\) (.*>>.*)$', line)
        if header:
            row = {'index': int(header.group(1)), 'rxn_smi': header.group(2), 'predictions': []}
            rows.append(row)
            continue
        match = re.match(r'^(\d+) prediction_is_correct:(True|False) probability:(\S+) (\S+)(?: (.*))?$', line)
        if match:
            if row is None:
                raise ValueError('Prediction before reaction header: ' + str(path))
            rank = int(match.group(1))+1
            if rank != len(row['predictions'])+1:
                raise ValueError('Non-contiguous candidate ranking: ' + str(path))
            row['predictions'].append({'rank': rank, 'correct': match.group(2)=='True',
                                       'probability': float(match.group(3)),
                                       'smiles': match.group(4), 'actions': match.group(5) or ''})
    for row in rows:
        row['first_match_rank'] = next((p['rank'] for p in row['predictions'] if p['correct']), None)
        for k in KS:
            row['top'+str(k)] = int(row['first_match_rank'] is not None and row['first_match_rank']<=k)
    return rows


def classify(value, lower=20, upper=100):
    return 'Many' if value is None or value>upper else 'Medium' if value>=lower else 'Few'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline_root', type=Path, required=True)
    parser.add_argument('--aug_unknown_dir', type=Path, required=True)
    parser.add_argument('--aug_known_dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError('Refusing to overwrite audit output: '+str(args.output))
    base = args.baseline_root.resolve()
    sys.path.insert(0, str(base))
    import joblib
    from rdkit import Chem, RDLogger, rdBase
    RDLogger.DisableLog('rdApp.*')
    test_path = base/'data/uspto_50k/test/test.file.kekulized'
    train_path = base/'data/uspto_50k/train/train.file.kekulized'
    frequency_path = base/'data/uspto_50k/train/action_freq_map.pkl'
    test, train, frequency = [joblib.load(path) for path in (test_path, train_path, frequency_path)]
    counter = Counter(edit for reaction in train for edit in reaction.edits if edit!='Terminate')
    assert counter == frequency, 'Supplied frequencies disagree with processed training reactions'
    assert len(test)==5004, 'Unexpected evaluated test population'
    minima = [min((counter.get(e,0) for e in r.edits if e!='Terminate'), default=None) for r in test]
    buckets = [classify(value) for value in minima]
    sources = {
        'baseline_unknown': base/'experiments/uspto_50k/without_rxn_class/27-06-2022--10-27-22/pred_results.txt',
        'baseline_known': base/'experiments/uspto_50k/with_rxn_class/30-06-2022--00-19-29/pred_results.txt',
        'aug_unknown': args.aug_unknown_dir/'pred_results_1.txt',
        'aug_known': args.aug_known_dir/'pred_results_4.txt',
    }
    outputs = {key: read_predictions(path) for key,path in sources.items()}
    for key, records in outputs.items():
        assert len(records)==len(test), key+' incomplete'
        assert [r['index'] for r in records]==list(range(len(test))), key+' indices differ'
        assert all(row['rxn_smi']==record.rxn_smi for row,record in zip(records,test)), key+' reaction identities differ'
    args.output.mkdir(parents=True, exist_ok=False)
    checks = {'processed_training_reactions': len(train), 'test_reactions':len(test),
              'frequency_actions':len(counter), 'frequency_matches_processed_train':True,
              'bucket_sizes':dict(Counter(buckets)), 'rdkit_audit_version':rdBase.rdkitVersion,
              'all_four_prediction_sequences_match_test':True,
              'input_sha256':{key:digest(path) for key,path in sources.items()},
              'test_sha256':digest(test_path), 'frequency_sha256':digest(frequency_path),
              'prediction_flag_checks':{}}
    def canonical(smiles):
        molecule = Chem.MolFromSmiles(smiles)
        if molecule is None:
            return None
        for atom in molecule.GetAtoms():
            atom.ClearProp('molAtomMapNumber')
        # Preserve upstream's SMILES round-trip, important for symmetric-ring stereo.
        molecule = Chem.MolFromSmiles(Chem.MolToSmiles(molecule))
        if molecule is None:
            return None
        return set(Chem.MolToSmiles(molecule,isomericSmiles=True).split('.'))
    canonical_references = [canonical(r.rxn_smi.split('>>')[0]) for r in test]
    chemical_exceptions=[]
    summaries=[]
    for key, records in outputs.items():
        normalised=[]
        positive_checks=0;different=0
        for row, reaction, bucket, minimum, reference in zip(records,test,buckets,minima,canonical_references):
            for prediction in row['predictions']:
                if prediction['correct']:
                    positive_checks += 1
                    if canonical(prediction['smiles'])!=reference:
                        different+=1
                        chemical_exceptions.append({'model_setting':key,'reaction_index':row['index'],
                                                    'rank':prediction['rank'], 'predicted_smiles':prediction['smiles'],
                                                    'mapped_reference':reaction.rxn_smi.split('>>')[0]})
            normalised.append({'reaction_index':row['index'], 'reaction_id':str(reaction.rxn_id),
                               'class_index_0_based':int(reaction.rxn_class),
                               'class_number_1_based':int(reaction.rxn_class)+1,
                               'bucket':bucket, 'min_edit_frequency':minimum,
                               'nonterminal_edit_count':sum(e!='Terminate' for e in reaction.edits),
                               'rxn_smi':row['rxn_smi'],
                               'first_match_rank':row['first_match_rank'] or '',
                               **{'top'+str(k):row['top'+str(k)] for k in KS},
                               'predictions_top10_json':json.dumps(row['predictions'][:10],ensure_ascii=False)})
        write_csv(args.output/(key+'_per_reaction.csv'),normalised)
        checks['prediction_flag_checks'][key]={'positive_candidates_checked':positive_checks,
                                              'non_equivalent_in_audit_rdkit':different}
        for group in [None]+list(range(10)):
            for bucket in list(BUCKETS)+(['All'] if group is None else []):
                indices=[i for i,b in enumerate(buckets) if (bucket=='All' or b==bucket) and
                         (group is None or test[i].rxn_class==group)]
                if not indices:continue
                entry={'model_setting':key,'class_index_0_based':'All' if group is None else group,
                       'bucket':bucket,'n':len(indices)}
                for k in KS:
                    correct=sum(records[i]['top'+str(k)] for i in indices)
                    entry['correct_top'+str(k)]=correct
                    entry['top'+str(k)+'_percent']=100*correct/len(indices)
                entry['top1_ci_low'],entry['top1_ci_high']=wilson(entry['correct_top1'],entry['n'])
                summaries.append(entry)
    write_csv(args.output/'verified_bucket_results.csv',summaries)
    if chemical_exceptions:write_csv(args.output/'canonicalization_exceptions.csv',chemical_exceptions)
    paired=[]
    for setting in ['unknown','known']:
        a,b=outputs['baseline_'+setting],outputs['aug_'+setting]
        for bucket in list(BUCKETS)+['All']:
            indices=[i for i,value in enumerate(buckets) if bucket=='All' or value==bucket]
            for k in KS:
                label='top'+str(k)
                loss=sum(a[i][label] and not b[i][label] for i in indices)
                gain=sum(b[i][label] and not a[i][label] for i in indices)
                discordant=loss+gain
                pvalue=min(1,2*sum(math.comb(discordant,j) for j in range(min(loss,gain)+1))/2**discordant) if discordant else 1.0
                paired.append({'setting':setting,'bucket':bucket,'metric':label,'n':len(indices),
                               'baseline_correct':sum(a[i][label] for i in indices),
                               'aug_correct':sum(b[i][label] for i in indices),
                               'baseline_only_correct':loss,'aug_only_correct':gain,
                               'difference_pp':100*(gain-loss)/len(indices),'p_exact':pvalue})
    running=0
    for rank,index in enumerate(sorted(range(len(paired)),key=lambda i:paired[i]['p_exact'])):
        running=max(running,min(1,(len(paired)-rank)*paired[index]['p_exact']))
        paired[index]['p_holm_32']=running
    write_csv(args.output/'paired_tests.csv',paired)
    sensitivity=[]
    for lower,upper in [(10,50),(20,100),(50,200)]:
        labels=[classify(v,lower,upper) for v in minima]
        for setting in ['unknown','known']:
            predictions=outputs['baseline_'+setting]
            values={}
            for bucket in BUCKETS:
                ids=[i for i,v in enumerate(labels) if v==bucket]
                values[bucket]=(len(ids),100*sum(predictions[i]['top1'] for i in ids)/len(ids))
            sensitivity.append({'few_below':lower,'many_above':upper,'setting':setting,
                                'many_n':values['Many'][0],'medium_n':values['Medium'][0],'few_n':values['Few'][0],
                                'many_top1_percent':values['Many'][1],'few_top1_percent':values['Few'][1],
                                'head_to_tail_gap_pp':values['Many'][1]-values['Few'][1]})
    write_csv(args.output/'threshold_sensitivity.csv',sensitivity)
    descriptors=[]
    for bucket in BUCKETS:
        ids=[i for i,v in enumerate(buckets) if v==bucket]
        length=[sum(e!='Terminate' for e in test[i].edits) for i in ids]
        unseen=sum(minima[i]==0 for i in ids)
        descriptors.append({'bucket':bucket,'n':len(ids),'unseen_edit_reactions':unseen,
                            'unseen_edit_percent':100*unseen/len(ids),
                            'median_nonterminal_edits':statistics.median(length),
                            'min_nonterminal_edits':min(length),'max_nonterminal_edits':max(length),
                            'with_leaving_group_attachment':sum(any(e!='Terminate' and e[0]=='Attaching LG' for e in test[i].edits) for i in ids)})
    write_csv(args.output/'bucket_descriptors.csv',descriptors)
    # Separate the primary few-shot definition (which includes frequency zero)
    # from a seen-label-only sensitivity check; keep primary denominators unchanged.
    seen_few=[i for i,v in enumerate(buckets) if v=='Few' and minima[i]>0]
    head=[i for i,v in enumerate(buckets) if v=='Many']
    unseen_sensitivity=[]
    for key,records in outputs.items():
        for k in KS:
            metric='top'+str(k)
            head_correct=sum(records[i][metric] for i in head)
            few_correct=sum(records[i][metric] for i in seen_few)
            head_percent=100*head_correct/len(head)
            few_percent=100*few_correct/len(seen_few)
            low,high=wilson(few_correct,len(seen_few))
            unseen_sensitivity.append({'model_setting':key,'metric':metric,
                                       'seen_few_n':len(seen_few),'excluded_unseen_reactions':5,
                                       'many_n':len(head),'many_correct':head_correct,
                                       'seen_few_correct':few_correct,
                                       'many_percent':head_percent,'seen_few_percent':few_percent,
                                       'seen_few_ci_low':low,'seen_few_ci_high':high,
                                       'head_to_seen_few_gap_pp':head_percent-few_percent})
    write_csv(args.output/'unseen_edit_sensitivity.csv',unseen_sensitivity)
    power=[]
    for row in summaries:
        if not row['model_setting'].startswith('baseline') or row['class_index_0_based']!='All' or row['bucket']=='All':continue
        for k in KS:
            p=row['correct_top'+str(k)]/row['n']
            power.append({'setting':row['model_setting'][len('baseline_'):],'bucket':row['bucket'],
                          'metric':'top'+str(k),'n':row['n'],'baseline_percent':100*p,
                          'aggregate_ceiling_pp':100*(row['n']-row['correct_top'+str(k)])/len(test),
                          'mdd_unpaired_80_percent_power_pp':mdd(row['n'],p)})
    write_csv(args.output/'power_and_ceiling.csv',power)
    checks['sensitivity']=sensitivity
    checks['bucket_descriptors']=descriptors
    checks['unseen_edit_sensitivity']=unseen_sensitivity
    checks['paired_tests']=paired
    checks['summary_rows']=summaries
    (args.output/'audit_results.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({k:v for k,v in checks.items() if k not in ['summary_rows','paired_tests']},indent=2,ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
