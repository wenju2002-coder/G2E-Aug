# Bucket Evaluation: 27-06-2022--10-27-22

- Dataset: `uspto_50k`
- Checkpoint: `epoch_123.pt`
- Beam size: `10`
- Max steps: `9`
- Unit: `reaction`
- Test reactions: `5004`
- Use reaction class: `False`
- Round-trip: `False`

## Evaluation Report (Bucket by Minimum Edit Frequency)

| Reaction Class | Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| 0 | Many-shot | 1513 | 57.1% | 79.2% | 85.8% | 92.1% | - |
| 0 | Medium-shot | 2 | 50.0% | 50.0% | 50.0% | 50.0% | - |
| 0 | Few-shot | 1 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 1 | Many-shot | 1173 | 66.0% | 87.8% | 92.3% | 95.1% | - |
| 1 | Medium-shot | 4 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 1 | Few-shot | 10 | 30.0% | 60.0% | 80.0% | 80.0% | - |
| 2 | Many-shot | 507 | 41.2% | 63.1% | 71.6% | 81.5% | - |
| 2 | Medium-shot | 49 | 26.5% | 42.9% | 46.9% | 61.2% | - |
| 2 | Few-shot | 11 | 9.1% | 27.3% | 27.3% | 27.3% | - |
| 3 | Many-shot | 83 | 51.8% | 65.1% | 69.9% | 79.5% | - |
| 3 | Medium-shot | 5 | 40.0% | 40.0% | 60.0% | 60.0% | - |
| 3 | Few-shot | 3 | 33.3% | 33.3% | 33.3% | 33.3% | - |
| 4 | Many-shot | 61 | 63.9% | 82.0% | 88.5% | 96.7% | - |
| 4 | Medium-shot | 7 | 42.9% | 71.4% | 85.7% | 100.0% | - |
| 5 | Many-shot | 782 | 51.0% | 77.0% | 85.3% | 91.0% | - |
| 5 | Medium-shot | 37 | 27.0% | 48.6% | 54.1% | 70.3% | - |
| 5 | Few-shot | 5 | 0.0% | 20.0% | 20.0% | 20.0% | - |
| 6 | Many-shot | 445 | 53.5% | 76.2% | 81.6% | 88.5% | - |
| 6 | Medium-shot | 5 | 0.0% | 20.0% | 20.0% | 20.0% | - |
| 6 | Few-shot | 12 | 8.3% | 16.7% | 16.7% | 25.0% | - |
| 7 | Many-shot | 81 | 60.5% | 85.2% | 91.4% | 91.4% | - |
| 7 | Few-shot | 1 | 0.0% | 100.0% | 100.0% | 100.0% | - |
| 8 | Many-shot | 164 | 49.4% | 61.0% | 66.5% | 75.0% | - |
| 8 | Medium-shot | 11 | 18.2% | 45.5% | 54.5% | 81.8% | - |
| 8 | Few-shot | 9 | 0.0% | 11.1% | 22.2% | 22.2% | - |
| 9 | Many-shot | 23 | 78.3% | 87.0% | 87.0% | 87.0% | - |

### Overall Summary (All Reaction Classes)

| Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Many-shot | 4832 | 56.2% | 78.3% | 84.6% | 90.4% | - |
| Medium-shot | 120 | 29.2% | 47.5% | 53.3% | 67.5% | - |
| Few-shot | 52 | 13.5% | 30.8% | 36.5% | 38.5% | - |
