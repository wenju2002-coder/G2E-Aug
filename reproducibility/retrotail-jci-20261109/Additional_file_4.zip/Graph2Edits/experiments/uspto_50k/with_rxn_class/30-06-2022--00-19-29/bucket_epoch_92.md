# Bucket Evaluation: 30-06-2022--00-19-29

- Dataset: `uspto_50k`
- Checkpoint: `epoch_92.pt`
- Beam size: `10`
- Max steps: `9`
- Unit: `reaction`
- Test reactions: `5004`
- Use reaction class: `True`
- Round-trip: `False`

## Evaluation Report (Bucket by Minimum Edit Frequency)

| Reaction Class | Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| 0 | Many-shot | 1513 | 64.4% | 86.2% | 92.1% | 94.6% | - |
| 0 | Medium-shot | 2 | 50.0% | 50.0% | 50.0% | 50.0% | - |
| 0 | Few-shot | 1 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 1 | Many-shot | 1173 | 76.4% | 94.2% | 96.3% | 96.8% | - |
| 1 | Medium-shot | 4 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 1 | Few-shot | 10 | 30.0% | 70.0% | 80.0% | 80.0% | - |
| 2 | Many-shot | 507 | 54.6% | 76.1% | 81.3% | 87.0% | - |
| 2 | Medium-shot | 49 | 42.9% | 65.3% | 71.4% | 81.6% | - |
| 2 | Few-shot | 11 | 9.1% | 27.3% | 36.4% | 45.5% | - |
| 3 | Many-shot | 83 | 71.1% | 83.1% | 85.5% | 85.5% | - |
| 3 | Medium-shot | 5 | 80.0% | 80.0% | 80.0% | 80.0% | - |
| 3 | Few-shot | 3 | 66.7% | 100.0% | 100.0% | 100.0% | - |
| 4 | Many-shot | 61 | 91.8% | 95.1% | 96.7% | 96.7% | - |
| 4 | Medium-shot | 7 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 5 | Many-shot | 782 | 62.5% | 88.6% | 93.7% | 95.0% | - |
| 5 | Medium-shot | 37 | 37.8% | 56.8% | 75.7% | 89.2% | - |
| 5 | Few-shot | 5 | 0.0% | 20.0% | 80.0% | 80.0% | - |
| 6 | Many-shot | 445 | 73.7% | 90.8% | 94.8% | 96.6% | - |
| 6 | Medium-shot | 5 | 0.0% | 40.0% | 40.0% | 40.0% | - |
| 6 | Few-shot | 12 | 16.7% | 16.7% | 25.0% | 41.7% | - |
| 7 | Many-shot | 81 | 90.1% | 97.5% | 97.5% | 97.5% | - |
| 7 | Few-shot | 1 | 100.0% | 100.0% | 100.0% | 100.0% | - |
| 8 | Many-shot | 164 | 70.1% | 84.8% | 89.0% | 91.5% | - |
| 8 | Medium-shot | 11 | 63.6% | 63.6% | 63.6% | 63.6% | - |
| 8 | Few-shot | 9 | 22.2% | 33.3% | 33.3% | 33.3% | - |
| 9 | Many-shot | 23 | 100.0% | 100.0% | 100.0% | 100.0% | - |

### Overall Summary (All Reaction Classes)

| Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Many-shot | 4832 | 68.1% | 88.2% | 92.5% | 94.5% | - |
| Medium-shot | 120 | 48.3% | 65.0% | 73.3% | 81.7% | - |
| Few-shot | 52 | 23.1% | 40.4% | 51.9% | 57.7% | - |
