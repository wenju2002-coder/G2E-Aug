import argparse
import os
from collections import Counter, defaultdict

import joblib
import numpy as np
import torch
from rdkit import Chem, RDLogger
from tqdm import tqdm

from models import BeamSearch, Graph2Edits


lg = RDLogger.logger()
lg.setLevel(4)

ROOT_DIR = './'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


def torch_load(path):
    try:
        return torch.load(path, map_location=DEVICE, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=DEVICE)


def build_action_freq_map(dataset_root):
    train_file = os.path.join(dataset_root, 'train', 'train.file.kekulized')
    if not os.path.exists(train_file):
        train_file = os.path.join(dataset_root, 'train', 'train.file')
    if not os.path.exists(train_file):
        raise FileNotFoundError(
            f'Training file not found under {os.path.join(dataset_root, "train")}')

    rxns_data = joblib.load(train_file)
    action_counter = Counter()
    for rxn in rxns_data:
        for edit in rxn.edits:
            if edit != 'Terminate':
                action_counter[edit] += 1

    save_path = os.path.join(dataset_root, 'train', 'action_freq_map.pkl')
    joblib.dump(action_counter, save_path)
    print(f'Saved action frequency map with {len(action_counter)} actions to {save_path}')
    return action_counter


def load_action_freq_map(dataset_root):
    freq_map_path = os.path.join(dataset_root, 'train', 'action_freq_map.pkl')
    if os.path.exists(freq_map_path):
        freq_map = joblib.load(freq_map_path)
    else:
        print('Frequency map not found. Building from training edits...')
        freq_map = build_action_freq_map(dataset_root)
    print(f'Loaded frequency map with {len(freq_map)} actions.')
    return freq_map


def get_bucket(edits, freq_map):
    min_freq = float('inf')
    for edit in edits:
        if edit == 'Terminate':
            continue
        min_freq = min(min_freq, freq_map.get(edit, 0))

    if min_freq == float('inf') or min_freq > 100:
        return 'Many-shot'
    if min_freq >= 20:
        return 'Medium-shot'
    return 'Few-shot'


def canonical_reactant_set(reactants_smi):
    mol = Chem.MolFromSmiles(reactants_smi)
    if mol is None:
        return set(reactants_smi.split('.'))
    for atom in mol.GetAtoms():
        atom.ClearProp('molAtomMapNumber')
    mol = Chem.MolFromSmiles(Chem.MolToSmiles(mol))
    if mol is None:
        return set(reactants_smi.split('.'))
    return set(Chem.MolToSmiles(mol, isomericSmiles=True).split('.'))


def load_model(exp_dir, epoch):
    checkpoint_path = os.path.join(exp_dir, epoch)
    print(f'Loading checkpoint: {checkpoint_path}')
    checkpoint = torch_load(checkpoint_path)
    config = checkpoint['saveables']

    model = Graph2Edits(**config, device=DEVICE)
    model.load_state_dict(checkpoint['state'])
    model.to(DEVICE)
    model.eval()
    return model


def get_available_file_path(directory, filename):
    base_name, ext = os.path.splitext(filename)
    path = os.path.join(directory, filename)
    file_num = 1
    while os.path.exists(path):
        path = os.path.join(directory, f'{base_name}_{file_num}{ext}')
        file_num += 1
    return path


def build_report(stats, metadata=None, use_round_trip=False):
    classes = sorted({key[0] for key in stats if key[0] != -1})
    buckets = ['Many-shot', 'Medium-shot', 'Few-shot']
    lines = []

    overall = {
        bucket: {'total': 0, 'top1': 0, 'top3': 0, 'top5': 0, 'top10': 0, 'rt': 0}
        for bucket in buckets
    }
    for (_, bucket), row in stats.items():
        if bucket not in overall:
            continue
        overall[bucket]['total'] += row['total']
        overall[bucket]['top1'] += row['top1']
        overall[bucket]['top3'] += row['top3']
        overall[bucket]['top5'] += row['top5']
        overall[bucket]['top10'] += row['top10']
        overall[bucket]['rt'] += row['rt']

    if metadata:
        lines.append(f"# Bucket Evaluation: {metadata['experiments']}")
        lines.append('')
        lines.append(f"- Dataset: `{metadata['dataset']}`")
        lines.append(f"- Checkpoint: `{metadata['checkpoint']}`")
        lines.append(f"- Beam size: `{metadata['beam_size']}`")
        lines.append(f"- Max steps: `{metadata['max_steps']}`")
        lines.append("- Unit: `reaction`")
        lines.append(f"- Test reactions: `{metadata['test_reactions']}`")
        lines.append(f"- Use reaction class: `{metadata['use_rxn_class']}`")
        lines.append(f"- Round-trip: `{use_round_trip}`")
        lines.append('')

    lines.append('## Evaluation Report (Bucket by Minimum Edit Frequency)')
    lines.append('')
    lines.append('| Reaction Class | Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |')
    lines.append('| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |')

    for rxn_class in classes:
        for bucket in buckets:
            key = (rxn_class, bucket)
            if key not in stats or stats[key]['total'] == 0:
                continue

            row = stats[key]
            total = row['total']
            top1 = row['top1'] / total * 100
            top3 = row['top3'] / total * 100
            top5 = row['top5'] / total * 100
            top10 = row['top10'] / total * 100
            rt = row['rt'] / total * 100 if use_round_trip else '-'
            rt_text = rt if rt == '-' else f'{rt:.1f}%'
            lines.append(f'| {rxn_class} | {bucket} | {total} | {top1:.1f}% | {top3:.1f}% | {top5:.1f}% | {top10:.1f}% | {rt_text} |')

    lines.append('')
    lines.append('### Overall Summary (All Reaction Classes)')
    lines.append('')
    lines.append('| Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |')
    lines.append('| :--- | :---: | :---: | :---: | :---: | :---: | :---: |')
    for bucket in buckets:
        row = overall[bucket]
        total = row['total']
        if total == 0:
            continue
        top1 = row['top1'] / total * 100
        top3 = row['top3'] / total * 100
        top5 = row['top5'] / total * 100
        top10 = row['top10'] / total * 100
        rt = row['rt'] / total * 100 if use_round_trip else '-'
        rt_text = rt if rt == '-' else f'{rt:.1f}%'
        lines.append(f'| {bucket} | {total} | {top1:.1f}% | {top3:.1f}% | {top5:.1f}% | {top10:.1f}% | {rt_text} |')

    return '\n'.join(lines)


def print_report(stats, metadata=None, use_round_trip=False, report_file=None):
    report = build_report(stats, metadata=metadata, use_round_trip=use_round_trip)
    print('\n' + report)
    if report_file:
        report_dir = os.path.dirname(os.path.abspath(report_file))
        if report_dir:
            os.makedirs(report_dir, exist_ok=True)
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report + '\n')
        print(f'\nSaved evaluation report to {report_file}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default='USPTO_50k',
                        help='dataset: USPTO_50k or USPTO_full')
    parser.add_argument('--use_rxn_class', default=True, action='store_true',
                        help='Whether to use reaction class')
    parser.add_argument('--experiments', type=str, default='30-06-2022--00-19-29',
                        help='Experiment folder name')
    parser.add_argument('--epoch', type=str, default='epoch_92.pt',
                        help='Checkpoint file name, e.g. epoch_123.pt')
    parser.add_argument('--beam_size', type=int, default=10,
                        help='Beam search width')
    parser.add_argument('--max_steps', type=int, default=9,
                        help='Maximum number of edit steps')
    parser.add_argument('--data_root', type=str, default=ROOT_DIR,
                        help='Root folder containing data/')
    parser.add_argument('--experiments_root', type=str, default=ROOT_DIR,
                        help='Root folder containing experiments/')
    parser.add_argument('--report_file', type=str, default=None,
                        help='Path to save the final Markdown evaluation report. '
                             'Defaults to bucket_<epoch>.md next to the checkpoint.')
    args = parser.parse_args()
    args.dataset = args.dataset.lower()

    data_root = os.path.abspath(args.data_root)
    experiments_root = os.path.abspath(args.experiments_root)
    dataset_root = os.path.join(data_root, 'data', args.dataset)

    freq_map = load_action_freq_map(dataset_root)
    test_file = os.path.join(dataset_root, 'test', 'test.file.kekulized')
    test_data = joblib.load(test_file)

    class_dir = 'with_rxn_class' if args.use_rxn_class else 'without_rxn_class'
    exp_dir = os.path.join(
        experiments_root, 'experiments', args.dataset, class_dir, args.experiments)
    if args.report_file is None:
        epoch_name = os.path.splitext(os.path.basename(args.epoch))[0]
        args.report_file = os.path.join(exp_dir, f'bucket_{epoch_name}.md')

    model = load_model(exp_dir, args.epoch)
    beam_model = BeamSearch(
        model=model,
        step_beam_size=10,
        beam_size=args.beam_size,
        use_rxn_class=args.use_rxn_class,
    )
    pred_file = get_available_file_path(exp_dir, 'pred_results.txt')

    stats = defaultdict(lambda: {
        'total': 0,
        'top1': 0,
        'top3': 0,
        'top5': 0,
        'top10': 0,
        'rt': 0,
    })
    top_k = np.zeros(args.beam_size)

    with open(pred_file, 'w', encoding='utf-8') as fp:
        p_bar = tqdm(enumerate(test_data), total=len(test_data))
        for idx, rxn_data in p_bar:
            rxn_smi = rxn_data.rxn_smi
            rxn_class = getattr(rxn_data, 'rxn_class', -1)
            bucket = get_bucket(rxn_data.edits, freq_map)

            reactants_smi, product_smi = rxn_smi.split('>>')
            true_reactants = canonical_reactant_set(reactants_smi)

            with torch.no_grad():
                top_k_results = beam_model.run_search(
                    prod_smi=product_smi,
                    max_steps=args.max_steps,
                    rxn_class=rxn_data.rxn_class if args.use_rxn_class else None,
                )

            fp.write(f'({idx}) {rxn_smi}\n')

            beam_matched_idx = None
            for beam_idx, path in enumerate(top_k_results):
                pred_smi = path.get('final_smi', 'final_smi_unmapped')
                prob = path.get('prob', 0)
                pred_set = set(pred_smi.split('.')) if pred_smi != 'final_smi_unmapped' else set()
                correct = pred_set == true_reactants
                str_edits = '|'.join(
                    f'({str(edit)};{edit_prob})'
                    for edit, edit_prob in zip(
                        path.get('rxn_actions', []), path.get('edits_prob', []))
                )
                fp.write(
                    f'{beam_idx} prediction_is_correct:{correct} '
                    f'probability:{prob} {pred_smi} {str_edits}\n')
                if correct and beam_matched_idx is None:
                    beam_matched_idx = beam_idx

            fp.write('\n')

            key = (rxn_class, bucket)
            stats[key]['total'] += 1
            if beam_matched_idx is not None:
                top_k[beam_matched_idx] += 1
                if beam_matched_idx < 1:
                    stats[key]['top1'] += 1
                if beam_matched_idx < 3:
                    stats[key]['top3'] += 1
                if beam_matched_idx < 5:
                    stats[key]['top5'] += 1
                if beam_matched_idx < 10:
                    stats[key]['top10'] += 1

            msg = 'average score'
            for beam_idx in [1, 3, 5, 10]:
                if beam_idx <= args.beam_size:
                    match_acc = np.sum(top_k[:beam_idx]) / (idx + 1)
                    msg += ', t%d: %.4f' % (beam_idx, match_acc)
            p_bar.set_description(msg)

    metadata = {
        'experiments': args.experiments,
        'dataset': args.dataset,
        'checkpoint': args.epoch,
        'beam_size': args.beam_size,
        'max_steps': args.max_steps,
        'test_reactions': len(test_data),
        'use_rxn_class': args.use_rxn_class,
    }
    print_report(stats, metadata=metadata, report_file=args.report_file)
    print(f'Saved prediction results to {pred_file}')


if __name__ == '__main__':
    main()
