import argparse
import csv
import os
from collections import Counter, defaultdict

import joblib
import torch
from rdkit import Chem, RDLogger
from tqdm import tqdm

from models import BeamSearch, Graph2Edits


RDLogger.DisableLog('rdApp.*')

ROOT_DIR = './'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
BUCKETS = ('Many-shot', 'Medium-shot', 'Few-shot')
TOP_KS = (1, 3, 5, 10)


def torch_load(path):
    try:
        return torch.load(
            path, map_location=DEVICE, weights_only=False)
    except TypeError:
        return torch.load(path, map_location=DEVICE)


def find_reaction_file(dataset_root, split):
    split_dir = os.path.join(dataset_root, split)
    candidates = [
        os.path.join(split_dir, f'{split}.file.kekulized'),
        os.path.join(split_dir, f'{split}.file'),
    ]
    for path in candidates:
        if os.path.exists(path):
            return path
    raise FileNotFoundError(
        f'No {split} reaction file found. Tried: {candidates}')


def build_action_freq_map(dataset_root):
    train_file = find_reaction_file(dataset_root, 'train')
    reactions = joblib.load(train_file)
    action_counter = Counter()
    for reaction in reactions:
        for edit in reaction.edits:
            if edit != 'Terminate':
                action_counter[edit] += 1

    output_path = os.path.join(
        dataset_root, 'train', 'action_freq_map.pkl')
    joblib.dump(action_counter, output_path)
    print(
        f'Saved {len(action_counter)} action frequencies to: {output_path}')
    return action_counter


def load_action_freq_map(dataset_root, rebuild=False):
    freq_path = os.path.join(
        dataset_root, 'train', 'action_freq_map.pkl')
    if rebuild or not os.path.exists(freq_path):
        return build_action_freq_map(dataset_root)

    freq_map = joblib.load(freq_path)
    print(f'Loaded {len(freq_map)} action frequencies from: {freq_path}')
    return freq_map


def lookup_action_frequency(freq_map, edit):
    try:
        if edit in freq_map:
            return int(freq_map[edit])
    except TypeError:
        pass
    return int(freq_map.get(str(edit), 0))


def get_bucket(edits, freq_map, many_threshold, medium_threshold):
    frequencies = [
        lookup_action_frequency(freq_map, edit)
        for edit in edits
        if edit != 'Terminate'
    ]
    if not frequencies:
        return 'Many-shot'

    min_frequency = min(frequencies)
    if min_frequency > many_threshold:
        return 'Many-shot'
    if min_frequency >= medium_threshold:
        return 'Medium-shot'
    return 'Few-shot'


def canonical_component_multiset(smiles):
    components = []
    for component in smiles.split('.'):
        mol = Chem.MolFromSmiles(component)
        if mol is None:
            return None
        mol = Chem.RemoveHs(mol)
        for atom in mol.GetAtoms():
            if atom.HasProp('molAtomMapNumber'):
                atom.ClearProp('molAtomMapNumber')
        components.append(
            Chem.MolToSmiles(mol, isomericSmiles=True))
    return tuple(sorted(components))


def load_model(experiment_dir, checkpoint_name):
    checkpoint_path = os.path.join(
        experiment_dir, checkpoint_name)
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(
            f'Checkpoint not found: {checkpoint_path}')

    print(f'Loading checkpoint: {checkpoint_path}')
    checkpoint = torch_load(checkpoint_path)
    if 'saveables' not in checkpoint or 'state' not in checkpoint:
        raise KeyError(
            'Checkpoint must contain both "saveables" and "state".')

    model = Graph2Edits(
        **checkpoint['saveables'], device=DEVICE)
    model.load_state_dict(checkpoint['state'])
    model.to(DEVICE)
    model.eval()
    return model


def empty_stats():
    return {
        'total': 0,
        'top1': 0,
        'top3': 0,
        'top5': 0,
        'top10': 0,
    }


def update_stats(row, matched_rank):
    row['total'] += 1
    if matched_rank is None:
        return
    for top_k in TOP_KS:
        if matched_rank < top_k:
            row[f'top{top_k}'] += 1


def metric_percent(row, top_k, beam_size):
    if top_k > beam_size or row['total'] == 0:
        return None
    return 100.0 * row[f'top{top_k}'] / row['total']


def format_percent(value):
    return '-' if value is None else f'{value:.1f}%'


def result_row(section, reaction_class, bucket, stats, beam_size):
    row = {
        'section': section,
        'reaction_class': reaction_class,
        'bucket': bucket,
        'total_reactions': stats['total'],
    }
    for top_k in TOP_KS:
        value = metric_percent(stats, top_k, beam_size)
        row[f'top{top_k}'] = (
            '' if value is None else round(value, 4))
    row['round_trip'] = ''
    return row


def table_lines(title, rows, beam_size, include_class):
    lines = ['', title, '']
    if include_class:
        lines.extend([
            '| Reaction Class | Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |',
            '| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |',
        ])
    else:
        lines.extend([
            '| Bucket | Total Reactions | Top-1 | Top-3 | Top-5 | Top-10 | Round-trip |',
            '| :--- | :---: | :---: | :---: | :---: | :---: | :---: |',
        ])

    for reaction_class, bucket, stats in rows:
        values = [
            bucket,
            str(stats['total']),
            *[
                format_percent(metric_percent(
                    stats, top_k, beam_size))
                for top_k in TOP_KS
            ],
            '-',
        ]
        if include_class:
            values.insert(0, str(reaction_class))
        lines.append('| ' + ' | '.join(values) + ' |')
    return lines


def choose_output_paths(
        experiment_dir, split, checkpoint_name,
        report_file=None, csv_file=None):
    checkpoint_tag = os.path.splitext(
        os.path.basename(checkpoint_name))[0]
    split_tag = '' if split == 'test' else f'_{split}'
    base_name = f'bucket_eval{split_tag}_{checkpoint_tag}'

    if report_file:
        report_path = os.path.join(
            experiment_dir, report_file)
    else:
        report_path = None
    if csv_file:
        csv_path = os.path.join(experiment_dir, csv_file)
    else:
        csv_path = None

    if report_path and csv_path:
        return report_path, csv_path

    suffix = 0
    while True:
        numbered_base = (
            base_name if suffix == 0 else f'{base_name}_{suffix}')
        candidate_report = os.path.join(
            experiment_dir, f'{numbered_base}.md')
        candidate_csv = os.path.join(
            experiment_dir, f'{numbered_base}.csv')
        report_available = (
            report_path is not None
            or not os.path.exists(candidate_report)
        )
        csv_available = (
            csv_path is not None
            or not os.path.exists(candidate_csv)
        )
        if report_available and csv_available:
            return (
                report_path or candidate_report,
                csv_path or candidate_csv,
            )
        suffix += 1


def write_csv(path, metadata, result_rows):
    fieldnames = [
        'section',
        'reaction_class',
        'bucket',
        'total_reactions',
        'top1',
        'top3',
        'top5',
        'top10',
        'round_trip',
    ]
    with open(path, 'w', encoding='utf-8', newline='') as output:
        metadata_writer = csv.writer(output)
        for key, value in metadata:
            metadata_writer.writerow([key, value])
        metadata_writer.writerow([])

        writer = csv.DictWriter(
            output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(result_rows)


def main():
    parser = argparse.ArgumentParser(
        description='Evaluate G2E Top-k accuracy by edit-frequency bucket.')
    parser.add_argument(
        '--dataset', type=str, default='uspto_50k')
    parser.add_argument(
        '--split', choices=['valid', 'test'], default='test')
    parser.add_argument(
        '--use_rxn_class', action='store_true')
    parser.add_argument(
        '--experiments', type=str, required=True,
        help='Experiment folder name.')
    parser.add_argument(
        '--epoch', type=str, required=True,
        help='Checkpoint filename, e.g. epoch_123.pt.')
    parser.add_argument(
        '--beam_size', type=int, default=10)
    parser.add_argument(
        '--step_beam_size', type=int, default=10)
    parser.add_argument(
        '--max_steps', type=int, default=9)
    parser.add_argument(
        '--many_threshold', type=int, default=100,
        help='Many-shot requires minimum edit frequency > this value.')
    parser.add_argument(
        '--medium_threshold', type=int, default=20,
        help='Medium-shot requires minimum edit frequency >= this value.')
    parser.add_argument(
        '--rebuild_freq_map', action='store_true')
    parser.add_argument(
        '--limit', type=int, default=0,
        help='Evaluate only the first N reactions; 0 evaluates all.')
    parser.add_argument(
        '--report_file', type=str, default=None)
    parser.add_argument(
        '--csv_file', type=str, default=None)
    parser.add_argument(
        '--data_root', type=str, default=ROOT_DIR)
    parser.add_argument(
        '--experiments_root', type=str, default=ROOT_DIR)
    args = parser.parse_args()

    args.dataset = args.dataset.lower()
    if args.medium_threshold > args.many_threshold:
        raise ValueError(
            'medium_threshold must be <= many_threshold.')
    if args.beam_size < 1 or args.step_beam_size < 1:
        raise ValueError('Beam sizes must be positive.')

    data_root = os.path.abspath(args.data_root)
    experiments_root = os.path.abspath(
        args.experiments_root)
    dataset_root = os.path.join(
        data_root, 'data', args.dataset)
    reaction_file = find_reaction_file(
        dataset_root, args.split)
    reactions = joblib.load(reaction_file)
    if args.limit > 0:
        reactions = reactions[:args.limit]

    freq_map = load_action_freq_map(
        dataset_root, rebuild=args.rebuild_freq_map)
    class_dir = (
        'with_rxn_class'
        if args.use_rxn_class
        else 'without_rxn_class'
    )
    experiment_dir = os.path.join(
        experiments_root,
        'experiments',
        args.dataset,
        class_dir,
        args.experiments,
    )
    model = load_model(experiment_dir, args.epoch)
    beam_model = BeamSearch(
        model=model,
        step_beam_size=args.step_beam_size,
        beam_size=args.beam_size,
        use_rxn_class=args.use_rxn_class,
    )

    overall_stats = {
        bucket: empty_stats() for bucket in BUCKETS
    }
    class_stats = defaultdict(empty_stats)
    invalid_targets = 0

    progress = tqdm(
        enumerate(reactions), total=len(reactions))
    for index, reaction in progress:
        reactants, product = reaction.rxn_smi.split(
            '>>', 1)
        target = canonical_component_multiset(reactants)
        if target is None:
            invalid_targets += 1

        bucket = get_bucket(
            reaction.edits,
            freq_map,
            args.many_threshold,
            args.medium_threshold,
        )
        reaction_class = getattr(
            reaction, 'rxn_class', None)
        model_reaction_class = (
            reaction_class if args.use_rxn_class else None)

        with torch.no_grad():
            predictions = beam_model.run_search(
                prod_smi=product,
                max_steps=args.max_steps,
                rxn_class=model_reaction_class,
            )

        matched_rank = None
        if target is not None:
            for rank, path in enumerate(
                    predictions[:args.beam_size]):
                predicted_smiles = path.get(
                    'final_smi', 'final_smi_unmapped')
                if predicted_smiles == 'final_smi_unmapped':
                    continue
                predicted = canonical_component_multiset(
                    predicted_smiles)
                if predicted is not None and predicted == target:
                    matched_rank = rank
                    break

        update_stats(overall_stats[bucket], matched_rank)
        if args.use_rxn_class:
            update_stats(
                class_stats[(reaction_class, bucket)],
                matched_rank,
            )

        evaluated = index + 1
        top1_correct = sum(
            row['top1'] for row in overall_stats.values())
        top10_correct = sum(
            row['top10'] for row in overall_stats.values())
        progress.set_description(
            f'Top-1 {top1_correct / evaluated:.4f}, '
            f'Top-10 {top10_correct / evaluated:.4f}')

    total_count = sum(
        row['total'] for row in overall_stats.values())
    if total_count != len(reactions):
        raise RuntimeError(
            f'Bucket total {total_count} does not match '
            f'evaluated reactions {len(reactions)}.')

    report_lines = [
        f'# G2E Bucket Evaluation: {args.experiments}',
        '',
        f'- Dataset: `{args.dataset}`',
        f'- Split: `{args.split}`',
        f'- Checkpoint: `{args.epoch}`',
        f'- Beam size: `{args.beam_size}`',
        f'- Step beam size: `{args.step_beam_size}`',
        f'- Max steps: `{args.max_steps}`',
        f'- Use reaction class: `{args.use_rxn_class}`',
        f'- Evaluated reactions: `{len(reactions)}`',
        f'- Bucket rule: `Many > {args.many_threshold}; '
        f'Medium {args.medium_threshold}-{args.many_threshold}; '
        f'Few < {args.medium_threshold}`',
    ]
    if invalid_targets:
        report_lines.append(
            f'- Invalid target SMILES: `{invalid_targets}`')

    csv_rows = []
    if args.use_rxn_class:
        class_table_rows = []
        reaction_classes = sorted({
            key[0] for key in class_stats.keys()
        }, key=lambda value: (
            value is None, str(value)))
        for reaction_class in reaction_classes:
            for bucket in BUCKETS:
                stats = class_stats.get(
                    (reaction_class, bucket))
                if not stats or stats['total'] == 0:
                    continue
                class_table_rows.append(
                    (reaction_class, bucket, stats))
                csv_rows.append(result_row(
                    'by_reaction_class',
                    reaction_class,
                    bucket,
                    stats,
                    args.beam_size,
                ))
        report_lines.extend(table_lines(
            '## Results by Reaction Class',
            class_table_rows,
            args.beam_size,
            include_class=True,
        ))

    overall_table_rows = []
    for bucket in BUCKETS:
        stats = overall_stats[bucket]
        if stats['total'] == 0:
            continue
        overall_table_rows.append(
            ('All', bucket, stats))
        csv_rows.append(result_row(
            'overall',
            'All',
            bucket,
            stats,
            args.beam_size,
        ))
    report_lines.extend(table_lines(
        '## Overall Summary',
        overall_table_rows,
        args.beam_size,
        include_class=False,
    ))

    report_text = '\n'.join(report_lines) + '\n'
    print('\n' + report_text)

    report_path, csv_path = choose_output_paths(
        experiment_dir=experiment_dir,
        split=args.split,
        checkpoint_name=args.epoch,
        report_file=args.report_file,
        csv_file=args.csv_file,
    )
    with open(
            report_path, 'w', encoding='utf-8') as output:
        output.write(report_text)

    metadata = [
        ('experiment', args.experiments),
        ('dataset', args.dataset),
        ('split', args.split),
        ('checkpoint', args.epoch),
        ('beam_size', args.beam_size),
        ('step_beam_size', args.step_beam_size),
        ('max_steps', args.max_steps),
        ('use_rxn_class', args.use_rxn_class),
        ('num_reactions', len(reactions)),
        ('many_threshold', args.many_threshold),
        ('medium_threshold', args.medium_threshold),
        ('round_trip_enabled', False),
    ]
    write_csv(csv_path, metadata, csv_rows)
    print(f'Saved Markdown report to: {report_path}')
    print(f'Saved CSV report to: {csv_path}')


if __name__ == '__main__':
    main()
