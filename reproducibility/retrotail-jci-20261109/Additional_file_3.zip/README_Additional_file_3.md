# Additional file 3

# RetroTail Journal of Cheminformatics additional files

Article: RetroTail: Edit-frequency stratified evaluation for single-step retrosynthesis prediction
Authors: Wenju Zhang, Xiaorui Wang, Pei Yang, Yachao Cui, Yuquan Li
Release adaptation: 9 November 2026

## Assembly

Additional_file_1.pdf is the statistical report (Tables S1-S8 and Note S1).
Extract each of Additional_file_2.zip through Additional_file_6.zip into the SAME
empty parent directory. These are five independent ZIPs, not multipart volumes.
They restore Analysis/, evidence_analysis/, Graph2Edits/ and Graph2Edits-Aug/.
Do not extract each into a different wrapper folder. Each ZIP includes a file-specific
README and SHA256 manifest. The original metadata are retained as historical records;
the JCI manifests and this README describe the current release.

## Contents and evidence

2: matched ranked records and analysis/plotting sources;
3: Graph2Edits source/data; 4: Graph2Edits weights and raw historical results;
5: Graph2Edits-Aug source/data; 6: Graph2Edits-Aug weights and raw historical results.
The four Analysis/*_per_reaction.csv files each contain the same 5004 test reactions.
No fresh predictions, training runs, chemical examples or experimental results were
created during adaptation. The supplemental PDF uses the existing CSV summaries.
Table S5 describes hypothetical statistical planning, not extra experiments.
The legacy evidence_analysis/ESM_1.pdf is an identical compatibility alias of
Additional_file_1.pdf. Do not submit it as another additional file.

## Reproduction and licences

From the common extraction directory, recreate the current statistical report with:

```sh
python evidence_analysis/scripts/make_si_evidence_jci.py evidence_analysis/source_data/analysis_tables rebuilt_Additional_file_1.md
python evidence_analysis/scripts/typeset_si_jci.py rebuilt_Additional_file_1.md rebuilt_Additional_file_1.pdf
```

Use the statistical environment documented in Methods; the PDF typesetter additionally
requires ReportLab and a supported Times/Liberation Serif font directory. Pass
`--font-dir` to configure fonts on another operating system. Historical non-JCI
generator names are retained for provenance, not the current report front matter.

See the retained evidence_analysis/README* files and scripts for statistical commands,
and the model-directory READMEs for inference environments. Preserve the original
working-directory structure. The statistical analysis environment and historical
model environments differ, as described in the article; no new inference environment
has been independently validated by this packaging step.
For the approved five-panel Figure 4, see evidence_analysis/approved_figure4/code/
and its source_data/. Other retained figure scripts provide earlier figure provenance;
evidence_analysis/figures/ contains the current approved figures. Historical manifests
may refer to previous six-panel figure layouts, not to the current JCI layout.
Figure source changes concern presentation only. The final PDF figures are vector,
and PNG companions use 600 dpi. No font files are distributed.
See LICENSE_SCOPE_JCI.md and LICENSE_RetroTail_Code.txt. Upstream notices remain.
The complete Graph2Edits-Aug model/training/preprocessing source is public at GitHub commit 78b4a44. GitHub does not contain the matching datasets or weights; these additional files remain the version-specific evidence archive. No study-specific Zenodo DOI is claimed.

## Approved Figure 2 update

Figure 2 source and unchanged numerical inputs: evidence_analysis/approved_figure2_20261109/.
Run `python evidence_analysis/approved_figure2_20261109/code/preview_fig2_encoding.py` from the common extraction directory.
Its open/filled markers denote class unknown/known throughout this figure. Panel d/e class text is omitted in favour of the shared legend.
The top-level current figure assets are evidence_analysis/figures/fig2.*; earlier layout folders and their manifests are historical, not the final Figure 2.
The script exports a 300-dpi preview; the release 600-dpi PNG is rendered from its identical vector PDF.
